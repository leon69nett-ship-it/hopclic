const renderBeforeHideCardPlacement=render;
render=function(){
  renderBeforeHideCardPlacement();
  for(const label of document.querySelectorAll('#editor label'))if(label.firstChild?.textContent.trim()==='Emplacement de la carte de visite')label.remove();
};
render();
