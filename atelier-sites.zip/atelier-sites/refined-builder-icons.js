Object.assign(builderIconPaths,{
 company:'M4 21h16M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16M10 21v-4h4v4M9 7h.01M15 7h.01M9 11h.01M15 11h.01',
 intro:'M3 10.5l7.8-6.8a2 2 0 0 1 2.4 0l7.8 6.8M5 9v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9M9 21v-7h6v7',
 services:'M4 7l4-4 4 4-4 4zM13 16l4-4 4 4-4 4zM12 7h5v5M7 12v5h5',
 gallery:'M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2M3 15l5-5 5 5 3-3 5 5M16 8h.01',
 text:'M5 4h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-6 3V6a2 2 0 0 1 2-2M7 8h10M7 12h7',
 zone:'M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 0 1 14 0M9 10a3 3 0 1 0 6 0 3 3 0 1 0-6 0',
 contact:'M5 5h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2M3 7l9 6 9-6',
 video:'M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2M10 8l6 4-6 4z'
});
const renderBeforeRefinedBuilderIcons=render;
render=function(){renderBeforeRefinedBuilderIcons();for(const icon of document.querySelectorAll('.content-choice .choice-icon')){const path=builderIconPaths[icon.dataset.kind]||'M12 3l9 9-9 9-9-9z';icon.innerHTML='<svg viewBox="0 0 24 24" width="25" height="25" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+path+'"/></svg>'}};render();
