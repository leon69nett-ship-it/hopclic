// A reusable immersive media chapter that can be placed between any two content blocks.
contentNames.transition = 'Passage photo / vidéo';
editorSectionIcons.transition = '🎞️';
const transitionTitle = block => block.title || 'Un nouveau chapitre';
const transitionPageName = block => block.menuLabel || block.title || ({intro: 'Accueil', services: 'Prestations', gallery: 'Réalisations', text: 'Présentation', zone: 'Zone et horaires', contact: 'Contact', video: 'Vidéos', partners: 'Partenaires', social: 'Réseaux sociaux', promotions: 'Promotions', payment: 'Paiement'})[block.type] || 'Rubrique';
const regularBlocks = () => state.blocks.filter(block => block.type !== 'transition' && block.visible !== false);
function disableMotionEffectsForTransitions() {
  if (!state.blocks.some(block => block.type === 'transition' && block.visible !== false)) return;
  state.hoverTextMotion = false;
  state.homeLoadingAnimation = 'none';
  state.siteMenuPresentation = 'static';
  for (const block of state.blocks) {
    if (block.type !== 'intro') continue;
    block.titleAnimation = 'none';
    block.photoAnimation = 'none';
  }
}
const transitionInsertionIndex = afterId => {
  if (!afterId) return 0;
  const index = state.blocks.findIndex(block => block.id === afterId);
  if (index < 0) return state.blocks.length;
  let next = index + 1;
  while (state.blocks[next]?.type === 'transition') next++;
  return next;
};
const transitionAfterId = block => {
  const index = state.blocks.indexOf(block);
  for (let previous = index - 1; previous >= 0; previous--) {
    if (state.blocks[previous].type !== 'transition' && state.blocks[previous].visible !== false) return state.blocks[previous].id;
  }
  return '';
};
const refreshEditor = () => { render(); update(); };

function createTransitionBlock() {
  if (state.blocks.length >= 30) {
    $('#status').textContent = 'La limite de 30 rubriques est atteinte.';
    return;
  }
  const blocks = regularBlocks();
  const defaultGap = blocks[0];
  const block = {id: crypto.randomUUID(), type: 'transition', title: 'Un nouveau chapitre', text: '', visible: true, transitionPhotoId: '', transitionVideoId: '', transitionColor: '#18241f', transitionOverlay: 34};
  state.blocks.splice(transitionInsertionIndex(defaultGap?.id || ''), 0, block);
  disableMotionEffectsForTransitions();
  refreshEditor();
  $('#status').textContent = 'Page de transition ajoutée à l’organisation du site.';
}

function moveTransition(block, afterId) {
  const current = state.blocks.indexOf(block);
  if (current < 0) return;
  state.blocks.splice(current, 1);
  state.blocks.splice(transitionInsertionIndex(afterId), 0, block);
  refreshEditor();
}

function renderTransitionOrganization(settings) {
  settings.querySelector('.scroll-transition-organization')?.remove();
  const section = document.createElement('section');
  section.className = 'scroll-transition-organization';
  const heading = document.createElement('h3');
  heading.textContent = 'Pages de transition';
  const help = document.createElement('p');
  help.className = 'hint';
  help.textContent = 'La photo reste fixe en fond pendant le défilement. La rubrique précédente puis la suivante passent par-dessus.';
  section.append(heading, help);

  const add = document.createElement('button');
  add.type = 'button';
  add.className = 'scroll-transition-add';
  add.textContent = '+ Ajouter une page de transition';
  add.addEventListener('click', createTransitionBlock);
  section.append(add);

  const pages = regularBlocks();
  for (const block of state.blocks.filter(item => item.type === 'transition')) {
    const card = document.createElement('article');
    card.className = 'scroll-transition-settings';
    const cardTitle = document.createElement('h4');
    cardTitle.textContent = transitionTitle(block);
    card.append(cardTitle);

    const activeLabel = document.createElement('label');
    const active = document.createElement('input');
    active.type = 'checkbox';
    active.checked = block.visible !== false;
    active.addEventListener('change', () => { block.visible = active.checked; disableMotionEffectsForTransitions(); refreshEditor(); });
    activeLabel.append(active, document.createTextNode(' Afficher cette page de transition'));
    card.append(activeLabel);

    const positionLabel = document.createElement('label');
    positionLabel.textContent = 'Emplacement dans le site';
    const position = document.createElement('select');
    const beforeFirst = document.createElement('option');
    beforeFirst.value = '';
    beforeFirst.textContent = 'Avant la première rubrique';
    position.append(beforeFirst);
    for (const page of pages) {
      const option = document.createElement('option');
      option.value = page.id;
      option.textContent = 'Après « ' + transitionPageName(page) + ' »';
      position.append(option);
    }
    position.value = transitionAfterId(block);
    position.addEventListener('change', () => moveTransition(block, position.value));
    positionLabel.append(position);
    card.append(positionLabel);

    const titleLabel = document.createElement('label');
    titleLabel.textContent = 'Titre affiché sur la transition';
    const titleInput = document.createElement('input');
    titleInput.value = block.title || '';
    titleInput.maxLength = 180;
    titleInput.placeholder = 'Un nouveau chapitre';
    titleInput.addEventListener('input', () => { block.title = titleInput.value; cardTitle.textContent = transitionTitle(block); update(); });
    titleLabel.append(titleInput);
    card.append(titleLabel);

    const textLabel = document.createElement('label');
    textLabel.textContent = 'Petit texte (facultatif)';
    const textInput = document.createElement('textarea');
    textInput.value = block.text || '';
    textInput.maxLength = 1200;
    textInput.rows = 3;
    textInput.addEventListener('input', () => { block.text = textInput.value; update(); });
    textLabel.append(textInput);
    card.append(textLabel);

    const photo = (state.photoLibrary || []).find(item => item.id === block.transitionPhotoId);
    const video = (state.videoLibrary || []).find(item => item.id === block.transitionVideoId);
    if (photo) {
      const preview = document.createElement('img');
      preview.src = photo.src;
      preview.alt = photo.title || 'Photo de transition sélectionnée';
      preview.className = 'card-preview';
      card.append(preview);
    }
    const mediaStatus = document.createElement('p');
    mediaStatus.className = 'hint';
    mediaStatus.textContent = photo?.title || video?.title || 'Aucun média choisi';
    card.append(mediaStatus);

    const photoButton = document.createElement('button');
    photoButton.type = 'button';
    photoButton.textContent = 'Choisir une photo';
    photoButton.addEventListener('click', () => openTransitionPhotoPicker(block));
    const videoButton = document.createElement('button');
    videoButton.type = 'button';
    videoButton.textContent = 'Choisir une vidéo';
    videoButton.addEventListener('click', () => {
      if (typeof openUnifiedVideoPicker !== 'function') {
        $('#status').textContent = 'La bibliothèque vidéo est encore en préparation.';
        return;
      }
      openUnifiedVideoPicker([block.transitionVideoId], false, ids => {
        block.transitionVideoId = ids[0] || '';
        block.transitionPhotoId = '';
        refreshEditor();
      });
    });
    const removeMedia = document.createElement('button');
    removeMedia.type = 'button';
    removeMedia.textContent = 'Retirer le média';
    removeMedia.disabled = !block.transitionPhotoId && !block.transitionVideoId;
    removeMedia.addEventListener('click', () => {
      block.transitionPhotoId = '';
      block.transitionVideoId = '';
      refreshEditor();
    });
    card.append(photoButton, videoButton, removeMedia);

    const colorLabel = document.createElement('label');
    colorLabel.textContent = 'Couleur de fond';
    const color = document.createElement('input');
    color.type = 'color';
    color.value = block.transitionColor || '#18241f';
    color.addEventListener('input', () => { block.transitionColor = color.value; update(); });
    colorLabel.append(color);
    card.append(colorLabel);

    const overlayLabel = document.createElement('label');
    overlayLabel.textContent = 'Voile sombre pour le texte';
    const overlay = document.createElement('input');
    overlay.type = 'range';
    overlay.min = '0';
    overlay.max = '85';
    overlay.value = String(block.transitionOverlay ?? 34);
    const overlayValue = document.createElement('output');
    overlayValue.textContent = overlay.value + ' %';
    overlay.addEventListener('input', () => { block.transitionOverlay = Number(overlay.value); overlayValue.textContent = overlay.value + ' %'; update(); });
    overlayLabel.append(overlay, overlayValue);
    card.append(overlayLabel);

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'remove-transition-block';
    remove.textContent = 'Supprimer cette page de transition';
    remove.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      state.blocks = state.blocks.filter(item => item.id !== block.id);
      refreshEditor();
      $('#status').textContent = 'Page de transition supprimée de l’organisation du site.';
    });
    card.append(remove);
    section.append(card);
  }
  settings.append(section);
}

const renderBeforeScrollMediaTransition = render;
render = function () {
  renderBeforeScrollMediaTransition();
  const editor = document.getElementById('editor');
  // Les passages restent enregistrés comme rubriques, mais leur gestion se fait dans Organisation.
  for (const choice of editor?.querySelectorAll('.content-choice') || []) {
    if (state.blocks.some(block => block.type === 'transition' && block.id === choice.dataset.id)) choice.hidden = true;
  }
  for (const card of editor?.querySelectorAll('.block') || []) {
    if (state.blocks.some(block => block.type === 'transition' && block.id === card.dataset.blockId)) card.hidden = true;
  }
  editor?.querySelector('#editor > .add select option[value="transition"]')?.remove();
  editor?.querySelectorAll('.scroll-transition-add')?.forEach(button => button.remove());
  ensureTransitionOrganization();
};
const ensureTransitionOrganization = () => {
  if (tab !== 'effects') return;
  const editor = document.querySelector('#editor');
  if (!editor) return;
  let group = editor.querySelector('.design-special-effects');
  if (!group) {
    group = document.createElement('details');
    group.className = 'design-special-effects';
    group.open = true;
    const heading = document.createElement('summary');
    heading.textContent = 'Effets spéciaux';
    group.append(heading);
    editor.append(group);
  }
  if (editor.lastElementChild !== group) editor.append(group);
  if (!group.querySelector('.scroll-transition-organization')) renderTransitionOrganization(group);
};
if ('MutationObserver' in window) {
  new MutationObserver(ensureTransitionOrganization).observe(document.querySelector('#editor'), {childList: true, subtree: true});
}
document.querySelector('#tabs')?.addEventListener('click', event => {
  const effectsTab = event.target.closest('button[data-tab="effects"]');
  setTimeout(() => {
    ensureTransitionOrganization();
    if (effectsTab) {
      const effects = document.querySelector('#editor .design-special-effects');
      if (effects) effects.open = true;
    }
  }, 0);
});
setTimeout(ensureTransitionOrganization, 0);

const transitionEditorStyle = document.createElement('style');
transitionEditorStyle.textContent = `
  #editor .scroll-transition-organization{margin:22px 0 4px;padding-top:18px;border-top:1px solid #e5caba}
  #editor .scroll-transition-organization>h3{margin:0 0 5px;color:#38281f;font-size:16px}
  #editor .scroll-transition-organization>.hint{margin:0 0 12px;font-size:12px;line-height:1.55}
  #editor .scroll-transition-organization>.scroll-transition-add{min-height:40px;margin:0 0 14px;padding:9px 14px;border:1px solid #8e3d25;border-radius:9px;background:#fff1e3;color:#582f1f;font-weight:700;cursor:pointer}
  #editor .scroll-transition-settings{display:grid;gap:10px;margin:0 0 13px;padding:14px;border:1px solid #e2c6b3;border-radius:12px;background:#fffdf9}
  #editor .scroll-transition-settings h4{margin:0;color:#38281f;font-size:14px}
  #editor .scroll-transition-settings>label{display:grid;gap:5px;color:#604b3f;font-size:12px}
  #editor .scroll-transition-settings>label:has(input[type=checkbox]){display:flex;align-items:center}
  #editor .scroll-transition-settings input:not([type=checkbox]):not([type=range]),#editor .scroll-transition-settings select,#editor .scroll-transition-settings textarea{box-sizing:border-box;width:100%;min-height:38px;padding:8px 10px;border:1px solid #d6c2b3;border-radius:7px;background:white;color:#38281f;font:inherit}
  #editor .scroll-transition-settings input[type=color]{width:56px!important;padding:3px!important}
  #editor .scroll-transition-settings input[type=range]{width:100%}
  #editor .scroll-transition-settings .card-preview{width:100%;max-height:180px;object-fit:cover;border-radius:8px}
  #editor .scroll-transition-settings>button{justify-self:start}
  #editor .scroll-transition-settings .remove-transition-block{color:#733b2b}
`;
document.head.append(transitionEditorStyle);

function openTransitionPhotoPicker(block) {
  const dialog = document.createElement('dialog');
  dialog.className = 'service-library-dialog';
  dialog.setAttribute('aria-label', 'Choisir une photo de fond');
  const heading = document.createElement('h2');
  heading.textContent = 'Choisir une photo de fond';
  const help = document.createElement('p');
  help.className = 'hint';
  help.textContent = 'Choisissez une photo déjà importée dans votre bibliothèque Photos.';
  const list = document.createElement('div');
  list.className = 'library-grid';
  const photos = state.photoLibrary || [];
  if (!photos.length) {
    const empty = document.createElement('p');
    empty.className = 'notice';
    empty.textContent = 'Importez d’abord vos images dans l’onglet Photos.';
    list.append(empty);
  }
  for (const photo of photos) {
    const choice = document.createElement('button');
    choice.type = 'button';
    choice.className = 'library-photo';
    const image = document.createElement('img');
    image.src = photo.src;
    image.alt = photo.title || 'Photo';
    image.loading = 'lazy';
    const label = document.createElement('span');
    label.textContent = photo.title || 'Photo';
    choice.append(image, label);
    choice.addEventListener('click', () => {
      block.transitionPhotoId = photo.id;
      block.transitionVideoId = '';
      update();
      dialog.close();
      render();
    });
    list.append(choice);
  }
  const cancel = document.createElement('button');
  cancel.type = 'button';
  cancel.textContent = 'Fermer';
  cancel.addEventListener('click', () => dialog.close());
  dialog.append(heading, help, list, cancel);
  dialog.addEventListener('close', () => dialog.remove());
  document.body.append(dialog);
  dialog.showModal();
}

const pageBeforeScrollMediaTransition = page;
page = function () {
  disableMotionEffectsForTransitions();
  const doc = parseRenderedPage(pageBeforeScrollMediaTransition());
  const transitions = state.blocks.filter(block => block.visible && block.type === 'transition');
  if (!transitions.length) return serializeRenderedPage(doc);
  doc.documentElement.dataset.scrollMediaTransitions = 'true';

  for (const block of transitions) {
    const section = doc.getElementById('rubrique-' + block.id);
    if (!section) continue;
    doc.querySelector('.site-menu a[href="#rubrique-' + block.id + '"]')?.remove();
    const photo = (state.photoLibrary || []).find(item => item.id === block.transitionPhotoId);
    const video = (state.videoLibrary || []).find(item => item.id === block.transitionVideoId);
    const videoValue = video?.videoUrl || '';
    const videoInfo = typeof videoSource === 'function' ? videoSource(videoValue) : null;
    const title = esc(block.title || 'Un nouveau chapitre');
    const text = esc(block.text || '');
    let media = '<div class="scroll-transition-placeholder" aria-hidden="true"><span>Choisissez une photo ou une vidéo pour ce passage</span></div>';
    if (photo) {
      media = `<div class="scroll-transition-media scroll-transition-fixed-photo" style="background-image:url(&quot;${esc(photo.src)}&quot;)" aria-hidden="true"></div>`;
    } else if (videoInfo?.file) {
      media = `<video class="scroll-transition-media" src="${esc(videoInfo.file)}" autoplay muted loop playsinline preload="metadata" aria-hidden="true"></video>`;
    } else if (videoInfo?.embed) {
      const videoId = videoValue.match(/(?:youtu\.be\/|[?&]v=|\/embed\/)([\w-]{11})/)?.[1] || '';
      const source = videoInfo.embed + '?autoplay=1&mute=1&controls=0&loop=1&playlist=' + encodeURIComponent(videoId);
      media = `<iframe class="scroll-transition-media" src="${esc(source)}" title="${title}" loading="lazy" allow="autoplay; encrypted-media; picture-in-picture" referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
    }
    section.className = 'scroll-media-transition';
    section.style.setProperty('position', 'relative', 'important');
    section.style.setProperty('left', '50%', 'important');
    section.style.setProperty('width', '100vw', 'important');
    section.style.setProperty('max-width', 'none', 'important');
    section.style.setProperty('margin-left', '-50vw', 'important');
    section.style.setProperty('--transition-color', /^#[0-9a-f]{6}$/i.test(block.transitionColor || '') ? block.transitionColor : '#18241f');
    section.setAttribute('aria-label', 'Transition vers la rubrique suivante');
    section.innerHTML = `<div class="scroll-transition-stage" style="--transition-overlay-alpha:${Math.max(0,Math.min(85,Number(block.transitionOverlay)||0))/100}"><div class="scroll-transition-visual">${media}<span class="scroll-transition-shade" aria-hidden="true"></span><div class="scroll-transition-copy"><h2>${title}</h2>${text ? `<p>${text}</p>` : ''}</div></div></div>`;
    let previous = section.previousElementSibling;
    while (previous?.classList.contains('scroll-media-transition')) previous = previous.previousElementSibling;
    if (previous?.matches('body>section[id^="rubrique-"],body>section#devis')) {
      previous.classList.add('scroll-transition-neighbor');
      previous.classList.add('scroll-transition-before');
      for (const [property, value] of Object.entries({left:'50%',width:'100vw',maxWidth:'none',marginLeft:'-50vw',marginRight:'0',zIndex:'3',border:'0',borderRadius:'0',boxShadow:'none',paddingInline:'max(24px,calc((100vw - 1100px)/2))'})) previous.style.setProperty(property.replace(/[A-Z]/g, char => '-' + char.toLowerCase()), value, 'important');
    }

    let cover = section.nextElementSibling;
    while (cover?.classList.contains('scroll-media-transition')) cover = cover.nextElementSibling;
    if (cover?.matches('body>section[id^="rubrique-"],body>section#devis')) {
      cover.classList.add('scroll-transition-neighbor');
      cover.classList.add('scroll-transition-cover');
      for (const [property, value] of Object.entries({left:'50%',width:'100vw',maxWidth:'none',marginLeft:'-50vw',marginRight:'0',zIndex:'3',border:'0',borderRadius:'0',boxShadow:'none',paddingInline:'max(24px,calc((100vw - 1100px)/2))'})) cover.style.setProperty(property.replace(/[A-Z]/g, char => '-' + char.toLowerCase()), value, 'important');
    }
  }

  if (!doc.getElementById('scroll-media-transition-style')) {
    const style = doc.createElement('style');
    style.id = 'scroll-media-transition-style';
    style.textContent = `
      body>section.scroll-media-transition{position:relative;left:50%;isolation:isolate;box-sizing:border-box;width:100vw!important;max-width:none!important;height:100vh;min-height:0;max-height:none;padding:0!important;margin:0 0 0 -50vw!important;z-index:0;background:transparent;overflow:visible!important}
      body[data-block-presentation="left-rail"]>section.scroll-media-transition,body[data-block-presentation="right-rail"]>section.scroll-media-transition,body[data-block-presentation="left-rail"]>section.scroll-transition-neighbor,body[data-block-presentation="right-rail"]>section.scroll-transition-neighbor{grid-column:1/-1!important}
      .scroll-transition-stage{position:relative;box-sizing:border-box;width:100%;height:100vh;min-height:0;padding:0;display:grid;align-items:center}
      .scroll-transition-visual{position:relative;width:100%;height:100%;overflow:hidden;border-radius:0;background:var(--transition-color,#18241f);color:#fff;display:grid;align-items:center;isolation:isolate;box-shadow:none}
      .scroll-transition-media,.scroll-transition-placeholder{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border:0;z-index:0;transform:none!important;animation:none!important;animation-timeline:auto!important;transition:none!important;filter:none!important}
      .scroll-transition-fixed-photo{background-position:center;background-size:cover;background-repeat:no-repeat;background-attachment:fixed;transform:none!important;animation:none!important;transition:none!important;filter:none!important}
      body>section.scroll-media-transition,body>section.scroll-media-transition *,body>section.scroll-transition-neighbor,body>section.scroll-transition-neighbor *{animation:none!important;animation-timeline:auto!important;transition:none!important;transform:none!important;filter:none!important;scroll-behavior:auto!important}
      html[data-scroll-media-transitions="true"],html[data-scroll-media-transitions="true"] body{scroll-behavior:auto!important}
      html[data-scroll-media-transitions="true"] body>section:not(.scroll-media-transition),html[data-scroll-media-transitions="true"] body>section:not(.scroll-media-transition) *{animation:none!important;animation-timeline:auto!important;transition:none!important;transform:none!important;filter:none!important}
      body>section:not(.business-card).scroll-transition-before{position:relative!important;z-index:3!important;margin-bottom:-12vh!important;isolation:isolate}
      body>section:not(.business-card).scroll-transition-cover{position:relative!important;left:50%!important;width:100vw!important;max-width:none!important;z-index:3!important;margin-left:-50vw!important;margin-right:0!important;margin-top:-40vh!important;padding-inline:max(24px,calc((100vw - 1100px)/2))!important;border:0!important;border-radius:0!important;box-shadow:none!important;isolation:isolate}
      .scroll-transition-placeholder{display:grid;place-items:center;background:radial-gradient(ellipse at 60% 30%,color-mix(in srgb,var(--transition-color) 50%,#fff),var(--transition-color));color:#fff9;font:14px Arial,sans-serif}
      .scroll-transition-shade{position:absolute;inset:0;background:linear-gradient(90deg,#101815b8,#10181530 75%),linear-gradient(0deg,#101815aa,transparent 65%);opacity:var(--transition-overlay-alpha,.34);z-index:1;pointer-events:none}
      .scroll-transition-copy{position:absolute;z-index:2;top:0;right:0;bottom:0;left:0;box-sizing:border-box;width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:clamp(26px,7vw,96px);max-width:none;margin:0;color:white;text-align:center!important}
      .scroll-transition-copy h2{justify-self:center;width:100%;font:italic 700 clamp(44px,7.2vw,96px)/1.02 "${state.font}",serif;letter-spacing:-.045em;max-width:1200px;margin:0 auto;color:white;text-align:center!important;text-shadow:0 2px 25px #0005}.scroll-transition-copy p{color:#fffffff0;font-size:clamp(15px,2vw,20px);max-width:620px}
      @media(max-width:650px){body>section.scroll-media-transition{height:100vh}.scroll-transition-stage{height:100vh}body>section:not(.business-card).scroll-transition-before{margin-bottom:-12vh!important}body>section:not(.business-card).scroll-transition-cover{margin-top:-36vh!important;padding-inline:20px!important}.scroll-transition-copy{padding:24px}.scroll-transition-copy h2{font-size:clamp(34px,10vw,58px)}}
      @media(prefers-reduced-motion:reduce){.scroll-media-transition .scroll-transition-media{animation:none!important;transform:none!important}}
    `;
    doc.head.append(style);
  }
  return serializeRenderedPage(doc);
};

disableMotionEffectsForTransitions();
render();
update();
