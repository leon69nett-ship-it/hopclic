// Give the builder tabs a raised, compact surface and a subtle active light.
const builderTabsStyle = document.createElement('style');
builderTabsStyle.id = 'builder-tabs-glow-style';
builderTabsStyle.textContent = `
  html body .workspace>aside #tabs{display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr));gap:7px!important;border:0!important;margin:22px -5px!important;padding:0!important;overflow:visible}
  html body .workspace>aside #tabs button{position:relative!important;isolation:isolate;display:flex!important;flex-direction:column;align-items:center;justify-content:center;gap:5px;min-width:0;min-height:68px;padding:8px 4px!important;border:1px solid #b8b6b3!important;border-radius:16px!important;background:linear-gradient(155deg,#73747b,#24242c 62%,#11121b)!important;color:#fffaf4!important;font-size:10px!important;font-weight:700!important;line-height:1.15;box-shadow:0 6px 12px #15151b2b,inset 0 1px 2px #ffffff78,inset 0 -4px 8px #0008!important;transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease}
  html body .workspace>aside #tabs button::before{content:"";position:absolute;inset:1px 1px 48%;z-index:-1;border-radius:inherit;background:linear-gradient(#ffffff50,#ffffff00);pointer-events:none}
  html body .workspace>aside #tabs button:hover{transform:translateY(-2px);box-shadow:0 9px 16px #15151b38,inset 0 1px 2px #ffffff8c,inset 0 -4px 8px #0008!important}
  html body .workspace>aside #tabs button.active{border-color:#fff2d4!important;background:linear-gradient(155deg,#88858a,#302b34 62%,#17131d)!important;color:#fff!important;box-shadow:0 0 0 2px #fff,0 0 0 4px #be7046,0 0 14px #f0a44d60,0 7px 15px #15151b38,inset 0 1px 2px #ffffff90,inset 0 -4px 8px #0008!important}
  html body .workspace>aside #tabs button.active::after{content:"";position:absolute;top:6px;right:7px;width:6px;height:6px;border-radius:50%;background:#ffe09a;box-shadow:0 0 5px 2px #ffc961,0 0 12px 4px #ff8f3d9c}
  html body .workspace>aside #tabs button:focus-visible{outline:3px solid #efbd78!important;outline-offset:3px}
  @media(max-width:760px){html body .workspace>aside #tabs{grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:6px!important}html body .workspace>aside #tabs button{min-height:62px!important;padding:6px 2px!important;font-size:9px!important}}
  @media(max-width:380px){html body .workspace>aside #tabs{grid-template-columns:repeat(3,minmax(0,1fr))!important}html body .workspace>aside #tabs button{min-height:58px!important}}
  @media(prefers-reduced-motion:reduce){html body .workspace>aside #tabs button{transition:none!important}}
`;
document.head.append(builderTabsStyle);
