function decoratePromotionPreview(){
 const doc=previewFrame.contentDocument;if(!doc)return;
 for(const section of doc.querySelectorAll('.promotions-section[data-editor-block]')){
  const block=state.blocks.find(b=>b.id===section.dataset.editorBlock);if(!block)continue;
  const openProduct=index=>{selectedBlockId=block.id;tab='blocks';render();syncContentMenu();const card=[...document.querySelectorAll('#editor .block')].find(c=>c.dataset.blockId===block.id);if(card){card.hidden=false;card.querySelector('details').open=true;const panel=card.querySelectorAll('.library-details')[index];(panel||card).scrollIntoView({block:'nearest'});return panel}};
  const empty=section.querySelector('.promotion-empty');
  if(empty&&!empty.querySelector('button')){const add=doc.createElement('button');add.textContent='+ Ajouter un produit en promotion';add.type='button';add.style.cssText='display:block;margin-top:14px';add.onclick=event=>{event.preventDefault();event.stopPropagation();block.products??=[];block.products.push({name:'',description:'',price:'',oldPrice:'',photo:'',mode:'onsite',featured:false});openProduct(block.products.length-1);update()};empty.append(add)}
  section.querySelectorAll('.promotion-product').forEach((card,index)=>{
   if(card.querySelector('img,video,iframe,.promotion-media-actions'))return;
   const actions=doc.createElement('div');actions.className='promotion-media-actions';actions.style.cssText='display:flex;gap:10px;padding:12px;border:0;background:transparent;border-radius:0';
   for(const kind of ['photo','video']){const button=doc.createElement('button');button.type='button';button.textContent=kind==='photo'?'📷':'🎬';button.title=kind==='photo'?'Ajouter une photo':'Ajouter une vidéo';button.setAttribute('aria-label',button.title);button.style.cssText='display:grid;place-items:center;width:44px;height:44px;min-height:44px;padding:0;font-size:22px';button.onclick=event=>{event.preventDefault();event.stopPropagation();const panel=openProduct(index);const label=[...(panel?.querySelectorAll('label')||[])].find(l=>l.firstChild?.textContent===(kind==='photo'?'Photo de la bibliothèque':'Vidéo de la bibliothèque'));label?.querySelector('button')?.click()};actions.append(button)}card.querySelector('.promotion-name')?.before(actions);
  });
 }
}
previewFrame.addEventListener('load',decoratePromotionPreview);
const refreshBeforePromotionActions=refreshPreviewWithoutBlink;
refreshPreviewWithoutBlink=function(){refreshBeforePromotionActions();decoratePromotionPreview()};
decoratePromotionPreview();
