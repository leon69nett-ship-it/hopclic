const pageBeforeModernSiteButtons=page;
page=function(){const doc=parseRenderedPage(pageBeforeModernSiteButtons());
 const targets='.hero a[href]:not(.experimental-destinations a),.hero button,.service-info-button,.quote-form button[type="submit"],#devis form button[type="submit"],.project-comparison-button,.video-result-request,.request-project-style';
 for(const button of doc.querySelectorAll(targets)){if(button.closest('.preview-block-tools,.pro-video-player'))continue;button.classList.add('modern-action-button')}
 const style=doc.createElement('style');style.id='modern-site-buttons';style.textContent=`
 .modern-action-button{position:relative;display:inline-flex!important;align-items:center;justify-content:center;gap:20px;overflow:hidden;border-radius:100px!important;border:1px solid transparent!important;background:${state.accent}!important;color:${paletteButtonText(state.accent)}!important;box-shadow:0 4px 14px #00000012!important;transition:translate .2s,box-shadow .2s;font:600 14px/1.2 Segoe UI,Arial,sans-serif!important;min-height:48px;padding:8px 8px 8px 22px!important;letter-spacing:0;text-decoration:none!important;cursor:pointer}
 .modern-action-button::after{content:'↗';position:static!important;display:grid;place-items:center;flex:0 0 32px;width:32px;height:32px;pointer-events:none;border-radius:50%;background:${paletteButtonText(state.accent)}18;color:inherit;font:20px/1 Arial;transition:transform .2s}
 .modern-action-button.service-info-button{gap:6px!important;padding:6px 8px!important;font-size:12px!important;line-height:1.1!important;white-space:nowrap!important;flex-wrap:nowrap!important}
 .modern-action-button.service-info-button::after{flex-basis:22px;width:22px;height:22px;font-size:15px}
 .modern-action-button.service-info-button[data-service-button-compact="true"]::after{display:none!important}
 @media(hover:hover){.modern-action-button:hover{translate:0 -1px;box-shadow:0 8px 22px #00000020!important}.modern-action-button:hover::after{transform:rotate(45deg)}}
 .modern-action-button:active{translate:0 1px;box-shadow:0 2px 5px #00000012!important}.modern-action-button:focus-visible{outline:3px solid ${state.textColor}!important;outline-offset:5px}
 @media(prefers-reduced-motion:reduce){.modern-action-button,.modern-action-button::after{transition:none}.modern-action-button:hover,.modern-action-button:active{translate:none}}
 `;doc.head.append(style);return serializeRenderedPage(doc)};update();
