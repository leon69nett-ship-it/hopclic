(()=>{
 const editor=document.querySelector('#editor');let scheduled=0;
 const follow=event=>{
  if(event.target.closest('input[type="checkbox"],input[type="radio"]'))return;
  const card=event.target.closest('.block[data-block-id]'),choice=event.target.closest('.content-choice');
  const id=card?.dataset.blockId||choice?.dataset.id;
  if(!id)return;
  // Editing a setting must not recenter a section that is already selected.
  if(!choice&&id===selectedBlockId)return;
  cancelAnimationFrame(scheduled);scheduled=requestAnimationFrame(()=>{
   const block=state.blocks.find(block=>block.id===id);if(!block?.visible)return;
   selectedBlockId=id;highlightPreview(true);
   const doc=previewFrame.contentDocument;
   if(block.type==='services'&&selectedServiceBlockId===id){const service=doc?.querySelector('[data-editor-block="'+id+'"]')?.querySelectorAll('.service-card')[selectedServiceIndex];service?.scrollIntoView({behavior:'smooth',block:'center'})}
  });
 };
 editor.addEventListener('click',follow,true);editor.addEventListener('focusin',follow);
})();
