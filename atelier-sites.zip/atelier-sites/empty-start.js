// A new draft keeps reusable media and a recoverable copy of the previous site.
async function startEmptySite(){
  await window.photoLibraryReady;
  const previous=structuredClone(state);
  const archiveKey=KEY+'-before-empty-'+Date.now();
  try{
    await libraryStore(archiveKey,previous);
    localStorage.setItem(KEY+'-empty-archive',archiveKey);
    const clean=structuredClone(defaults);
    for(const key of ['name','trade','city','phone','email','address','hours'])clean[key]='';
    clean.blocks=clean.blocks.map(block=>({...block,title:'',text:'',visible:false,photos:[]}));
    clean.photoLibrary=[];
    clean.videoLibrary=[];
    state=validate(clean);localStorage.removeItem(KEY+'-welcome-started-v1');
    selectedBlockId=null;
    tab='blocks';
    $('#tabs').querySelectorAll('button').forEach(button=>button.classList.remove('active'));
    librarySelection=null;
    if(typeof selectedLibraryVideoId!=='undefined')selectedLibraryVideoId=null;
    librarySearch='';
    clearTimeout(librarySaveTimer);clearTimeout(videoSaveTimer);
    lastQueuedPhotos=[];lastQueuedVideos=[];
    await libraryStore(KEY,[]);
    await libraryStore(KEY+'-videos',[]);
    localStorage.setItem(KEY,JSON.stringify({...state,photoLibrary:[],videoLibrary:[]}));
    render();update();refreshPreviewWithoutBlink();
    localStorage.setItem(KEY+'-empty-start-v2','1');
    $('#status').textContent='Nouveau site vide, prêt à créer. Une copie du site précédent avec sa bibliothèque est conservée.';
  }catch(error){$('#status').textContent='Impossible de préparer le nouveau site : '+error.message;}
}
const emptyStartButton=document.createElement('button');
emptyStartButton.type='button';
emptyStartButton.textContent='Créer un nouveau site vide';
emptyStartButton.onclick=()=>{
  const dialog=document.createElement('dialog');
  const text=document.createElement('p');text.textContent='Repartir avec un site et une bibliothèque vides ? Une copie du brouillon actuel avec ses médias sera conservée.';
  const confirm=document.createElement('button');confirm.textContent='Repartir de zéro';confirm.onclick=()=>{dialog.close();dialog.remove();startEmptySite()};
  const cancel=document.createElement('button');cancel.textContent='Annuler';cancel.onclick=()=>{dialog.close();dialog.remove()};
  dialog.append(text,confirm,cancel);document.body.append(dialog);dialog.showModal();
};
document.querySelector('aside .tools').append(emptyStartButton);
const restoreEmptyButton=document.createElement('button');
restoreEmptyButton.type='button';restoreEmptyButton.textContent='Restaurer le site précédent';
restoreEmptyButton.onclick=async()=>{
  const archive=localStorage.getItem(KEY+'-empty-archive');
  if(!archive){$('#status').textContent='Aucun site précédent archivé.';return;}
  try{const saved=await libraryStore(archive);if(!saved)throw Error('Copie introuvable');state=validate(saved);selectedBlockId=null;tab='blocks';render();update();$('#status').textContent='Site précédent restauré.'}catch(error){$('#status').textContent=error.message;}
};
document.querySelector('aside .tools').append(restoreEmptyButton);
// Once per browser, replace the old demonstration draft with the requested blank start.

