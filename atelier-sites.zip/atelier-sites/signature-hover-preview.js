let signatureHoverTimer=null,signatureHoverPanel=null;
function closeSignatureHover(){clearTimeout(signatureHoverTimer);signatureHoverTimer=null;signatureHoverPanel?.remove();signatureHoverPanel=null}
const renderBeforeSignatureHover=render;
render=function(){closeSignatureHover();renderBeforeSignatureHover();if(tab!=='design')return;
 for(const card of document.querySelectorAll('.modern-signatures article')){
 const model=modernSignatures.find(m=>m.name===card.querySelector('h3')?.textContent);if(!model)continue;
 card.addEventListener('mouseenter',()=>{if(!matchMedia('(hover:hover)').matches)return;closeSignatureHover();signatureHoverTimer=setTimeout(()=>{
 if(document.querySelector('dialog[open]'))return;
 previewModernSignature(model);const dialog=document.querySelector('dialog[open]');const source=dialog?.querySelector('iframe');if(!source)return;
 const panel=document.createElement('div');panel.className='signature-hover-preview';panel.setAttribute('role','region');panel.setAttribute('aria-label','Aperçu '+model.name);const title=document.createElement('strong');title.textContent=model.name+' · aperçu';const frame=document.createElement('iframe');frame.title='Aperçu '+model.name;frame.setAttribute('sandbox','');frame.srcdoc=source.srcdoc;panel.append(title,frame);dialog.close();
 const cardRect=card.getBoundingClientRect(),width=Math.min(900,cardRect.left-32);if(width<300)return;
 panel.style.width=width+'px';panel.style.left=Math.max(12,cardRect.left-width-18)+'px';document.body.append(panel);signatureHoverPanel=panel;
 },250)});
 card.addEventListener('mouseleave',closeSignatureHover);
 card.addEventListener('click',closeSignatureHover);
 }
};
const signatureHoverStyle=document.createElement('style');signatureHoverStyle.textContent='.signature-hover-preview{position:fixed;top:80px;bottom:24px;z-index:2000;padding:12px;border-radius:20px;background:#fffaf5;border:1px solid #decfc5;box-shadow:0 20px 65px #0003;pointer-events:none;display:flex;flex-direction:column;gap:10px;box-sizing:border-box}.signature-hover-preview>strong{font:700 14px Arial;padding:4px 6px;color:#43352e}.signature-hover-preview iframe{width:100%;flex:1;min-height:0;border:0;border-radius:12px;background:white}@media(max-width:760px){.signature-hover-preview{display:none}}';document.head.append(signatureHoverStyle);window.addEventListener('blur',closeSignatureHover);render();
