// Keep the homepage hero readable and centered in the builder preview and generated site.
(() => {
  const pageBeforeHomePreviewCentering = page;
  page = function () {
    const doc = parseRenderedPage(pageBeforeHomePreviewCentering());
    const style = doc.createElement('style');
    style.id = 'home-preview-centering';
    style.textContent = `
      body>section.hero{
        display:flex!important;
        flex-direction:column!important;
        align-items:center!important;
        text-align:center!important;
      }
      body>section.hero>:is(.eyebrow,h1,p,.actions){
        margin-left:auto!important;
        margin-right:auto!important;
        text-align:center!important;
      }
      body>section.hero>h1,body>section.hero>p{width:min(100%,700px)!important}
      body>section.hero>.actions{justify-content:center!important}
    `;
    doc.head.append(style);
    return serializeRenderedPage(doc);
  };
})();
