function bindServiceTitleShortcut(){
  const doc=previewFrame.contentDocument;if(!doc||doc.serviceTitleShortcutBound)return;doc.serviceTitleShortcutBound=true;
  doc.addEventListener('click',event=>{
    const heading=event.target.closest('.services-section>h2,.services-section>.eyebrow');if(!heading)return;
    const section=heading.closest('[data-editor-block]');
    const block=state.blocks.find(item=>item.id===section?.dataset.editorBlock);if(!block)return;
    event.preventDefault();event.stopImmediatePropagation();
    selectEditorBlock(block.id);render();syncContentMenu();
    const panel=[...document.querySelectorAll('#editor .block')].find(card=>card.dataset.blockId===block.id);
    const label=[...panel.querySelectorAll('label')].find(item=>item.firstChild?.textContent==='Titre');
    const input=label?.querySelector('input');
    if(input){input.placeholder='Nos prestations';input.scrollIntoView({behavior:'instant',block:'center'});input.focus({preventScroll:true});input.select();}
  },true);
}
previewFrame.addEventListener('load',bindServiceTitleShortcut);bindServiceTitleShortcut();
