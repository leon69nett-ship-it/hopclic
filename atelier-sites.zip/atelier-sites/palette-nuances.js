let paletteNuanceMode='original';
function nuanceMix(a,b,t){const x=a.match(/[a-f0-9]{2}/gi).map(v=>parseInt(v,16)),y=b.match(/[a-f0-9]{2}/gi).map(v=>parseInt(v,16));return '#'+x.map((v,i)=>Math.round(v+(y[i]-v)*t).toString(16).padStart(2,'0')).join('')}
function nuancePalette(c,mode){
 if(mode==='original')return [...c];
 const dark=paletteButtonText(c[0])==='#ffffff';
 let bg,surface,accent=c[4];
 if(mode==='soft'){bg=nuanceMix(c[0],dark?'#ffffff':c[4],dark?.88:.12);surface=nuanceMix(bg,'#ffffff',.78);accent=dark?nuanceMix(c[4],'#413029',.55):c[4]}
 if(mode==='rich'){bg=nuanceMix(dark?'#efe8df':c[0],c[4],.26);surface=nuanceMix(bg,'#ffffff',.72);accent=dark?nuanceMix(c[4],'#302926',.55):c[4]}
 if(mode==='night'){bg=nuanceMix(c[4],'#15151b',.87);surface=nuanceMix(c[4],'#24242c',.8);accent=nuanceMix(c[4],'#ffffff',.45)}
 const text=paletteButtonText(bg)==='#ffffff'?'#fff7f0':'#29252b';const secondary=nuanceMix(text,bg,.28),border=nuanceMix(bg,text,.2);
 return [bg,surface,text,secondary,accent,border];
}
const renderBeforePaletteNuances=render;
render=function(){renderBeforePaletteNuances();if(tab!=='design')return;const grid=document.querySelector('.modern-palette-track');if(!grid)return;
 const toolbar=document.createElement('div');toolbar.className='palette-nuance-toolbar';const title=document.createElement('strong');title.textContent='Nuances de chaque palette';toolbar.append(title);
 for(const [id,name]of [['original','Signature'],['soft','Pastel'],['rich','Colorée']]){const b=document.createElement('button');b.type='button';b.textContent=name;b.setAttribute('aria-pressed',String(paletteNuanceMode===id));b.onclick=()=>{paletteNuanceMode=id;render();document.querySelector('.palette-nuance-toolbar')?.scrollIntoView({block:'nearest'})};toolbar.append(b)}grid.before(toolbar);
 [...grid.children].forEach((card,index)=>{const [name,original]=palettes[index],c=nuancePalette(original,paletteNuanceMode);card.style.cssText=`--sample-bg:${c[0]};--sample-surface:${c[1]};--sample-text:${c[2]};--sample-accent:${c[4]}`;
 card.querySelectorAll('.swatches i').forEach((swatch,i)=>swatch.style.background=c[i]);const active=colorKeys.every((k,i)=>state[k].toLowerCase()===c[i].toLowerCase());card.setAttribute('aria-pressed',String(active));card.querySelector('.palette-card-name').textContent=name+(active?' ✓':'');card.onclick=()=>applyPalette(c);
 card.querySelector('.palette-scene-action').style.color=paletteButtonText(c[4]);});
 const hint=document.createElement('p');hint.className='hint';hint.textContent='Changez de nuance pour comparer les aperçus. Cliquez ensuite sur une palette pour l’appliquer à votre site.';toolbar.append(hint);
};
const nuanceStyle=document.createElement('style');nuanceStyle.textContent='.palette-nuance-toolbar{display:flex;flex-wrap:wrap;gap:6px;margin:16px 0 6px}.palette-nuance-toolbar>strong,.palette-nuance-toolbar>.hint{width:100%}.palette-nuance-toolbar>strong{font-size:13px;margin-bottom:6px}.palette-nuance-toolbar>button{flex:1;padding:9px 6px!important;border-radius:20px!important;font-size:11px}.palette-nuance-toolbar>button[aria-pressed=true]{background:var(--ui-accent)!important;color:var(--ui-on-accent)!important}.palette-nuance-toolbar>.hint{margin:6px 0}';document.head.append(nuanceStyle);render();

