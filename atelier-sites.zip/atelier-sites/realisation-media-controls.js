
const galleryBeforeMediaControls=renderGalleryPhotos;
renderGalleryPhotos=function(card,block){galleryBeforeMediaControls(card,block);const picker=card.querySelector('.gallery-library-picker');if(!picker)return;const oldVideoGroup=[...picker.children].find(node=>node.querySelector('h4')?.textContent.includes('Vidéos de cette réalisation'));picker.replaceChildren();const title=document.createElement('h3');title.textContent='Photos et vidéos de cette réalisation';picker.append(title);const addChoice=(caption,text,action)=>{const label=document.createElement('label');label.textContent=caption;const button=document.createElement('button');button.type='button';button.textContent=text;button.style.cssText='display:block;width:100%;text-align:left;margin-top:6px;min-height:40px';button.onclick=action;label.append(button);picker.append(label)};const windowCount=Math.max(1,Math.min(3,Number(block.galleryWindows)||3));const photoChoice=block.galleryMode==='slideshow'?'Choisir des photos…':'Choisir '+windowCount+' '+(windowCount===1?'photo…':'photos…');const videoChoice=block.galleryMode==='slideshow'?'Choisir des vidéos…':'Choisir '+windowCount+' '+(windowCount===1?'vidéo…':'vidéos…');addChoice('Photos de la bibliothèque',photoChoice,()=>openGalleryPhotoSelection(card,block));addChoice('Vidéos de la bibliothèque',videoChoice,()=>chooseLibraryVideos(block,()=>renderGalleryPhotos(card,block)));const counts=document.createElement('p');counts.className='hint';counts.textContent=galleryLibraryPhotos(block).length+' photo(s) et '+(block.galleryVideos||[]).filter(video=>video.libraryId||video.videoUrl||video.videoIframe).length+' vidéo(s) sélectionnées.';picker.append(counts);const upload=(kind)=>{const button=document.createElement('button');button.type='button';button.textContent=kind==='photo'?'📥 Importer une photo depuis mon PC':'📥 Importer une vidéo depuis mon PC';button.style.cssText='display:block;width:100%;min-height:42px;margin:8px 0';const input=document.createElement('input');input.type='file';input.multiple=true;input.hidden=true;input.accept=kind==='photo'?'image/png,image/jpeg,image/webp':'video/mp4,video/webm';button.disabled=kind==='photo'?!libraryReady:!videosReady;button.onclick=()=>input.click();input.onchange=async()=>{if(!input.files.length)return;button.disabled=true;try{if(kind==='photo'){if(!Array.isArray(block.galleryPhotoIds))block.galleryPhotoIds=galleryLibraryPhotos(block).map(photo=>photo.id);await importLibraryPhotos([...input.files],block)}else{await importVideoFiles([...input.files],block)}renderGalleryPhotos(card,block)}catch(error){$('#status').textContent=error.message;button.disabled=false}};picker.append(button,input)};upload('photo');upload('video');const note=document.createElement('p');note.className='hint';note.textContent='Les médias importés sont ajoutés à leur bibliothèque et peuvent être réutilisés sans doublon.';picker.append(note);addOnlineRealisationPhoto(picker,card,block);const advanced=document.createElement('details');const summary=document.createElement('summary');summary.textContent='Modifier les vidéos sélectionnées ou ajouter un lien';advanced.append(summary);if(oldVideoGroup)advanced.append(oldVideoGroup);picker.append(advanced);};
render();

let selectedRealisationPhotoId=null;
window.openRealisationWindowEditor=function(block,index){
 const photo=galleryLibraryPhotos(block)[index];
 selectedGalleryIndex=index;selectedRealisationPhotoId=photo?.id||null;
 selectEditorBlock(block.id,true);
 const editorCard=[...document.querySelectorAll('#editor .block')].find(card=>card.dataset.blockId===block.id);
 if(editorCard)renderGalleryPhotos(editorCard,block);
 const panel=document.querySelector('.realisation-window-texts');
 panel?.scrollIntoView({behavior:'smooth',block:'center'});
 panel?.querySelector('input')?.focus({preventScroll:true});
};
const galleryBeforeWindowTexts=renderGalleryPhotos;
renderGalleryPhotos=function(card,block){
 galleryBeforeWindowTexts(card,block);
 card.querySelector('.realisation-window-texts')?.remove();
 const photos=galleryLibraryPhotos(block),photo=photos.find(photo=>photo.id===selectedRealisationPhotoId);
 if(!photo)return;
 const index=photos.indexOf(photo),panel=document.createElement('div'),heading=document.createElement('h3');
 panel.className='realisation-window-texts';
 const color=state.selectionColor||state.accent;
 panel.style.cssText='padding:14px;border:2px solid '+color+';border-radius:10px;background:color-mix(in srgb,'+color+' 10%,white);margin:14px 0';
 heading.textContent='Fenêtre '+(index+1)+' — Textes à modifier';heading.style.color=color;panel.append(heading);
 for(const [key,caption] of [['title','Titre de la réalisation'],['description','Description de la réalisation']]){
  const label=document.createElement('label');label.textContent=caption;
  const input=document.createElement(key==='title'?'input':'textarea');input.value=photo[key]||'';
  if(key==='description')input.rows=3;
  input.style.cssText='display:block;width:100%;box-sizing:border-box;margin:6px 0 12px';
  if(key==='title')label.style.cssText='color:'+color+';font-weight:700';
  input.oninput=()=>{photo[key]=input.value;update()};label.append(input);panel.append(label);
 }
 const picker=card.querySelector('.gallery-library-picker');if(picker)picker.prepend(panel);
};
render();

const galleryBeforePresentationOrder=renderGalleryPhotos;
renderGalleryPhotos=function(card,block){
 galleryBeforePresentationOrder(card,block);
 const choices=card.querySelector('.gallery-window-choices'),picker=card.querySelector('.gallery-library-picker');
 if(choices&&picker)choices.after(picker);
};
render();

const galleryBeforeWindowCountPosition=renderGalleryPhotos;renderGalleryPhotos=function(card,block){galleryBeforeWindowCountPosition(card,block);const panel=card.querySelector('.realisation-window-texts'),label=card.querySelector('.window-count-label'),choices=card.querySelector('.gallery-window-choices');if(panel&&label&&choices)panel.after(label,choices)};render();
