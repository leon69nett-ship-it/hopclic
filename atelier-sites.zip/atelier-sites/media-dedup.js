const importedPhotoHashes=new Map();

// Compare file contents, rather than names, before converting an imported photo.
const optimisePhotoBeforeDedup=optimiseLibraryPhoto;
optimiseLibraryPhoto=async function(file){await window.photoLibraryReady;const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer())),b=>b.toString(16).padStart(2,'0')).join('');let existing=state.photoLibrary.find(photo=>photo.sourceHash===hash);if(existing){$('#status').textContent='Photo déjà présente : utilisation de celle de la bibliothèque.';return existing}const photo=await optimisePhotoBeforeDedup(file);existing=state.photoLibrary.find(item=>item.src===photo.src);if(existing){existing.sourceHash=hash;$('#status').textContent='Photo déjà présente : utilisation de celle de la bibliothèque.';return existing}photo.sourceHash=hash;importedPhotoHashes.set(photo.src,hash);return photo};
const saveVideoBeforeDedup=saveLibraryVideo;
saveLibraryVideo=async function(video){const existing=state.videoLibrary.find(item=>(video.videoUrl&&item.videoUrl===video.videoUrl)||(video.videoIframe&&item.videoIframe===video.videoIframe));if(existing){$('#status').textContent='Vidéo déjà présente : utilisation de celle de la bibliothèque.';return existing}return saveVideoBeforeDedup(video)};

// The service upload has its own reduction dialog: check the library before opening it.
const offerReductionBeforeLibraryReuse=offerPhotoReduction;
offerPhotoReduction=async function(input,parent,apply){const file=input.files?.[0];if(!file)return;try{const candidate=await optimiseLibraryPhoto(file);const existing=state.photoLibrary.find(photo=>photo.id===candidate.id||photo.src===candidate.src||candidate.sourceHash&&photo.sourceHash===candidate.sourceHash);if(existing){apply(existing.src);$('#status').textContent='Photo déjà présente : celle de la bibliothèque a été réutilisée, sans doublon.';return}return offerReductionBeforeLibraryReuse(input,parent,async src=>{await cacheSitePhoto(src,file.name.replace(/\.[^.]+$/,''));const stored=state.photoLibrary.find(photo=>photo.src===src);if(stored){stored.sourceHash=candidate.sourceHash;await libraryStore(KEY,structuredClone(state.photoLibrary))}apply(stored?.src||src)})}catch(error){$('#status').textContent=error.message}};

const cachePhotoBeforeHash=cacheSitePhoto;
cacheSitePhoto=async function(source,title){await cachePhotoBeforeHash(source,title);const item=state.photoLibrary.find(photo=>photo.src===source||photo.originalUrl===source);const hash=importedPhotoHashes.get(source);if(item&&hash&&item.sourceHash!==hash){item.sourceHash=hash;await libraryStore(KEY,structuredClone(state.photoLibrary))}};
// Legacy originals may have been stored without optimisation or a source fingerprint.
const optimiseBeforeLegacyReuse=optimiseLibraryPhoto;
optimiseLibraryPhoto=async function(file){await window.photoLibraryReady;const raw=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('Lecture impossible.'));reader.readAsDataURL(file)});const original=state.photoLibrary.find(photo=>photo.src===raw);if(original){$('#status').textContent='Photo déjà présente : utilisation de celle de la bibliothèque.';return original}return optimiseBeforeLegacyReuse(file)};
