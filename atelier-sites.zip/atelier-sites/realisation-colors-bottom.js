const renderBeforeRealisationColorsBottom=render;
render=function(){
 renderBeforeRealisationColorsBottom();
 if(tab!=='blocks')return;
 for(const card of document.querySelectorAll('#editor .block')){
  const colors=card.querySelector('.realisation-colors-disclosure');
  if(colors)card.append(colors);
 }
};
render();update();
