const serviceFieldsBeforeAlignedControls=addServicePhotoFields;
addServicePhotoFields=function(fields,block,index){
 serviceFieldsBeforeAlignedControls(fields,block,index);
 const buttons=[...fields.querySelectorAll('button')];
 const photoChoice=buttons.find(button=>/Choisir une photo/.test(button.textContent));
 const videoChoice=buttons.find(button=>/Choisir une vidéo/.test(button.textContent));
 const photoUpload=buttons.find(button=>/Importer une photo depuis mon PC/.test(button.textContent));
 const videoUpload=buttons.find(button=>/Importer une vidéo depuis mon PC/.test(button.textContent));
 const group=document.createElement('div');group.className='service-aligned-media-controls';group.style.cssText='display:grid;gap:10px;margin:14px 0';
 const addChoice=(button,caption,text)=>{if(!button)return;const label=document.createElement('label');label.textContent=caption;label.style.margin='0';button.textContent=text;button.style.cssText='display:block;width:100%;text-align:left;margin:6px 0 0;min-height:40px';label.append(button);group.append(label)};
 addChoice(photoChoice,'Photo de la bibliothèque','Choisir une photo…');addChoice(videoChoice,'Vidéo de la bibliothèque','Choisir une vidéo…');
 const oldFileLabel=photoUpload?.closest('label');
 for(const button of [photoUpload,videoUpload])if(button){button.style.cssText='display:block;width:100%;text-align:left;margin:0;min-height:42px';group.append(button)}
 if(oldFileLabel){for(const node of [...oldFileLabel.childNodes])if(node.nodeType===3)node.remove();oldFileLabel.hidden=true}
 const online=[...fields.querySelectorAll('label')].find(label=>label.textContent.startsWith('Ou adresse HTTPS'));
 if(online)online.before(group);else fields.append(group);
};render();
