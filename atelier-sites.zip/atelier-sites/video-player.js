const pageBeforeProVideo=page;
page=function(){
 const doc=parseRenderedPage(pageBeforeProVideo());
 for(const video of doc.querySelectorAll('video')){
  if(video.closest('.service-card-video-thumb,.service-info-dialog,.photo-viewer'))continue;
  const player=doc.createElement('div');player.className='pro-video-player';
  video.before(player);player.append(video);video.controls=true;video.preload='metadata';video.setAttribute('playsinline','');video.removeAttribute('autoplay');
  const play=doc.createElement('button');play.type='button';play.className='pro-video-play';play.setAttribute('aria-label','Lire la vidéo');play.innerHTML='<span aria-hidden="true">▶</span><strong>À vous de regarder</strong>';
  play.setAttribute('onclick',"event.preventDefault();event.stopPropagation();const b=this,v=this.parentElement.querySelector('video');v.play().then(()=>{b.hidden=true}).catch(()=>{b.hidden=true;v.focus()})");
  video.setAttribute('onplay',"this.parentElement.querySelector('.pro-video-play').hidden=true");
  video.setAttribute('onended',"this.parentElement.querySelector('.pro-video-play').hidden=false");
  player.append(play);
 }
 const style=doc.createElement('style');style.textContent=`
 .pro-video-player{position:relative;isolation:isolate;width:100%;max-width:100%;aspect-ratio:16/9;border-radius:16px;overflow:hidden;background:radial-gradient(ellipse at top right,${state.accent}55,transparent 65%),#171310;box-shadow:0 12px 28px #25130c24;border:1px solid ${state.borderColor}}
 .pro-video-player>video{display:block!important;position:absolute;inset:0;width:100%!important;height:100%!important;max-height:none!important;object-fit:contain!important;background:transparent!important;border-radius:0!important}
 .pro-video-play{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;width:100%;height:calc(100% - 42px);border:0!important;border-radius:0!important;background:linear-gradient(transparent,#0004)!important;color:#fff!important;cursor:pointer;padding:12px!important}
 .pro-video-play>span{display:grid;place-items:center;width:64px;height:64px;padding-left:4px;box-sizing:border-box;border-radius:50%;font:24px Arial;background:${state.accent};box-shadow:0 0 0 8px #ffffff1f,0 8px 24px #0005;transition:transform .2s}
 .pro-video-play:hover>span{transform:scale(1.08)}.pro-video-play>strong{font:600 13px Arial;text-shadow:0 1px 4px #000}
 .pro-video-play:focus-visible{outline:3px solid #fff!important;outline-offset:-5px}.pro-video-play[hidden]{display:none!important}
 @media(max-width:600px){.pro-video-player{border-radius:10px}.pro-video-play>span{width:48px;height:48px;font-size:18px}.pro-video-play>strong{display:none}}
 @media(prefers-reduced-motion:reduce){.pro-video-play>span{transition:none}}
 `;doc.head.append(style);return serializeRenderedPage(doc);
};
update();
