palettes.push(
 ['Corail vitaminé',['#fff3ee','#ffffff','#44241e','#795047','#b63b28','#efc7bb']],
 ['Lagon tropical',['#edfafa','#ffffff','#143d41','#40696c','#087978','#b9dddd']],
 ['Lavande créative',['#f6f0ff','#ffffff','#332344','#69527c','#7740a5','#dcc9ee']],
 ['Citron pop',['#fffce7','#ffffff','#363015','#716337','#756500','#e7df9f']],
 ['Framboise pétillante',['#fff0f6','#ffffff','#492237','#80566b','#ad235c','#efbfd4']],
 ['Azur vacances',['#eef6ff','#ffffff','#20364c','#4c6983','#1266b4','#c2daf0']],
 ['Abricot solaire',['#fff5e9','#ffffff','#4b2d1b','#805c42','#a94d12','#eed1b0']]
);
const renderBeforeCardImportDesign=render;
render=function(){
 renderBeforeCardImportDesign();if(tab!=='design')return;
 for(const label of document.querySelectorAll('#editor label')){
  if(!label.textContent.includes('Utiliser les couleurs de ma carte de visite'))continue;
  const check=label.querySelector('input[type=checkbox]');if(!check)continue;
  const original=check.onchange;check.disabled=false;
  const file=document.createElement('input');file.type='file';file.accept='image/png,image/jpeg,image/webp';file.hidden=true;label.after(file);
  const hint= file.nextElementSibling;if(hint?.classList.contains('hint')&&!state.businessCard)hint.textContent='Cochez cette option pour choisir votre carte de visite sur votre PC et appliquer ses couleurs.';
  check.onchange=event=>{
   if(state.businessCard||!check.checked){original?.call(check,event);return}
   check.checked=false;file.click();
  };
  file.onchange=async()=>{
   const selected=file.files[0];if(!selected)return;
   check.disabled=true;
   try{
    if(!['image/png','image/jpeg','image/webp'].includes(selected.type)||selected.size>25000000)throw Error('Choisissez une carte PNG, JPEG ou WebP de 25 Mo maximum.');
    const data=(await optimiseLibraryPhoto(selected)).src;await colorsFromCard(data);
    state.businessCard=data;check.checked=true;await original?.call(check,new Event('change'));
   }catch(error){document.querySelector('#status').textContent=error.message;check.checked=state.useCardColors===true}
   finally{check.disabled=false;file.value=''}
  };
 }
};
render();
