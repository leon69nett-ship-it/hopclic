// Browsers supporting the file picker API can start media imports in Downloads.
document.addEventListener('click',async event=>{
  const input=event.target;
  if(!(input instanceof HTMLInputElement)||input.type!=='file')return;
  if(!/image|video|\.png|\.jpe?g|\.webp|\.mp4|\.webm/i.test(input.accept))return;
  if(typeof window.showOpenFilePicker!=='function')return;
  event.preventDefault();
  try{
    const handles=await window.showOpenFilePicker({startIn:'downloads',multiple:input.multiple});
    const files=await Promise.all(handles.map(handle=>handle.getFile()));
    const transfer=new DataTransfer();files.forEach(file=>transfer.items.add(file));
    input.files=transfer.files;
    input.dispatchEvent(new Event('change',{bubbles:true}));
  }catch(error){
    if(error.name!=='AbortError'){
      const status=document.querySelector('#status');
      if(status)status.textContent='Ouverture des fichiers impossible. Réessayez ou vérifiez les autorisations du navigateur.';
    }
  }
},true);
