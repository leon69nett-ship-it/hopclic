function attachContextualTextHelp(){
 for(const input of document.querySelectorAll('#editor textarea,#editor input[type="text"],#editor input:not([type])')){
  const label=input.closest('label');if(!label||input.dataset.aiHelpAttached)continue;
  const caption=[...label.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join(' ').trim();
  if(!caption||/HTML|script|code|adresse|e-mail|téléphone|URL|HTTPS|mot-clé|prestation par ligne/i.test(caption))continue;
  if(input.tagName!=='TEXTAREA'&&!/titre|description|présentation/i.test(caption))continue;
  TextHelp.attach(input,caption);
 }
}
const renderBeforeContextualAI=render;
render=function(){renderBeforeContextualAI();attachContextualTextHelp()};
const serviceBeforeContextualAI=renderServiceItems;
renderServiceItems=function(card,block){serviceBeforeContextualAI(card,block);attachContextualTextHelp()};
addLibraryAIButton=function(parent,photo){
 const button=document.createElement('button');button.type='button';button.textContent='✨ Décrire cette photo';
 button.onclick=()=>{
  const dialog=document.createElement('dialog');dialog.className='text-help-dialog';
  const title=document.createElement('h2');title.textContent='Décrire cette photo';
  const image=document.createElement('img');image.src=photo.src;image.alt=photo.title||'Photo sélectionnée';image.style.cssText='display:block;width:100%;max-height:200px;object-fit:contain';
  const notice=document.createElement('p');notice.textContent='Générer transmet cette photo à Cloudflare. Relisez la proposition avant de cliquer sur Appliquer.';
  const fields={};for(const [key,caption]of [['title','Titre'],['description','Description'],['keywords','Mots-clés']]){const label=document.createElement('label');label.textContent=caption;const input=document.createElement(key==='description'?'textarea':'input');input.value=photo[key]||'';label.append(input);fields[key]=input;dialog.append(label)}
  const status=document.createElement('p');status.setAttribute('role','status');
  const generate=document.createElement('button');generate.type='button';generate.textContent='Générer';
  const apply=document.createElement('button');apply.type='button';apply.textContent='Appliquer';apply.disabled=true;
  generate.onclick=async()=>{generate.disabled=true;apply.disabled=true;status.textContent='Analyse en cours…';try{const result=await describeLibraryPhoto(photo);for(const key of Object.keys(fields))fields[key].value=result[key]||'';apply.disabled=false;status.textContent='Relisez et ajustez la proposition.'}catch(error){status.textContent=error.message}finally{generate.disabled=false}};
  apply.onclick=()=>{for(const key of Object.keys(fields))photo[key]=fields[key].value;update();dialog.close();render()};
  const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Annuler';cancel.onclick=()=>dialog.close();
  dialog.prepend(title,image,notice);dialog.append(status,generate,apply,cancel);dialog.addEventListener('close',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
 };parent.append(button);
};
render();
