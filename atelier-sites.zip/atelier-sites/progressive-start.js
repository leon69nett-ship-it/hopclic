async function prepareProgressiveStart(){
  if(!CLIENT||localStorage.getItem(KEY+'-progressive-start-v1'))return;
  await window.photoLibraryReady;
  // Preserve all content: only the display flags are reset.
  await libraryStore(KEY+'-before-progressive-start',structuredClone(state));
  for(const block of state.blocks)block.visible=false;
  selectedBlockId=null;tab='blocks';
  localStorage.removeItem(KEY+'-welcome-started-v1');
  localStorage.setItem(KEY+'-progressive-start-v1','1');
  render();update();refreshPreviewWithoutBlink();
}
prepareProgressiveStart().catch(()=>{$('#status').textContent='Le démarrage n’a pas pu être préparé. Vos contenus sont conservés.'});
