// Make the existing local photo upload clear and easy to use on a phone.
const renderPhotoLibraryBeforeMobileUpload = renderPhotoLibrary;
renderPhotoLibrary = function () {
  renderPhotoLibraryBeforeMobileUpload();
  const upload = document.querySelector('#editor .library-upload');
  if (upload) {
    const input = upload.querySelector('input[type="file"]');
    const mobile = window.matchMedia('(max-width: 760px) and (pointer: coarse)').matches;
    if (upload.firstChild?.nodeType === Node.TEXT_NODE) {
      upload.firstChild.nodeValue = mobile ? '📷 Ajouter des photos depuis mon téléphone' : '📥 Ajouter des photos depuis cet appareil';
    }
    if (input) input.setAttribute('aria-label', mobile ? 'Choisir des photos sur mon téléphone' : 'Choisir des photos sur cet appareil');
  }

  // On a phone the real photo picker above replaces the PC-side transfer demo.
  const phoneDemo = document.querySelector('#editor .phone-demo-launch');
  if (phoneDemo && window.matchMedia('(max-width: 760px) and (pointer: coarse)').matches) phoneDemo.hidden = true;
};
