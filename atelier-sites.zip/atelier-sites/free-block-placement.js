// Position libre des boutons dans les blocs de l'aperçu.
(() => {
  // Direct manipulation is always available in the editor preview.
  let placementMode = true;
  let activeDrag = null;
  let suppressClickOn = null;

  const placementKey = (kind, index) => `${kind}-${index}`;
  const serviceCardFor = target => target.matches('.service-info-button') ? target.closest('.service-card') : null;
  const responsiveCopySelector = '.hero-copy,.habitat-hero-copy,.meta-hero-copy,.service-copy,.actions,.template-hero-actions,.meta-actions,.habitat-hero-actions';
  const isServiceCardAnchor = anchor => anchor === 'service-card' || anchor === 'service-card-centered';
  const isResponsiveCopyAnchor = anchor => anchor === 'responsive-copy';
  const responsiveCopyFor = target => target.closest(responsiveCopySelector);
  // Buttons can move across their whole block; service detail links stay in their card.
  const placementBasisFor = (target, section) => serviceCardFor(target) || section;
  const applyServiceButtonWidthLimit = target => {
    if (!target.matches('.service-info-button')) return;
    const card = serviceCardFor(target);
    const copy = target.closest('.service-copy') || card;
    if (!card || !copy) return;
    const scale = Number.parseFloat(target.style.scale) || 1;
    const copyStyle = target.ownerDocument.defaultView.getComputedStyle(copy);
    const available = Math.max(40, copy.clientWidth - (parseFloat(copyStyle.paddingLeft) || 0) - (parseFloat(copyStyle.paddingRight) || 0));
    const preferred = Number(target.dataset.serviceButtonPreferredWidth)
      || Number.parseFloat(target.style.width)
      || 190;
    target.dataset.serviceButtonPreferredWidth = String(preferred);
    const canvas = target.ownerDocument.createElement('canvas');
    const context = canvas.getContext('2d');
    if (context) context.font = '600 12px Segoe UI, Arial, sans-serif';
    const labelText = [...target.childNodes].filter(node => node.nodeType === 3).map(node => node.textContent).join('').trim();
    const labelWidth = context?.measureText(labelText).width || 84;
    const minimumWithIcon = Math.ceil(labelWidth + 22 + 6 + 16 + 2);
    const compact = available / scale < minimumWithIcon;
    target.dataset.serviceButtonCompact = String(compact);
    const minimum = Math.min(available / scale, compact ? labelWidth + 18 : minimumWithIcon);
    const width = Math.max(40, Math.min(available / scale, Math.max(minimum, Math.min(preferred, available / scale))));
    target.style.setProperty('width', `${width}px`, 'important');
    target.style.setProperty('min-width', `${width}px`, 'important');
    target.style.setProperty('max-width', `${width}px`, 'important');
    target.style.setProperty('box-sizing', 'border-box', 'important');
    // Auto margins cannot center an inline flex button. Make it a block-level flex box.
    target.style.setProperty('display', 'flex', 'important');
    target.style.setProperty('gap', '6px', 'important');
    target.style.setProperty('padding-left', '8px', 'important');
    target.style.setProperty('padding-right', '8px', 'important');
    target.style.setProperty('white-space', 'nowrap', 'important');
    target.style.setProperty('min-height', '40px', 'important');
    target.style.setProperty('font-size', '12px', 'important');
    target.style.setProperty('line-height', '1.1', 'important');
    target.style.setProperty('margin-left', 'auto', 'important');
    target.style.setProperty('margin-right', 'auto', 'important');
  };
  const isResizableButton = target => !target.matches('.checkout-auth-button,.interactive-photo-point,.preview-block-resize,.preview-block-move')
    && !target.closest('.checkout-auth-options')
    && (target.dataset.siteButtonStyleTarget === 'true'
    || target.matches('[data-home-cta],[data-custom-site-button]')
    || target.matches('button,[role="button"]')
    || (target.matches('a[href]') && target.matches('.btn,.button,[class*="button"],[class*="action"],[class*="cta"]')));
  const snapButtonX = (target, section, x, y, threshold = 22) => {
    if (!isResizableButton(target)) return x;
    const sectionRect = section.getBoundingClientRect();
    const style = section.ownerDocument.defaultView.getComputedStyle(section);
    const left = sectionRect.left + section.clientLeft + (parseFloat(style.paddingLeft) || 0);
    const right = sectionRect.left + section.clientLeft + section.clientWidth - (parseFloat(style.paddingRight) || 0);
    if (right <= left) return x;

    target.style.translate = `${sectionRect.width * x / 100}px ${sectionRect.height * y / 100}px`;
    const buttonRect = target.getBoundingClientRect();
    const width = buttonRect.width;
    const alignments = [left, (left + right - width) / 2, right - width];
    const nearest = alignments.reduce((best, position) =>
      Math.abs(position - buttonRect.left) < Math.abs(best - buttonRect.left) ? position : best, alignments[0]);
    if (Math.abs(nearest - buttonRect.left) > threshold) return x;
    return Math.max(-100, Math.min(100, x + (nearest - buttonRect.left) / sectionRect.width * 100));
  };
  const buttonGroupFor = target => target.closest('.custom-site-actions,.template-hero-actions,.meta-actions,.habitat-hero-actions,.actions,.project-comparison-actions');
  const relatedButtons = (target, section) => {
    const group = buttonGroupFor(target);
    if (!group) return [];
    return [...section.querySelectorAll('a[href],button,[role="button"]')].filter(other => {
      if (other === target || !isResizableButton(other) || other.closest('.site-button-controls,dialog,.preview-block-tools')) return false;
      return buttonGroupFor(other) === group;
    });
  };
  const snapButtonToPeer = (target, section, x, y) => {
    const sectionRect = section.getBoundingClientRect();
    target.style.translate = `${sectionRect.width * x / 100}px ${sectionRect.height * y / 100}px`;
    const rect = target.getBoundingClientRect();
    let best = { x, y, distance: Infinity };
    for (const peer of relatedButtons(target, section)) {
      const peerRect = peer.getBoundingClientRect();
      const peerCenterX = peerRect.left + peerRect.width / 2;
      const peerCenterY = peerRect.top + peerRect.height / 2;
      const horizontalOptions = [peerRect.right + 16, peerRect.left - rect.width - 16];
      for (const left of horizontalOptions) {
        const dx = left - rect.left;
        const dy = peerCenterY - (rect.top + rect.height / 2);
        const distance = Math.hypot(dx, dy);
        if (Math.abs(dy) <= 30 && Math.abs(dx) <= Math.max(100, rect.width * .8) && distance < best.distance) {
          best = { x: Math.max(-100, Math.min(100, x + dx / sectionRect.width * 100)), y: Math.max(-100, Math.min(100, y + dy / sectionRect.height * 100)), distance };
        }
      }
      const verticalOptions = [peerRect.bottom + 16, peerRect.top - rect.height - 16];
      for (const top of verticalOptions) {
        const dx = peerCenterX - (rect.left + rect.width / 2);
        const dy = top - rect.top;
        const distance = Math.hypot(dx, dy);
        if (Math.abs(dx) <= 30 && Math.abs(dy) <= Math.max(80, rect.height * 1.5) && distance < best.distance) {
          best = { x: Math.max(-100, Math.min(100, x + dx / sectionRect.width * 100)), y: Math.max(-100, Math.min(100, y + dy / sectionRect.height * 100)), distance };
        }
      }
    }
    return best.distance < Infinity ? best : null;
  };
  const buttonScale = target => target.matches('[data-home-cta]')
    ? Number(target.dataset.homeCtaScale) || 1
    : target.matches('[data-custom-site-button]')
      ? Number(target.dataset.customScale) || 1
      : Number(target.dataset.freePlacementScale) || 1;
  const setButtonScale = (target, scale) => {
    const bounded = Math.max(target.matches('[data-home-cta]') ? .55 : .65, Math.min(target.matches('[data-home-cta]') ? 1.5 : 1.8, scale));
    if (target.matches('[data-home-cta]')) target.dataset.homeCtaScale = String(bounded);
    else if (target.matches('[data-custom-site-button]')) target.dataset.customScale = String(bounded);
    else target.dataset.freePlacementScale = String(bounded);
    const siteScale = Math.max(60, Math.min(130, Number(state.siteButtonScale) || 100)) / 100;
    target.style.setProperty('scale', String(siteScale * bounded), 'important');
    applyServiceButtonWidthLimit(target);
    return bounded;
  };
  const alignResizedGroup = (drag, scale) => {
    const members = [drag.target, ...drag.scaleGroup.map(item => item.target)];
    for (const member of members) setButtonScale(member, scale);
    if (members.length < 2) return;
    const sharedWidth = Math.max(...members.map(member => member.offsetWidth));
    const sharedHeight = Math.max(...members.map(member => member.offsetHeight));
    for (const member of members) {
      member.style.setProperty('box-sizing', 'border-box', 'important');
      member.style.setProperty('width', `${sharedWidth}px`, 'important');
      member.style.setProperty('height', `${sharedHeight}px`, 'important');
    }
    if (buttonGroupFor(drag.target)?.matches('.project-comparison-actions')) {
      for (const member of members) {
        member.dataset.freePlacementX = '0';
        member.dataset.freePlacementY = '0';
        member.style.translate = '0px 0px';
      }
      return;
    }
    const sectionRect = drag.section.getBoundingClientRect();
    const sectionStyle = drag.section.ownerDocument.defaultView.getComputedStyle(drag.section);
    const contentLeft = sectionRect.left + drag.section.clientLeft + (parseFloat(sectionStyle.paddingLeft) || 0);
    const contentRight = sectionRect.left + drag.section.clientLeft + drag.section.clientWidth - (parseFloat(sectionStyle.paddingRight) || 0);
    const rects = new Map(members.map(member => [member, member.getBoundingClientRect()]));
    const totalWidth = members.reduce((sum, member) => sum + rects.get(member).width, 0) + (members.length - 1) * 16;
    const horizontal = totalWidth <= contentRight - contentLeft;
    const targetRect = rects.get(drag.target);
    const orderOf = member => member === drag.target ? drag.targetOrder : drag.scaleGroup.find(item => item.target === member)?.order;
    const ordered = members.sort((a, b) => orderOf(a) - orderOf(b));
    const targetIndex = ordered.indexOf(drag.target);
    let cursor = horizontal ? targetRect.left : targetRect.top;
    for (let index = targetIndex - 1; index >= 0; index--) {
      const peer = ordered[index];
      const rect = rects.get(peer);
      cursor -= (horizontal ? rect.width : rect.height) + 16;
      const left = horizontal ? cursor : targetRect.left + (targetRect.width - rect.width) / 2;
      const top = horizontal ? targetRect.top + (targetRect.height - rect.height) / 2 : cursor;
      const current = peer.getBoundingClientRect();
      const x = Math.max(-100, Math.min(100, (Number(peer.dataset.freePlacementX) || 0) + (left - current.left) / sectionRect.width * 100));
      const y = Math.max(-100, Math.min(100, (Number(peer.dataset.freePlacementY) || 0) + (top - current.top) / sectionRect.height * 100));
      peer.dataset.freePlacementX = String(x); peer.dataset.freePlacementY = String(y);
      peer.style.translate = `${sectionRect.width * x / 100}px ${sectionRect.height * y / 100}px`;
    }
    cursor = horizontal ? targetRect.right : targetRect.bottom;
    for (let index = targetIndex + 1; index < ordered.length; index++) {
      const peer = ordered[index];
      const rect = rects.get(peer);
      const left = horizontal ? cursor + 16 : targetRect.left + (targetRect.width - rect.width) / 2;
      const top = horizontal ? targetRect.top + (targetRect.height - rect.height) / 2 : cursor + 16;
      const current = peer.getBoundingClientRect();
      const x = Math.max(-100, Math.min(100, (Number(peer.dataset.freePlacementX) || 0) + (left - current.left) / sectionRect.width * 100));
      const y = Math.max(-100, Math.min(100, (Number(peer.dataset.freePlacementY) || 0) + (top - current.top) / sectionRect.height * 100));
      peer.dataset.freePlacementX = String(x); peer.dataset.freePlacementY = String(y);
      peer.style.translate = `${sectionRect.width * x / 100}px ${sectionRect.height * y / 100}px`;
      cursor = horizontal ? left + rect.width : top + rect.height;
    }
  };
  const normalisePlacements = placements => {
    if (!placements || typeof placements !== 'object' || Array.isArray(placements)) return {};
    const result = {};
    for (const [key, value] of Object.entries(placements)) {
      if (!/^(image-\d+|bouton-(?:\d+|custom-[\w-]+))$/.test(key) || !value || typeof value !== 'object') continue;
      const x = Number(value.x);
      const y = Number(value.y);
      if (!Number.isFinite(x) || !Number.isFinite(y)) continue;
      const scale = Number(value.scale);
      result[key] = {
        x: Math.max(-100, Math.min(100, x)),
        y: Math.max(-100, Math.min(100, y)),
        ...(Number.isFinite(scale) ? { scale: Math.max(.5, Math.min(1.8, scale)) } : {}),
        ...(isServiceCardAnchor(value.anchor) || isResponsiveCopyAnchor(value.anchor) ? { anchor: value.anchor } : {}),
        ...(Number.isFinite(Number(value.width)) ? { width: Math.max(40, Math.min(900, Number(value.width))) } : {}),
        ...(Number.isFinite(Number(value.height)) ? { height: Math.max(30, Math.min(500, Number(value.height))) } : {})
      };
    }
    return result;
  };

  // Preserve placement coordinates when a project is imported or restored.
  if (typeof validate === 'function') {
    const validateBeforeFreePlacement = validate;
    validate = function (saved) {
      const result = validateBeforeFreePlacement(saved);
      if (Array.isArray(saved?.blocks)) {
        result.blocks.forEach((block, index) => {
          block.freePlacements = normalisePlacements(saved.blocks[index]?.freePlacements);
        });
      }
      return result;
    };
  }

  const placementPage = page;
  page = function () {
    const doc = new DOMParser().parseFromString(placementPage(), 'text/html');
    const blocks = state.blocks.filter(block => block.visible);
    const sections = [...doc.querySelectorAll('body > section:not(.business-card)')];

    sections.forEach((section, sectionIndex) => {
      const block = blocks[sectionIndex];
      if (!block) return;
      const placements = normalisePlacements(block.freePlacements);
      let buttonIndex = 0;
    const targets = [...section.querySelectorAll('a[href], button, [role="button"]')].filter(isResizableButton);

      for (const target of targets) {
        if (target.closest('.site-menu, .site-menu-toggle, dialog, .preview-block-tools, .author-credit')) continue;
        const generatedKey = placementKey('bouton', buttonIndex++);
        const key = target.dataset.freePlacementKey || generatedKey;
        target.dataset.freePlacementBlock = String(block.id);
        target.dataset.freePlacementKey = key;
        const saved = placements[key] || { x: 0, y: 0 };
        target.dataset.freePlacementX = String(saved.x);
        target.dataset.freePlacementY = String(saved.y);
        if (isServiceCardAnchor(saved.anchor) || isResponsiveCopyAnchor(saved.anchor)) target.dataset.freePlacementAnchor = saved.anchor;
        if (isResizableButton(target) && !target.matches('[data-home-cta],[data-custom-site-button]')) {
          const siteScale = Math.max(60, Math.min(130, Number(state.siteButtonScale) || 100)) / 100;
          const savedScale = Math.max(.5, Math.min(1.8, Number(saved.scale) || 1));
          target.dataset.freePlacementScale = String(savedScale);
          target.style.setProperty('scale', String(siteScale * savedScale), 'important');
        }
        if (saved.width && saved.height && isResizableButton(target)) {
          target.style.setProperty('box-sizing', 'border-box', 'important');
          target.style.setProperty('width', `${saved.width}px`, 'important');
          target.style.setProperty('height', `${saved.height}px`, 'important');
        }
      }
    });

    const positionScript = doc.createElement('script');
    positionScript.textContent = `(()=>{const apply=()=>{for(const el of document.querySelectorAll('[data-free-placement-block]')){const section=el.closest('[data-editor-block]')||el.closest('body>section');const responsiveCopy=el.closest('.hero-copy,.habitat-hero-copy,.meta-hero-copy,.service-copy,.actions,.template-hero-actions,.meta-actions,.habitat-hero-actions');const basis=isCardAnchor(el.dataset.freePlacementAnchor)?(el.closest('.service-card')||section):el.dataset.freePlacementAnchor==='responsive-copy'?(responsiveCopy||section):section;if(!basis)continue;const r=basis.getBoundingClientRect();let x=Number(el.dataset.freePlacementX)||0;const y=Number(el.dataset.freePlacementY)||0;el.style.translate=(r.width*x/100)+'px '+(r.height*y/100)+'px';if(el.matches('.service-info-button')){const copy=el.closest('.service-copy')||el.closest('.service-card')||basis,style=getComputedStyle(copy),scale=parseFloat(el.style.scale)||1,available=Math.max(40,copy.clientWidth-(parseFloat(style.paddingLeft)||0)-(parseFloat(style.paddingRight)||0)),preferred=Number(el.dataset.serviceButtonPreferredWidth)||parseFloat(el.style.width)||190,canvas=document.createElement('canvas'),context=canvas.getContext('2d');if(context)context.font='600 12px Segoe UI, Arial, sans-serif';const textWidth=context?.measureText(el.textContent.trim()).width||84,minimumWithIcon=Math.ceil(textWidth+22+6+16+2),compact=available/scale<minimumWithIcon,minimum=Math.min(available/scale,compact?textWidth+18:minimumWithIcon),width=Math.max(40,Math.min(available/scale,Math.max(minimum,Math.min(preferred,available/scale))));el.dataset.serviceButtonCompact=String(compact);el.dataset.serviceButtonPreferredWidth=String(preferred);el.style.setProperty('width',width+'px','important');el.style.setProperty('min-width',width+'px','important');el.style.setProperty('max-width',width+'px','important');el.style.setProperty('box-sizing','border-box','important');el.style.setProperty('display','flex','important');el.style.setProperty('gap','6px','important');el.style.setProperty('padding-left','8px','important');el.style.setProperty('padding-right','8px','important');el.style.setProperty('white-space','nowrap','important');el.style.setProperty('min-height','40px','important');el.style.setProperty('font-size','12px','important');el.style.setProperty('line-height','1.1','important');el.style.setProperty('margin-left','auto','important');el.style.setProperty('margin-right','auto','important');const button=el.getBoundingClientRect(),copyRect=copy.getBoundingClientRect(),contentLeft=copyRect.left+(parseFloat(style.paddingLeft)||0),contentRight=copyRect.right-(parseFloat(style.paddingRight)||0);const correction=button.left<contentLeft?contentLeft-button.left:button.right>contentRight?contentRight-button.right:0;if(Math.abs(correction)>.5&&r.width>0){x=Math.max(-100,Math.min(100,x+correction/r.width*100));el.dataset.freePlacementX=String(x);el.style.translate=(r.width*x/100)+'px '+(r.height*y/100)+'px'}}}};const isCardAnchor=value=>value==='service-card'||value==='service-card-centered';window.applyFreeBlockPlacements=apply;requestAnimationFrame(apply);window.addEventListener('resize',apply,{passive:true});if('ResizeObserver'in window){const observer=new ResizeObserver(apply);document.querySelectorAll('[data-free-placement-block]').forEach(el=>{const section=el.closest('body>section');if(section)observer.observe(section);const card=el.closest('.service-card');if(card)observer.observe(card);const copy=el.closest('.service-copy,.hero-copy,.habitat-hero-copy,.meta-hero-copy,.actions,.template-hero-actions,.meta-actions,.habitat-hero-actions');if(copy)observer.observe(copy)})}})();`;
    doc.body.append(positionScript);
    return '<!doctype html>\n' + doc.documentElement.outerHTML;
  };

  const toolbar = document.querySelector('.toolbar');
  const resetButton = document.createElement('button');
  resetButton.type = 'button';
  resetButton.className = 'free-placement-reset';
  resetButton.textContent = 'Réinitialiser';
  resetButton.title = 'Remettre tous les boutons à leur position et taille d’origine';
  if (toolbar) {
    toolbar.append(resetButton);
    const style = document.createElement('style');
    style.textContent = '.free-placement-reset{font-size:12px}.free-placement-help{flex-basis:100%;margin:5px 0 0;color:#765f51;font-size:12px}';
    document.head.append(style);
    const help = document.createElement('p');
    help.className = 'free-placement-help';
    help.textContent = 'Déplacez les boutons et le menu de gauche. Tirez les poignées pour régler la taille des boutons et des blocs.';
    toolbar.after(help);
    resetButton.addEventListener('click', () => {
      for (const block of state.blocks) block.freePlacements = {};
      for (const block of state.blocks) block.homeCtaScale = 1;
      for (const button of state.customSiteButtons || []) button.scale = 1;
      state.siteButtonScale = 100;
      update();
      $('#status').textContent = 'Les boutons ont retrouvé leur taille et leur position d’origine.';
    });
  }

  function bindPlacementDrag() {
    const doc = previewFrame.contentDocument;
    if (!doc?.body || doc.freePlacementDragBound) return;
    doc.freePlacementDragBound = true;
    const style = doc.createElement('style');
    style.textContent = 'body.free-placement-mode [data-free-placement-block]{cursor:move!important;touch-action:none}body.free-placement-mode [data-free-placement-block]:hover{z-index:20;outline:2px dashed #b43c2d!important;outline-offset:3px;filter:drop-shadow(0 3px 8px #b43c2d66)}body.free-placement-mode [data-free-placement-block]:focus-visible{outline:3px solid #b43c2d!important}.site-button-resize{display:none;position:absolute;right:-9px;bottom:-9px;z-index:40;place-items:center;width:22px;height:22px;padding:0;border:2px solid #fff;border-radius:50%;background:#8e3d25;color:#fff;font:700 14px/1 Arial;box-shadow:0 2px 8px #2b1b1670;cursor:nwse-resize;touch-action:none}body.free-placement-mode .site-button-resize,body.free-placement-mode .custom-site-button-resize,body.free-placement-mode .home-cta-resize{display:grid}';
    doc.head.append(style);
    doc.defaultView.applyFreeBlockPlacements?.();

    doc.addEventListener('pointerdown', event => {
      suppressClickOn = null;
      if (!placementMode) return;
      const resetHandle = event.target.closest('.site-button-reset-size');
      if (resetHandle) {
        const target = resetHandle.closest('[data-free-placement-block]');
        if (target) suppressClickOn = target;
        return;
      }
      const resizeHandle = event.target.closest('.site-button-resize,.custom-site-button-resize,.home-cta-resize');
      const target = resizeHandle?.closest('[data-free-placement-block]') || event.target.closest('[data-free-placement-block]');
      if (!target) return;
      const block = state.blocks.find(item => String(item.id) === target.dataset.freePlacementBlock);
      const section = placementBasisFor(target, target.closest('[data-editor-block]') || target.closest('body>section'), target.dataset.freePlacementAnchor);
      if (!block || !section) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      const rect = section.getBoundingClientRect();
      const x = Number(target.dataset.freePlacementX) || 0;
      const y = Number(target.dataset.freePlacementY) || 0;
      const scalePeers = isResizableButton(target) ? relatedButtons(target, section) : [];
      const groupRects = [target, ...scalePeers].map(item => ({ item, rect: item.getBoundingClientRect() }));
      const row = groupRects.slice(1).some(({ rect: peerRect }) => {
        const targetRect = groupRects[0].rect;
        return Math.abs(targetRect.top + targetRect.height / 2 - (peerRect.top + peerRect.height / 2)) <= Math.abs(targetRect.left + targetRect.width / 2 - (peerRect.left + peerRect.width / 2));
      });
      const scaleOrder = item => { const itemRect = item.getBoundingClientRect(); return row ? itemRect.left : itemRect.top; };
      activeDrag = {
        target, block, section, startX: event.clientX, startY: event.clientY,
        width: Math.max(1, rect.width), height: Math.max(1, rect.height), x, y,
        startScale: Number(target.dataset.homeCtaScale) || Number(target.dataset.customScale) || Number(target.dataset.freePlacementScale) || 1,
        scaleGroup: scalePeers.map(item => ({ target: item, order: scaleOrder(item) })), targetOrder: scaleOrder(target),
        mode: resizeHandle && isResizableButton(target) ? 'resize' : 'move',
        pointerId: event.pointerId, moved: false
      };
      target.setPointerCapture?.(event.pointerId);
    }, true);

    doc.addEventListener('pointermove', event => {
      if (!placementMode || !activeDrag || event.pointerId !== activeDrag.pointerId) return;
      event.preventDefault();
      const drag = activeDrag;
      drag.moved ||= Math.abs(event.clientX - drag.startX) > 3 || Math.abs(event.clientY - drag.startY) > 3;
      if (drag.mode === 'resize') {
        const homeCta = drag.target.matches('[data-home-cta]');
          const minScale = homeCta ? .55 : .65;
        const maxScale = homeCta ? 1.5 : 1.8;
        const scale = Math.max(minScale, Math.min(maxScale, drag.startScale + ((event.clientX - drag.startX) + (event.clientY - drag.startY)) / 220));
        const customButton = drag.target.matches('[data-custom-site-button]');
        if (homeCta) drag.target.dataset.homeCtaScale = String(scale);
        else if (customButton) drag.target.dataset.customScale = String(scale);
        else drag.target.dataset.freePlacementScale = String(scale);
        alignResizedGroup(drag, scale);
      } else {
        let x = Math.max(-100, Math.min(100, drag.x + (event.clientX - drag.startX) / drag.width * 100));
        const y = Math.max(-100, Math.min(100, drag.y + (event.clientY - drag.startY) / drag.height * 100));
        const peerSnap = snapButtonToPeer(drag.target, drag.section, x, y);
        if (peerSnap) { x = peerSnap.x; drag.target.dataset.freePlacementY = String(peerSnap.y); }
        else x = snapButtonX(drag.target, drag.section, x, y);
        drag.target.dataset.freePlacementX = String(x);
        if (!peerSnap) drag.target.dataset.freePlacementY = String(y);
        const finalY = Number(drag.target.dataset.freePlacementY) || 0;
        drag.target.style.translate = `${drag.width * x / 100}px ${drag.height * finalY / 100}px`;
      }
    }, true);

    const finish = event => {
      if (!activeDrag || (event.pointerId !== undefined && event.pointerId !== activeDrag.pointerId)) return;
      const drag = activeDrag;
      activeDrag = null;
      if (drag.moved) suppressClickOn = drag.target;
      const placements = drag.block.freePlacements = normalisePlacements(drag.block.freePlacements);
      if (drag.mode === 'resize') {
        const resizeMembers = [drag.target, ...drag.scaleGroup.map(item => item.target)];
        if (drag.target.matches('[data-home-cta]')) {
          drag.block.homeCtaScale = Math.max(.55, Math.min(1.5, Number(drag.target.dataset.homeCtaScale) || 1));
        } else if (drag.target.matches('[data-custom-site-button]')) {
          const button = state.customSiteButtons?.find(item => item.id === drag.target.dataset.customSiteButton);
          if (button) button.scale = Math.max(.65, Math.min(1.8, Number(drag.target.dataset.customScale) || 1));
        } else {
          placements[drag.target.dataset.freePlacementKey] = {
            ...(placements[drag.target.dataset.freePlacementKey] || {}),
            x: Number(drag.target.dataset.freePlacementX) || 0,
            y: Number(drag.target.dataset.freePlacementY) || 0,
            scale: Math.max(.5, Math.min(1.8, Number(drag.target.dataset.freePlacementScale) || 1))
          };
        }
        for (const { target } of drag.scaleGroup) {
          if (target.matches('[data-home-cta]')) drag.block.homeCtaScale = Math.max(.55, Math.min(1.5, Number(target.dataset.homeCtaScale) || 1));
          else if (target.matches('[data-custom-site-button]')) {
            const button = state.customSiteButtons?.find(item => item.id === target.dataset.customSiteButton);
            if (button) button.scale = Math.max(.65, Math.min(1.8, Number(target.dataset.customScale) || 1));
          }
          placements[target.dataset.freePlacementKey] = {
            ...(placements[target.dataset.freePlacementKey] || {}),
            x: Number(target.dataset.freePlacementX) || 0,
            y: Number(target.dataset.freePlacementY) || 0,
            ...(!target.matches('[data-home-cta],[data-custom-site-button]') ? { scale: Math.max(.5, Math.min(1.8, Number(target.dataset.freePlacementScale) || 1)) } : {})
          };
        }
        if (resizeMembers.length > 1) {
          for (const target of resizeMembers) {
            placements[target.dataset.freePlacementKey] = {
              ...(placements[target.dataset.freePlacementKey] || {}),
              x: Number(target.dataset.freePlacementX) || 0,
              y: Number(target.dataset.freePlacementY) || 0,
              width: target.offsetWidth,
              height: target.offsetHeight
            };
          }
        }
      }
      if (drag.mode === 'move') placements[drag.target.dataset.freePlacementKey] = {
        ...(placements[drag.target.dataset.freePlacementKey] || {}),
        x: Number(drag.target.dataset.freePlacementX) || 0,
        y: Number(drag.target.dataset.freePlacementY) || 0
      };
      update();
    };
    doc.addEventListener('pointerup', finish, true);
    doc.addEventListener('pointercancel', finish, true);
    doc.addEventListener('click', event => {
      const resetHandle = event.target.closest('.site-button-reset-size');
      if (placementMode && resetHandle) {
        const target = resetHandle.closest('[data-free-placement-block]');
        const block = state.blocks.find(item => String(item.id) === target?.dataset.freePlacementBlock);
        if (!target || !block) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        suppressClickOn = null;
        const placements = block.freePlacements = normalisePlacements(block.freePlacements);
        const savedPlacement = placements[target.dataset.freePlacementKey];
        if (savedPlacement) {
          delete savedPlacement.width;
          delete savedPlacement.height;
        }
        if (target.matches('[data-home-cta]')) {
          block.homeCtaScale = 1;
        } else if (target.matches('[data-custom-site-button]')) {
          const button = state.customSiteButtons?.find(item => item.id === target.dataset.customSiteButton);
          if (button) button.scale = 1;
        } else {
          const key = target.dataset.freePlacementKey;
          placements[key] = { ...(placements[key] || {}), x: Number(target.dataset.freePlacementX) || 0, y: Number(target.dataset.freePlacementY) || 0, scale: 1 };
        }
        $('#status').textContent = 'La taille de ce bouton a été rétablie sans déplacer les autres.';
        update();
        return;
      }
      if (!placementMode || !suppressClickOn || !event.target.closest('[data-free-placement-block]')) return;
      if (event.target.closest('[data-free-placement-block]') !== suppressClickOn) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      suppressClickOn = null;
    }, true);
  }

  function applyPlacementPreview() {
    const doc = previewFrame.contentDocument;
    if (!doc?.body) return;
    let shouldPersistSnappedButtons = false;
    for (const section of doc.querySelectorAll('body > section[data-editor-block]')) {
      const block = state.blocks.find(item => String(item.id) === section.dataset.editorBlock);
      if (!block) continue;
      const placements = normalisePlacements(block.freePlacements);
      block.freePlacements = placements;
      for (const group of section.querySelectorAll('.custom-site-actions,.template-hero-actions,.meta-actions,.habitat-hero-actions,.actions,.project-comparison-actions')) {
        if (group.querySelectorAll(':scope > a[href],:scope > button,:scope > [role="button"]').length > 1) {
          group.style.setProperty('display', 'flex', 'important');
          group.style.setProperty('flex-wrap', 'wrap', 'important');
          group.style.setProperty('align-items', 'center', 'important');
          group.style.setProperty('column-gap', '16px', 'important');
          group.style.setProperty('row-gap', '16px', 'important');
        }
      }
      let buttonIndex = 0;
      const rect = section.getBoundingClientRect();
      for (const target of section.querySelectorAll('a[href], button, [role="button"]')) {
        if (target.closest('.checkout-auth-options')) {
          // Keep old generated placement indexes stable while leaving provider controls untouched.
          buttonIndex++;
          target.querySelectorAll('.site-button-controls,.site-button-resize,.custom-site-button-resize,.home-cta-resize').forEach(handle => handle.remove());
          continue;
        }
        if (!isResizableButton(target)) continue;
        if (target.closest('.site-menu, .site-menu-toggle, dialog, .preview-block-tools, .author-credit')) continue;
        const generatedKey = placementKey('bouton', buttonIndex++);
        const key = target.dataset.freePlacementKey || generatedKey;
        const hasSavedPosition = Object.hasOwn(placements, key);
        let saved = placements[key] || { x: 0, y: 0 };
        if (target.closest('.project-comparison-actions')) {
          if (saved.x || saved.y || saved.anchor) {
            saved = { ...saved, x: 0, y: 0, anchor: undefined };
            placements[key] = saved;
            shouldPersistSnappedButtons = true;
          }
          saved = { ...saved, x: 0, y: 0 };
        }
        target.dataset.freePlacementBlock = String(block.id);
        target.dataset.freePlacementKey = key;
        const card = serviceCardFor(target);
        if (card && saved.anchor !== 'service-card-centered') {
          target.style.translate = '0px 0px';
          const cardRect = card.getBoundingClientRect();
          const oldY = rect.height * saved.y / 100;
          saved = { ...saved, x: 0, y: cardRect.height ? oldY / cardRect.height * 100 : 0, anchor: 'service-card-centered' };
          placements[key] = saved;
          shouldPersistSnappedButtons = true;
        } else if (!card && responsiveCopyFor(target) && isResponsiveCopyAnchor(saved.anchor)) {
          const copy = responsiveCopyFor(target);
          const copyRect = copy.getBoundingClientRect();
          saved = {
            ...saved,
            x: rect.width ? copyRect.width * saved.x / rect.width : 0,
            y: rect.height ? copyRect.height * saved.y / rect.height : 0,
            anchor: undefined
          };
          placements[key] = saved;
          shouldPersistSnappedButtons = true;
        }
        const basis = placementBasisFor(target, section, saved.anchor);
        const basisRect = basis.getBoundingClientRect();
        target.dataset.freePlacementAnchor = isServiceCardAnchor(saved.anchor) || isResponsiveCopyAnchor(saved.anchor) ? saved.anchor : '';
        target.dataset.freePlacementX = String(saved.x);
        target.dataset.freePlacementY = String(saved.y);
        target.style.translate = `${basisRect.width * saved.x / 100}px ${basisRect.height * saved.y / 100}px`;
        if (isResizableButton(target)) {
          target.querySelectorAll('.site-button-resize,.custom-site-button-resize,.home-cta-resize').forEach(handle => handle.remove());
          let controls = target.querySelector('.site-button-controls');
          if (!controls) {
            controls = doc.createElement('span');
            controls.className = 'site-button-controls';
            controls.style.cssText = 'display:flex!important;align-items:center!important;gap:3px!important;position:absolute!important;right:-16px!important;bottom:-10px!important;z-index:41!important;pointer-events:auto!important';
            const reset = doc.createElement('span');
            reset.className = 'site-button-reset-size';
            reset.textContent = '↺';
            reset.setAttribute('aria-hidden', 'true');
            reset.title = 'Rétablir la taille d’origine de ce bouton';
            reset.style.cssText = 'display:grid!important;position:static!important;place-items:center!important;width:24px!important;height:22px!important;padding:0!important;border:2px solid #71391f!important;border-radius:50%!important;background:#fff!important;color:#71391f!important;font:700 15px/1 Arial!important;box-shadow:0 2px 8px #2b1b1670!important;cursor:pointer!important;touch-action:none!important';
            const resize = doc.createElement('span');
            resize.className = 'site-button-resize';
            resize.textContent = '↘';
            resize.setAttribute('aria-hidden', 'true');
            resize.title = 'Tirer pour redimensionner ce bouton';
            resize.style.cssText = 'display:grid!important;position:static!important;place-items:center!important;width:22px!important;height:22px!important;padding:0!important;border:2px solid #fff!important;border-radius:50%!important;background:#8e3d25!important;color:#fff!important;font:700 14px/1 Arial!important;box-shadow:0 2px 8px #2b1b1670!important;cursor:nwse-resize!important;touch-action:none!important';
            controls.append(reset, resize);
            if (doc.defaultView.getComputedStyle(target).position === 'static') target.style.setProperty('position', 'relative', 'important');
            target.append(controls);
          }
        }
        target.dataset.freePlacementScale = String(Math.max(.5, Math.min(1.8, Number(saved.scale) || 1)));
        if (target.matches('[data-custom-site-button]')) {
          target.dataset.customScale = String(Math.max(.65, Math.min(1.8, Number(target.dataset.customScale) || 1)));
          target.style.scale = target.dataset.customScale;
        }
        if (target.matches('[data-home-cta]')) {
          target.dataset.homeCtaScale = String(Math.max(.55, Math.min(1.5, Number(block.homeCtaScale) || 1)));
          target.style.scale = target.dataset.homeCtaScale;
        }
        if (saved.width && saved.height && isResizableButton(target)) {
          target.style.setProperty('box-sizing', 'border-box', 'important');
          target.style.setProperty('width', `${saved.width}px`, 'important');
          target.style.setProperty('height', `${saved.height}px`, 'important');
        }
        if (isResizableButton(target)) {
          const siteScale = Math.max(60, Math.min(130, Number(state.siteButtonScale) || 100)) / 100;
          let individualScale = Number(target.dataset.homeCtaScale) || Number(target.dataset.customScale) || 1;
          if (target.dataset.customSiteButton) {
            const custom = state.customSiteButtons?.find(item => item.id === target.dataset.customSiteButton);
            individualScale = Number(custom?.scale) || individualScale;
          }
          if (!target.matches('[data-home-cta],[data-custom-site-button]')) individualScale = Number(target.dataset.freePlacementScale) || 1;
          target.style.setProperty('scale', String(siteScale * individualScale), 'important');
        }
        applyServiceButtonWidthLimit(target);
        if (card) {
          const currentRect = target.getBoundingClientRect();
          const copy = target.closest('.service-copy') || card;
          const copyRect = copy.getBoundingClientRect();
          const copyStyle = doc.defaultView.getComputedStyle(copy);
          const contentLeft = copyRect.left + (parseFloat(copyStyle.paddingLeft) || 0);
          const contentRight = copyRect.right - (parseFloat(copyStyle.paddingRight) || 0);
          const correction = currentRect.left < contentLeft
            ? contentLeft - currentRect.left
            : currentRect.right > contentRight ? contentRight - currentRect.right : 0;
          if (Math.abs(correction) > .5 && basisRect.width > 0) {
            saved = { ...saved, x: Math.max(-100, Math.min(100, saved.x + correction / basisRect.width * 100)) };
            placements[key] = saved;
            target.dataset.freePlacementX = String(saved.x);
            target.style.translate = `${basisRect.width * saved.x / 100}px ${basisRect.height * saved.y / 100}px`;
            shouldPersistSnappedButtons = true;
          }
        }
        if (isResizableButton(target) && !hasSavedPosition) {
          const peerSnap = snapButtonToPeer(target, basis, saved.x, saved.y);
          const snappedX = peerSnap?.x ?? snapButtonX(target, basis, saved.x, saved.y);
          const snappedY = peerSnap?.y ?? saved.y;
          if (Math.abs(snappedX - saved.x) > .01 || Math.abs(snappedY - saved.y) > .01) {
            placements[key] = { ...saved, x: snappedX, y: snappedY };
            target.dataset.freePlacementX = String(snappedX);
            target.dataset.freePlacementY = String(snappedY);
            target.style.translate = `${basisRect.width * snappedX / 100}px ${basisRect.height * snappedY / 100}px`;
            shouldPersistSnappedButtons = true;
          }
        }
      }
    }
    doc.body.classList.toggle('free-placement-mode', placementMode);
    if (shouldPersistSnappedButtons && !applyPlacementPreview.persistingSnap) {
      applyPlacementPreview.persistingSnap = true;
      setTimeout(() => {
        applyPlacementPreview.persistingSnap = false;
        update();
      }, 0);
    }
  }

  previewFrame.addEventListener('load', () => {
    bindPlacementDrag();
    applyPlacementPreview();
  });
  const refreshBeforePlacementBind = refreshPreviewWithoutBlink;
  refreshPreviewWithoutBlink = function () {
    refreshBeforePlacementBind();
    bindPlacementDrag();
    previewFrame.contentWindow?.applyFreeBlockPlacements?.();
    applyPlacementPreview();
  };
  bindPlacementDrag();
  refreshPreviewWithoutBlink();
})();
