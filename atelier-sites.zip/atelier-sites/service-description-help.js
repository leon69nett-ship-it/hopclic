const renderServiceBeforeDescriptionHelp=renderServiceItems;
renderServiceItems=function(card,block){
  renderServiceBeforeDescriptionHelp(card,block);
  const fields=card.querySelector('.service-item-fields');if(!fields)return;
  const inDetails=serviceDetailsEditingKey===block.id+':'+selectedServiceIndex;
  const labels=[...fields.querySelectorAll('label')];
  const description=labels.find(label=>label.textContent.startsWith('Description de la prestation'));
  const name=fields.querySelector('.selected-service-name');
  if(inDetails){
    block.serviceDetails??=[];const detail=block.serviceDetails[selectedServiceIndex]??={enabled:true,label:'En savoir plus',title:'',text:''};
    const input=description?.querySelector('textarea');
    if(input){input.value=detail.text||'';input.placeholder='Écrivez votre message…';input.oninput=()=>{detail.text=input.value;update()};if(description)description.firstChild.textContent='Message';}
    if(name){name.value=detail.title||'';name.placeholder='Écrivez un titre…';name.oninput=()=>{detail.title=name.value;update()};const nameLabel=name.closest('label');if(nameLabel)nameLabel.firstChild.textContent='Titre du message';}
  }
  for(const label of labels)if(label.textContent.startsWith('Titre de la fiche')||label.textContent.startsWith('Contenu de la fiche explicative'))label.remove();
  for(const note of fields.querySelectorAll('p'))if(note.textContent==='Le bouton ouvre ces informations dans une fenêtre sur le site.')note.remove();
  const input=description?.querySelector('textarea');
  if(input){input.setAttribute('aria-label',inDetails?'Message':'Description de la prestation');if(!description.querySelector('.text-help-button'))TextHelp.attach(input,inDetails?'Message':'Description de la prestation');description.querySelector('.text-help-button')?.setAttribute('aria-label','Aide IA pour la description de la prestation');}
};
render();
