function prepareEmptyServiceCards(){
  for(const block of state.blocks)if(block.type==='services'){
    if(!block.text.trim())block.text='|\n|\n|';
    block.serviceDetails??=[];
    serviceItems(block).forEach((item,index)=>{block.serviceDetails[index]??={enabled:true,label:'En savoir plus',title:'',text:''}});
  }
}
const renderBeforeEmptyServiceCards=render;
render=function(){prepareEmptyServiceCards();renderBeforeEmptyServiceCards()};
const pageBeforeEmptyServiceCards=page;
page=function(){
  prepareEmptyServiceCards();
  const doc=parseRenderedPage(pageBeforeEmptyServiceCards());
  doc.querySelectorAll('.service-card').forEach(card=>{
    if(card.querySelector('img,.service-video,.service-card-video-thumb'))return;
    const placeholder=doc.createElement('div');placeholder.className='service-empty-photo';
    placeholder.innerHTML='<button type="button" class="service-empty-image" title="Ajouter une photo" aria-label="Ajouter une photo">📷</button><button type="button" class="service-empty-video" title="Ajouter une vidéo" aria-label="Ajouter une vidéo">🎬</button><button type="button" class="service-empty-text">Sans média</button>';
    card.prepend(placeholder);
  });
  const style=doc.createElement('style');style.textContent='.service-empty-photo{min-height:84px;display:flex;flex-direction:row;align-items:center;justify-content:center;gap:12px;background:transparent;border:0;border-radius:0;color:'+state.secondaryColor+';font:13px Arial;cursor:pointer}.service-empty-photo>span:first-child{font-size:28px}.service-empty-photo button{display:inline-flex;align-items:center;justify-content:center;width:44px;min-width:44px;height:44px;min-height:44px;background:transparent!important;color:inherit!important;border:0!important;box-shadow:none!important;padding:0!important;font:22px Arial!important}.service-copy h3:empty,.service-copy p:empty{display:none}';doc.head.append(style);
  return serializeRenderedPage(doc);
};
function bindEmptyServiceCards(){
  const doc=previewFrame.contentDocument;if(!doc||doc.emptyServiceCardsBound)return;doc.emptyServiceCardsBound=true;
  doc.addEventListener('click',event=>{
    const placeholder=event.target.closest('.service-empty-photo');if(!placeholder)return;
    const section=placeholder.closest('[data-editor-block]'),card=placeholder.closest('.service-card');
    const block=state.blocks.find(item=>item.id===section?.dataset.editorBlock);if(!block)return;
    const index=[...section.querySelectorAll('.service-card')].indexOf(card);
    event.preventDefault();event.stopImmediatePropagation();
    if(event.target.closest('.service-empty-text')){chooseServiceTextOnly(block,index,false);return;}serviceDetailsEditingKey=null;selectEditorBlock(block.id);render();openServiceItem(block.id,index);
    const panel=[...document.querySelectorAll('#editor .block')].find(item=>item.dataset.blockId===block.id);
    const button=[...panel.querySelectorAll('button')].find(item=>(event.target.closest('.service-empty-video')?/Choisir une vidéo/:/Choisir une photo/).test(item.textContent));
    if(button){button.scrollIntoView({behavior:'instant',block:'center'});button.focus({preventScroll:true});button.click();}
  },true);
}
previewFrame.addEventListener('load',bindEmptyServiceCards);bindEmptyServiceCards();
render();update();
