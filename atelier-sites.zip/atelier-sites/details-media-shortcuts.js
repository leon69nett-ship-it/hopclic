// These editor actions belong only to the draft preview, never to the exported site.
function addDetailsMediaShortcuts(){
  const doc=previewFrame.contentDocument;if(!doc)return;
  doc.querySelectorAll('.service-info-dialog').forEach(dialog=>{
    if(dialog.querySelector('.details-media-shortcuts'))return;
    const actions=doc.createElement('div');actions.className='details-media-shortcuts';
    actions.style.cssText='display:flex;gap:12px;flex-wrap:wrap;padding:14px 0;border-top:1px dashed currentColor;margin-top:20px';
    for(const [kind,label]of [['photo','📷 Photo'],['video','🎬 Vidéo']]){
      const action=doc.createElement('button');action.type='button';action.textContent=label;
      action.style.cssText='background:transparent;color:inherit;border:1px solid currentColor;padding:10px 16px;border-radius:8px';
      action.onclick=event=>{
        event.preventDefault();event.stopPropagation();
        const card=dialog.closest('.service-card'),section=dialog.closest('[data-editor-block]');
        const block=state.blocks.find(item=>item.id===section?.dataset.editorBlock);if(!block)return;
        const index=[...section.querySelectorAll('.service-card')].indexOf(card);
        dialog.close();selectEditorBlock(block.id);serviceDetailsEditingKey=block.id+':'+index;render();openServiceItem(block.id,index);
        const panel=[...document.querySelectorAll('#editor .block')].find(item=>item.dataset.blockId===block.id);
        const button=[...panel.querySelectorAll('button')].find(item=>(kind==='photo'?/Choisir une photo/:/Choisir une vidéo/).test(item.textContent));
        button?.click();
      };
      actions.append(action);
    }
    dialog.append(actions);
  });
}
previewFrame.addEventListener('load',addDetailsMediaShortcuts);
const refreshBeforeDetailsShortcuts=refreshPreviewWithoutBlink;
refreshPreviewWithoutBlink=function(){refreshBeforeDetailsShortcuts();addDetailsMediaShortcuts()};
addDetailsMediaShortcuts();
const renderServiceBeforeCompactDetails=renderServiceItems;
renderServiceItems=function(card,block){
  renderServiceBeforeCompactDetails(card,block);
  if(serviceDetailsEditingKey!==block.id+':'+selectedServiceIndex)return;
  const fields=card.querySelector('.service-item-fields');if(!fields)return;
  const actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;margin:14px 0';
  for(const [pattern,label]of [[/Choisir une photo/,'📷 Photo'],[/Choisir une vidéo/,'🎬 Vidéo']]){
    const target=[...fields.querySelectorAll('button')].find(button=>pattern.test(button.textContent));if(!target)continue;
    const button=document.createElement('button');button.type='button';button.textContent=label;button.onclick=()=>target.click();actions.append(button);
  }
  const content=[...fields.querySelectorAll('label')].find(label=>label.textContent.includes('Contenu de la fiche explicative'));
  if(content)content.after(actions);else fields.prepend(actions);
};
