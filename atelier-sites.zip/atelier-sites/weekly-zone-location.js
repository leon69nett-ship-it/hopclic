const renderBeforeZoneHours=render;
render=function(){
  renderBeforeZoneHours();
  if(tab!=='blocks')return;
  for(const card of document.querySelectorAll('#editor .block')){
    const block=state.blocks.find(item=>item.id===card.dataset.blockId);
    if(block?.type==='zone'&&!card.querySelector('.weekly-editor'))renderWeeklyEditor(card.querySelector('details')||card);
  }
};
render();
