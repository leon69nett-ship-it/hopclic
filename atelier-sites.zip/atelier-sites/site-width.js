const validateBeforeSiteWidth=validate;
validate=function(saved){const result=validateBeforeSiteWidth(saved);result.siteWidth=saved.siteWidth==='full'?'full':'centered';return result};
state.siteWidth=state.siteWidth==='full'?'full':'centered';
const renderBeforeSiteWidth=render;
render=function(){
  renderBeforeSiteWidth();document.querySelector('.browser')?.classList.toggle('site-full-width',state.siteWidth==='full');if(tab!=='design')return;
  const label=document.createElement('label');label.textContent='Largeur du site';
  const select=document.createElement('select');
  for(const [value,text]of [['centered','Centré — avec des marges'],['full','Pleine largeur']]){const option=document.createElement('option');option.value=value;option.textContent=text;select.append(option)}
  select.value=state.siteWidth||'centered';select.onchange=()=>{state.siteWidth=select.value;update();document.querySelector('.browser')?.classList.toggle('site-full-width',state.siteWidth==='full')};label.append(select);
  const note=document.createElement('p');note.className='hint';note.textContent='Sur mobile, le site utilise la largeur disponible de l’écran.';
  document.querySelector('#editor').prepend(label,note);
};
const pageBeforeSiteWidth=page;
page=function(){
  const doc=parseRenderedPage(pageBeforeSiteWidth());const style=doc.createElement('style');
  style.textContent=state.siteWidth==='full'?'html{width:100%!important;max-width:none!important}body{width:100%!important;max-width:none!important;margin:0!important;min-height:100vh;box-shadow:none!important}':'html{background:color-mix(in srgb,'+state.background+' 90%,#7b6357)}body{width:calc(100% - 64px);max-width:1200px;margin:0 auto;box-shadow:0 0 32px #00000012}body>header .site-menu-toggle,.back-to-top{right:max(16px,calc((100vw - 1200px)/2 + 16px))!important}@media(max-width:760px){body{width:100%;max-width:none;box-shadow:none}body>header .site-menu-toggle,.back-to-top{right:12px!important}}';
  doc.head.append(style);return serializeRenderedPage(doc);
};
render();update();
