const crypto=require('node:crypto'),net=require('node:net');
const sessions=new Map();
const configured=()=>Boolean(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET);
function siteURL(value){const url=new URL(value);if(url.protocol!=='https:'||url.username||url.password||net.isIP(url.hostname)||!url.hostname.includes('.')||/\.(localhost|local|internal)$/i.test(url.hostname))throw Error('Renseignez l’adresse HTTPS publique de votre site.');url.hash='';url.search='';if(!url.pathname.endsWith('/'))url.pathname+='/';return url.href}
async function handleGoogleSearch(req,res,pathname){
 if(!pathname.startsWith('/api/google-search/'))return false;
 const host=req.headers.host||'',origin='http://'+host;
 const reply=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data))};
 if(!/^127\.0\.0\.1:\d+$/.test(host)){reply(403,{error:'Connexion Google réservée au serveur local.'});return true}
 const callback=origin+'/api/google-search/callback';
 for(const [key,item]of sessions)if(Date.now()-item.created>3600000)sessions.delete(key);
 const id=(req.headers.cookie||'').match(/(?:^|;\s*)hopclic_google=([a-f0-9]{64})(?:;|$)/)?.[1];let session=sessions.get(id);
 if(pathname.endsWith('/status')&&req.method==='GET'){reply(200,{configured:configured(),connected:Boolean(session?.access&&session.expires>Date.now())});return true}
 if(pathname.endsWith('/callback')&&req.method==='GET'){
  const query=new URL(req.url,origin).searchParams;
  if(!session||!session.state||query.get('state')!==session.state||Date.now()-session.started>600000){reply(400,{error:'Connexion Google expirée ou invalide. Recommencez depuis HopClic.'});return true}
  const verifier=session.verifier;delete session.state;delete session.verifier;
  if(query.has('error')){reply(400,{error:'Connexion Google annulée. Vous pouvez fermer cet onglet.'});return true}
  try{const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({code:query.get('code')||'',client_id:process.env.GOOGLE_CLIENT_ID,client_secret:process.env.GOOGLE_CLIENT_SECRET,redirect_uri:callback,grant_type:'authorization_code',code_verifier:verifier}),signal:AbortSignal.timeout(15000)});const data=await response.json();if(!response.ok||!data.access_token)throw Error();session.access=data.access_token;session.expires=Date.now()+(Number(data.expires_in)||3600)*1000;res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'"});res.end('<!doctype html><html lang="fr"><meta charset="utf-8"><title>Google connecté</title><h1>Google est connecté.</h1><p>Fermez cet onglet puis cliquez sur « Actualiser la connexion » dans HopClic.</p></html>')}catch{reply(502,{error:'Connexion Google impossible. Vérifiez la configuration puis recommencez.'})}return true;
 }
 if(req.method!=='POST'||req.headers.origin!==origin){reply(403,{error:'Demande non autorisée.'});return true}
 if(!configured()){reply(503,{error:'Connexion Google à configurer par HopClic. Aucun site n’a été transmis.'});return true}
 try{
  if(pathname.endsWith('/connect')){if(sessions.size>=100)throw Error('Trop de connexions. Réessayez plus tard.');const sid=crypto.randomBytes(32).toString('hex');session={created:Date.now(),started:Date.now(),state:crypto.randomBytes(32).toString('hex'),verifier:crypto.randomBytes(48).toString('base64url'),verified:new Set()};sessions.set(sid,session);const challenge=crypto.createHash('sha256').update(session.verifier).digest('base64url');const url=new URL('https://accounts.google.com/o/oauth2/v2/auth');url.search=new URLSearchParams({client_id:process.env.GOOGLE_CLIENT_ID,redirect_uri:callback,response_type:'code',scope:'https://www.googleapis.com/auth/webmasters https://www.googleapis.com/auth/siteverification.verify_only',state:session.state,code_challenge:challenge,code_challenge_method:'S256',access_type:'online',prompt:'select_account consent'}).toString();res.setHeader('Set-Cookie',`hopclic_google=${sid}; HttpOnly; SameSite=Lax; Path=/api/google-search/; Max-Age=3600`);reply(200,{url:url.href});return true}
  if(!session?.access||session.expires<=Date.now()){reply(401,{error:'Connectez d’abord votre compte Google.'});return true}
  let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>5000)throw Error('Demande trop longue.');chunks.push(chunk)}const body=JSON.parse(Buffer.concat(chunks).toString()),site=siteURL(body.site);
  const api=async(url,method,payload)=>{const response=await fetch(url,{method,headers:{Authorization:'Bearer '+session.access,'Content-Type':'application/json'},...(payload?{body:JSON.stringify(payload)}:{}),signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error(response.status===401?'Connexion Google expirée. Reconnectez-vous.':'Google a refusé cette étape. Vérifiez que le site est en ligne, que le code de validation est publié et que votre compte dispose des droits nécessaires.');return response.status===204?{}:response.json().catch(()=>({}))};
  if(pathname.endsWith('/prepare')){const data=await api('https://www.googleapis.com/siteVerification/v1/token','POST',{site:{type:'SITE',identifier:site},verificationMethod:'META'});const match=String(data.token||'').match(/content=["']([^"']+)["']/i);if(!match||!/^[-_a-zA-Z0-9]+$/.test(match[1]))throw Error('Code Google de validation illisible.');reply(200,{verification:match[1],site});return true}
  if(pathname.endsWith('/verify')){await api('https://www.googleapis.com/siteVerification/v1/webResource?verificationMethod=META','POST',{site:{type:'SITE',identifier:site}});await api('https://www.googleapis.com/webmasters/v3/sites/'+encodeURIComponent(site),'PUT');session.verified.add(site);reply(200,{verified:true,site});return true}
  if(pathname.endsWith('/submit')){if(!session.verified.has(site))throw Error('Validez d’abord cette adresse de site avec Google.');const sitemap=new URL('sitemap.xml',site).href;await api('https://www.googleapis.com/webmasters/v3/sites/'+encodeURIComponent(site)+'/sitemaps/'+encodeURIComponent(sitemap),'PUT');reply(200,{submitted:true,sitemap,message:'Sitemap transmis à Google. Cela ne garantit pas l’indexation.'});return true}
  reply(404,{error:'Étape inconnue.'});
 }catch(error){reply(400,{error:error.message||'Étape impossible. Réessayez.'})}return true;
}
module.exports={handleGoogleSearch,siteURL};
