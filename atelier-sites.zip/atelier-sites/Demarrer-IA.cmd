@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -Command "$env:HOPCLIC_PORT='8787'; $taskKey=[Environment]::GetEnvironmentVariable('GEMINI_API_KEY','User'); if($taskKey){$env:GEMINI_API_KEY=$taskKey}; $taskModel=[Environment]::GetEnvironmentVariable('GEMINI_PHOTO_MODEL','User'); if($taskModel){$env:GEMINI_PHOTO_MODEL=$taskModel}; node './server.cjs'"
pause
