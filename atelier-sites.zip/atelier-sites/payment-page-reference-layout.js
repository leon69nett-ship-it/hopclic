// Align the account choices and checkout footer with the supplied checkout reference.
const pageBeforePaymentReferenceLayout = page;
page = function () {
  const doc = parseRenderedPage(pageBeforePaymentReferenceLayout());
  const layouts = [...doc.querySelectorAll('.payment-checkout-section .checkout-layout')];

  for (const layout of layouts) {
    const account = layout.querySelector('.checkout-account');
    const methods = account?.querySelector('.checkout-auth-options');
    account?.querySelectorAll('.checkout-optin,.checkout-optout').forEach(element => element.remove());
    if (!account || !methods) continue;

    const policy = doc.createElement('p');
    policy.className = 'checkout-policy';
    policy.textContent = 'En créant votre compte, vous acceptez les conditions d’utilisation et la politique de confidentialité.';
    const handoffNote = account.querySelector('.checkout-terms');
    if (handoffNote) handoffNote.after(policy);

    const action = account.querySelector('.checkout-action');
    if (action) {
      if (action.matches('a')) {
        const arrow = action.querySelector('span');
        action.replaceChildren(doc.createTextNode('Créer le compte et continuer'));
        if (arrow) action.append(arrow);
      }
      const footer = doc.createElement('div');
      footer.className = 'checkout-footer';
      action.replaceWith(footer);
      footer.append(action);
    }

    const step = account.querySelector('.checkout-step details');
    if (step) {
      step.className = 'checkout-billing';
      layout.after(step);
    }
    account.querySelector('.checkout-step')?.remove();
  }

  if (layouts.length && !doc.getElementById('payment-reference-layout-style')) {
    const style = doc.createElement('style');
    style.id = 'payment-reference-layout-style';
    style.textContent = `
      .checkout-auth-options{gap:12px;margin:18px 0 16px}
      html body .payment-checkout-section .checkout-auth-options .checkout-auth-button{box-sizing:border-box!important;position:relative!important;display:flex!important;align-items:center!important;justify-content:center!important;gap:10px!important;width:100%!important;min-width:0!important;max-width:100%!important;height:40px!important;min-height:40px!important;max-height:40px!important;margin:0!important;padding:8px 12px!important;border:1px solid #c9cdd1!important;border-radius:4px!important;background:#fff!important;color:#4d5964!important;box-shadow:none!important;transform:none!important;translate:none!important;scale:1!important;font:600 15px/1.2 Arial,sans-serif!important;text-align:center!important;letter-spacing:normal!important;text-decoration:none!important}
      html body .payment-checkout-section .checkout-auth-options .checkout-auth-button:hover{border-color:#9ba6ae!important;background:#f7f9fb!important;box-shadow:none!important;transform:none!important;translate:none!important}
      html body .payment-checkout-section .checkout-auth-options .checkout-auth-button:focus-visible{outline:3px solid #078bb2!important;outline-offset:2px}
      .checkout-auth-button svg{width:22px!important;height:22px!important;flex:0 0 22px!important}
      .checkout-policy{margin:18px 0 0;padding:17px 0 0;border-top:1px solid #e0e6eb;color:#78838d;text-align:center;font:12px/1.5 Arial,sans-serif}
      .checkout-footer{display:flex;justify-content:flex-end;margin:18px calc(-1 * clamp(22px,4vw,36px)) calc(-1 * clamp(22px,4vw,36px));padding:22px clamp(22px,4vw,36px);border-top:1px solid #dce2e7;background:#fafafa}
      .checkout-footer .checkout-action{width:auto;min-width:240px;margin:0}
      .checkout-billing{max-width:720px;margin:24px 0 0;padding:16px;border:1px solid #dce2e7;border-radius:4px;color:#89929a;font:600 18px Arial,sans-serif}
      .checkout-billing summary{cursor:pointer;list-style:none}
      .checkout-billing summary::-webkit-details-marker{display:none}
      .checkout-billing[open] p{font:14px/1.5 Arial,sans-serif;color:#5d6872}
      @media(max-width:700px){.checkout-footer .checkout-action{width:100%;min-width:0}.checkout-footer{margin-bottom:calc(-1 * clamp(22px,4vw,36px))}}
      @media(prefers-reduced-motion:reduce){.checkout-auth-button{transition:none}}
    `;
    doc.head.append(style);
  }

  return serializeRenderedPage(doc);
};
update();
