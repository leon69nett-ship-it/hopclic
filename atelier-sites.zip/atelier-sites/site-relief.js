state.relief ??= 25;
state.shadowDirection ??= 'right';
const renderBeforeRelief=render;
render=function(){
  renderBeforeRelief();if(tab!=='design')return;
  const box=document.createElement('div');
  const title=document.createElement('h3');title.textContent='Relief et ombres';box.append(title);
  const label=document.createElement('label');label.textContent='Intensité du relief';
  const value=document.createElement('output');value.textContent=' — '+state.relief+' %';label.append(value);
  const slider=document.createElement('input');slider.type='range';slider.min='0';slider.max='100';slider.value=state.relief;slider.setAttribute('aria-label','Intensité du relief');
  slider.oninput=()=>{state.relief=Number(slider.value);value.textContent=' — '+state.relief+' %';update()};label.append(slider);box.append(label);
  const direction=document.createElement('label');direction.textContent='Direction de l’ombre';
  const select=document.createElement('select');for(const [v,t] of [['right','Vers la droite'],['left','Vers la gauche'],['bottom','Vers le bas']]){const option=document.createElement('option');option.value=v;option.textContent=t;select.append(option)}select.value=state.shadowDirection;select.onchange=()=>{state.shadowDirection=select.value;update()};direction.append(select);box.append(direction);
  const hint=document.createElement('p');hint.className='hint';hint.textContent='De plat à marqué : ajustez les ombres du cadre et des cartes. Le rendu change aussitôt.';box.append(hint);
  document.querySelector('#editor').prepend(box);
};
const pageBeforeRelief=page;
page=function(){
  const doc=parseRenderedPage(pageBeforeRelief()),style=doc.createElement('style');
  const n=Math.min(100,Math.max(0,Number(state.relief)||0))/100;
  const x=state.shadowDirection==='bottom'?0:(state.shadowDirection==='left'?-1:1)*Math.round(n*14);
  const shadow=n?`${x}px ${Math.round(3+n*17)}px ${Math.round(6+n*34)}px rgba(65,35,22,${(n*.24).toFixed(3)})`:'none';
  style.textContent=`.services .grid>article,.services-section .grid>article,.gallery-window,.promotions-section article,.slideshow-screen{box-shadow:${shadow}!important}body{box-shadow:${state.siteWidth==='full'?'none':shadow}!important}`;
  doc.head.append(style);return serializeRenderedPage(doc);
};
render();update();
