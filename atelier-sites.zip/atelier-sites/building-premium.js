companyDesignStyles.splice(0,companyDesignStyles.length,
 {name:'Chantier Impact',note:'Puissant · anthracite, cuivre, titres XXL',colors:['#f3f1eb','#ffffff','#202624','#616963','#a9431b','#d5d9d2'],font:'Arial',radius:'0',relief:25},
 {name:'Atelier Signature',note:'Chaleureux · composition éditoriale, terre cuite',colors:['#f8f1e7','#fffaf3','#392b24','#786557','#a44629','#ddcbb9'],font:'Georgia',radius:'20',relief:20},
 {name:'Architecture Studio',note:'Minimal · galerie immersive, lignes fines',colors:['#f6f6f2','#ffffff','#202421','#636960','#354e40','#d4d9d0'],font:'Arial',radius:'0',relief:0}
);
const premiumRenderBefore=render;
render=function(){premiumRenderBefore();if(tab!=='design')return;
 const choices=document.querySelector('.company-style-choices');if(!choices)return;
 choices.querySelector('h3').textContent='Collection Bâtiment';
 choices.querySelector('.hint').textContent='Trois compositions complètes. Choisissez votre ambiance, puis ajoutez vos propres images.';
 const grid=choices.querySelector('div');grid.style.gridTemplateColumns='1fr';
 choices.querySelectorAll('button').forEach((button,i)=>{
  const theme=companyDesignStyles[i];if(!theme)return;
  const preview=button.firstElementChild;preview.replaceChildren();preview.style.cssText='height:190px;margin-bottom:14px;position:relative;overflow:hidden;background:'+theme.colors[0]+';color:'+theme.colors[2]+';font-family:'+theme.font;
  const mini=document.createElement('div');mini.style.cssText='padding:12px 15px;font:700 8px Arial;letter-spacing:2px;border-bottom:1px solid '+theme.colors[5];mini.textContent='VOTRE ENTREPRISE                         MENU ☰';
  const title=document.createElement('div');title.textContent=['BÂTIR.\nTRANSFORMER.','Le goût du\ntravail bien fait.','L’espace,\nautrement.'][i];title.style.cssText='position:absolute;z-index:1;left:18px;top:52px;white-space:pre-line;font-size:'+(i===0?'26':'29')+'px;line-height:1.05;font-weight:'+(i===1?'400':'800')+';letter-spacing:-1px';
  const graphic=document.createElement('div');graphic.style.cssText='position:absolute;right:0;bottom:0;width:42%;height:140px;background:linear-gradient(150deg,transparent 30%,#0002 31%,transparent 32%),linear-gradient(35deg,'+theme.colors[5]+','+theme.colors[4]+');clip-path:'+(i===0?'polygon(22% 0,100% 0,100% 100%,0 100%)':i===1?'inset(0 round 65px 0 0 0)':'none');
  const cta=document.createElement('span');cta.textContent='DÉCOUVRIR  ↗';cta.style.cssText='position:absolute;bottom:17px;left:18px;padding:8px 10px;font:700 8px Arial;background:'+theme.colors[4]+';color:white';
  if(i===0){preview.style.background='#202624';preview.style.color='#fff';mini.style.borderColor='#ffffff30'}
  preview.append(mini,title,graphic,cta);
 });
};
const premiumPageBefore=page;
page=function(){
 const doc=parseRenderedPage(premiumPageBefore());const id=state.companyStyle;if(!Number.isInteger(id)||id<0||id>2)return serializeRenderedPage(doc);
 doc.body.classList.add('building-premium','building-'+id);
 const hero=doc.querySelector('.hero');
 if(hero){const content=doc.createElement('div');content.className='premium-hero-copy';while(hero.firstChild)content.append(hero.firstChild);hero.append(content);
  if(state.heroImage){const visual=doc.createElement('div');visual.className='premium-hero-visual';const img=doc.createElement('img');img.src=state.heroImage;img.alt=state.trade?'Notre activité : '+state.trade:'Présentation de notre entreprise';visual.append(img);hero.append(visual);hero.classList.add('premium-with-photo')}
 }
 for(const [index,card]of [...doc.querySelectorAll('.services-grid>.service-card')].entries()){const num=doc.createElement('span');num.className='premium-service-number';num.textContent=String(index+1).padStart(2,'0');card.prepend(num)}
 const style=doc.createElement('style');style.textContent=`
 .building-premium{overflow-x:clip}.building-premium>header{padding:28px 6%!important}.building-premium>section{padding:70px 6%}.building-premium .hero{position:relative;padding:76px 6%!important;border:0;border-radius:0;text-align:left;background:var(--template-bg)!important}
 .premium-hero-copy{position:relative;z-index:1;min-width:0}.building-premium .hero h1{font-size:clamp(42px,6vw,84px)!important;line-height:1.02;letter-spacing:-2.5px;max-width:900px;margin:20px 0}.building-premium .hero p{font-size:17px;line-height:1.8;max-width:540px;margin-left:0}.building-premium .hero .actions{justify-content:flex-start}
 .building-premium .hero.premium-with-photo{display:grid;grid-template-columns:1.1fr 1fr;gap:40px;align-items:center}.premium-hero-visual{min-width:0;aspect-ratio:4/5;overflow:hidden}.premium-hero-visual img{width:100%;height:100%;display:block;object-fit:cover}
 .building-premium .services-section>h2,.building-premium .realisations-section>h2{font-size:clamp(32px,4vw,52px)!important;line-height:1.12;margin:16px 0 35px;letter-spacing:-1.5px}.building-premium .service-card{position:relative;padding:26px!important}.premium-service-number{display:block;font:700 11px Arial;letter-spacing:2px;color:var(--template-accent);margin-bottom:20px}.building-premium .service-copy h3{line-height:1.2}.building-premium .service-copy p{line-height:1.8}.building-premium .service-info-button{padding:13px 20px;min-height:44px}
 .building-0>header{background:#202624;color:#fff;border:0}.building-0 .hero{background:#202624!important;color:#fff}.building-0 .hero p,.building-0 .hero .eyebrow{color:#d8ded8}.building-0 .hero h1{text-transform:uppercase;font-weight:900}.building-0 .premium-hero-visual{clip-path:polygon(12% 0,100% 0,100% 100%,0 100%)}.building-0 .services-section{border-top:8px solid var(--template-accent)}.building-0 .service-card{border:0!important;border-bottom:4px solid var(--template-accent)!important}.building-0 .realisations-section{background:#e6e9e2}
 .building-1 .hero h1{font-weight:400;letter-spacing:-2px}.building-1 .premium-hero-visual{border-radius:160px 160px 18px 18px}.building-1 .service-card{border:1px solid var(--template-border)!important;border-radius:20px!important}.building-1 .premium-service-number{font-family:Georgia;font-size:22px;font-weight:normal}.building-1 .realisations-section{border-radius:50px 50px 0 0;background:var(--template-block)}.building-1 .zone{border-radius:0;margin:0}.building-1>footer{padding:40px 6%}
 .building-2>header{border-bottom:1px solid var(--template-border)}.building-2 .hero h1{font-weight:400;letter-spacing:-3px}.building-2 .service-card{background:transparent!important;border:0!important;border-top:1px solid var(--template-border)!important;padding-left:0!important;padding-right:0!important;box-shadow:none!important}.building-2 .gallery-window{border-radius:0!important;padding:0!important;box-shadow:none!important}.building-2 .realisations-section{background:var(--template-block)}.building-2 .zone{margin:0;border-radius:0}.building-2 .contact form{padding:0;background:transparent;border:0}
 @media(max-width:760px){.building-premium>section{padding:42px 6%}.building-premium .hero.premium-with-photo{grid-template-columns:1fr;gap:28px}.building-premium .hero{padding:42px 6%!important}.building-premium .hero h1{font-size:clamp(38px,10vw,58px)!important;letter-spacing:-1.5px}.premium-hero-visual{aspect-ratio:4/3;max-height:380px}.building-1 .premium-hero-visual{border-radius:80px 80px 12px 12px}.building-premium .services-grid{grid-template-columns:1fr!important}.building-premium .hero p{font-size:15px}}
 `;doc.head.append(style);return serializeRenderedPage(doc);
};
render();update();
