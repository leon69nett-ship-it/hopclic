# Atelier — constructeur de sites artisans

Démarrer depuis ce dossier : node server.cjs
Ouvrir http://127.0.0.1:8786

Version indépendante, fichiers neufs, aucun média ou contenu repris du projet de référence.
Stockage navigateur : atelier-artisans-builder-v1. Les brouillons ne sont pas partagés entre navigateurs.

Fonctions : identité, coordonnées, blocs réordonnables/masquables/supprimables, ajout de blocs, prestations, photos locales, zone et horaires, couleurs, typographie, arrondis, aperçu ordinateur/mobile, sauvegarde/import JSON, export HTML autonome.
Les photos sont intégrées à l’export HTML. Exporter régulièrement une sauvegarde JSON, notamment avant de vider le stockage du navigateur.
Le devis prépare un e-mail dans la messagerie du visiteur ; aucun serveur de collecte n’est inclus. Renseigner l’adresse e-mail de l’entreprise pour activer le formulaire et son téléphone pour activer l’appel.
Avant mise en ligne, remplacer les exemples fictifs et compléter les informations légales adaptées à l’entreprise.

Vérifications : syntaxe JavaScript, serveur HTTP 200, affichage navigateur, changement du nom reflété dans l’aperçu, onglet blocs, aperçu mobile puis retour ordinateur.

## Nouveau parcours
Rendu du brouillon à gauche ; Entreprise, Contenu, Boutons et Design à droite. Votre offre permet de configurer marque, tarif, périodicité, service et lien de paiement HTTPS (PayPal, banque ou autre).
Configuration : http://127.0.0.1:8786/
Client gratuit : http://127.0.0.1:8786/?mode=client
Mise en ligne : http://127.0.0.1:8786/paiement.html?mode=client
Publier les modifications valide une version locale et initialise les nouveaux brouillons clients de ce navigateur. Les stockages propriétaire et client sont séparés. Exporter produit un JSON importable ; Exporter en HTML fournit le site autonome.
Cette version locale ne comprend pas encore les comptes clients, le stockage partagé, la vérification des paiements et le déploiement automatique. Le paiement reste inactif sans lien fourni. Aucun tarif n’est imposé. La connexion serveur au prestataire permettra ensuite de vérifier le règlement et autoriser l’hébergement. L’interface propriétaire locale n’a pas de protection d’accès de production.

Carte de visite : import PNG/JPEG/WebP (2 Mo), aperçu, affichage facultatif sur le site, conservation dans les sauvegardes JSON et l’export HTML. Design : six couleurs indépendantes, six palettes et extraction locale d’une couleur dominante de la carte pour proposer une palette ajustable. Aucune lecture automatique des coordonnées. Vérifications : validation import, affichage/masquage carte, styles exportés et six palettes.

## IA des photos et recherche des réalisations
Chaque réalisation conserve un titre, une description et des mots-clés. La recherche fonctionne sans IA dans ces champs, ignore les accents et combine les mots saisis. Le site HTML exporté comprend la recherche et les données enregistrées.
Le serveur propose une connexion Google Gemini pour générer ces trois champs à partir de la photo. Il ne simule aucune description si le service n’est pas configuré. Le tarif Cloud Vision mentionné précédemment ne correspond pas à cette génération Gemini : les tarifs et conditions Gemini sont à vérifier avant activation.
Configuration locale : définir GEMINI_API_KEY dans l’environnement du processus Node, puis redémarrer server.cjs. GEMINI_PHOTO_MODEL permet de choisir le modèle (défaut gemini-2.5-flash-lite). Ne jamais mettre la clé dans app.js, une sauvegarde client ou un export HTML. Aucune clé n’est fournie avec le projet.
L’analyse se déclenche après import si l’option automatique est cochée et le service connecté ; un bouton permet de la relancer. Les champs vides sont remplis, les textes existants ne sont remplacés qu’après validation d’une proposition. Les photos en ligne nécessitent que leur serveur autorise leur lecture depuis le navigateur. Les résultats restent modifiables.
Le serveur local limite l’analyse à 20 appels par heure et conserve au maximum 100 réponses en mémoire pour éviter les appels répétés. Cette connexion locale n’est pas un serveur public prêt à déployer : l’authentification des clients, les quotas persistants et l’autorisation d’accès devront être ajoutés avant exposition sur Internet.
Vérification : node --test work/photo-ai.test.cjs (depuis la racine du projet). Les réponses fournisseur sont simulées dans les tests ; aucune image n’est envoyée et aucune analyse réelle n’est facturée lors des tests.

Bibliothèque photos : onglet Photos, import multiple PNG/JPG/WebP avec conversion JPG locale (1600 px, qualité 78 %), contrôle des doublons, titres/descriptions/mots-clés, recherche sans accents, visibilité et ordre des photos. Les Réalisations et le diaporama utilisent les photos actives ; l’ordre peut varier chaque jour. Maximum 500 photos, 25 Mo par fichier importé. Stockage local IndexedDB distinct du petit stockage des réglages. Les exports JSON incluent les images ; importer une sauvegarde jusqu’à 200 Mo. Les versions validées (photos et HTML) sont conservées dans IndexedDB et l’aperçu site.html les lit. Aucun transfert serveur ni analyse IA.

Entreprise : planning de semaine type du lundi au dimanche, jusqu’à trois créneaux par jour, fermeture et copie vers les jours ouvrés. Les premiers créneaux proposés restent à vérifier ; le premier changement enregistre le planning. Affichage dans Zone & horaires, sauvegarde et export inclus. Le sélecteur d’ajout de rubrique a été retiré du menu Contenu.


Aide IA texte Cloudflare : configurer côté serveur CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_AI_TOKEN (autorisation Workers AI), ADMIN_PASSWORD ou TEST_AI_PASSWORD, puis relancer le serveur. Aucun secret dans le navigateur hormis le code saisi à chaque demande, jamais sauvegardé. Le modèle est @cf/meta/llama-3.2-3b-instruct. Le service est indépendant de Gemini photo.
Pages légales : compléter les informations dans Votre offre > Informations légales de HopClic. Données locales au navigateur : à migrer vers un stockage servi aux visiteurs avant publication. Les mentions des sites clients restent à fournir séparément. Aucun bandeau de consentement factice ajouté ; un gestionnaire bloquant réellement les traceurs facultatifs sera nécessaire si de tels traceurs sont ajoutés.

## IA photo Cloudflare (configuration actuelle)
Cloudflare Workers AI est maintenant le fournisseur par défaut. Gemini reste disponible uniquement avec PHOTO_AI_PROVIDER=gemini ; aucun basculement automatique n’envoie les photos à un autre fournisseur.

Variables à définir sur le serveur, puis redémarrer le lanceur :
- CLOUDFLARE_ACCOUNT_ID : identifiant du compte.
- CLOUDFLARE_AI_TOKEN : jeton limité au compte avec l’autorisation Workers AI (CLOUDFLARE_API_TOKEN est aussi accepté).
- CLOUDFLARE_PHOTO_MODEL : facultatif, défaut @cf/meta/llama-3.2-11b-vision-instruct.

Le compte doit avoir Workers AI activé. Ce modèle demande une acceptation préalable de la licence Meta et de sa politique d’utilisation : le propriétaire du compte doit lire les conditions, vérifier son éligibilité et activer le modèle lui-même. Le constructeur ne soumet jamais automatiquement une acceptation de conditions. Documentation : https://developers.cloudflare.com/workers-ai/guides/tutorials/llama-vision-tutorial/

Le bouton Vérifier teste l’accès au catalogue et la présence du modèle, sans analyser une photo ni accepter les conditions. Il ne garantit pas la qualité des descriptions ou la disponibilité d’une analyse. Les réponses doivent contenir un titre, une description et des mots-clés ; sinon aucun texte n’est remplacé. Secret conservé dans l’environnement Node, jamais dans les sauvegardes ou l’export HTML.

Tests : node --test work/cloudflare-photo.test.cjs. Appels simulés, aucune facturation. Le serveur reste local ; pour une mise en ligne, authentification et quotas persistants côté serveur restent nécessaires.

## Ajout des médias par lien
Les bibliothèques Photos et Vidéos proposent Ajouter par lien. HTTPS uniquement, sans identifiants dans l’URL, titre obligatoire. Photos : lien direct public ; copie optimisée si le serveur distant autorise son téléchargement, sinon référence distante. Vidéos : YouTube ou fichier MP4/WebM ; hébergement d’origine conservé. La disponibilité et les droits d’utilisation restent à vérifier par le propriétaire du média. Les médias ajoutés sont réutilisables dans les sélecteurs existants.

## SEO automatique
La rubrique Fiche entreprise Google a été retirée du constructeur et ses liens ne sont plus ajoutés au pied de page. Ses anciennes données restent dans les sauvegardes pour permettre leur récupération.
Le mode SEO automatique remplit titre, description et textes de partage à partir du nom, métier, secteur et contenu visible. Aucun appel IA. Activé par défaut si les quatre textes sont vides ; les textes déjà personnalisés sont conservés. Modifier un texte ou appliquer une proposition IA désactive le mode automatique. Le domaine définitif et l’image de partage restent à renseigner. Les métadonnées sont incluses dans l’export ; aucune garantie de classement ou d’indexation.

## Connexion Google Search Console — parcours préparé
Le constructeur propose Connecter Google, Préparer la validation, Valider mon site en ligne et Envoyer le sitemap. Aucun appel réel Google n’a été effectué pendant les tests.
Configuration serveur : GOOGLE_CLIENT_ID et GOOGLE_CLIENT_SECRET (client OAuth Google de type application Web). Activer Search Console API et Google Site Verification API dans le projet Google Cloud. Déclarer exactement http://127.0.0.1:8786/api/google-search/callback comme URI de retour autorisée pour le lanceur local. Configurer l’écran de consentement et les utilisateurs de test, ou réaliser la validation Google requise avant ouverture aux clients. Ne jamais placer le secret dans le navigateur.
Autorisations : webmasters pour Search Console et siteverification.verify_only pour vérifier la propriété. La connexion passe par Google, avec état anti-CSRF, PKCE et cookie HttpOnly SameSite=Lax. Jetons conservés uniquement en mémoire pendant la session, sans sauvegarde client ; reconnecter après redémarrage ou expiration. Pas d’enregistrement de mot de passe Google.
Le code META obtenu est ajouté au prochain export HTML uniquement pour l’adresse exacte du site validé. Il faut publier cet export avant de demander la validation. Télécharger sitemap.xml puis le déposer sur l’hébergement à l’adresse indiquée, avant de l’envoyer à Google. Le déploiement automatique du site et du sitemap n’est pas raccordé dans le constructeur local. L’envoi d’un sitemap ne garantit aucune indexation ni position.
Ce raccordement est réservé au serveur local 127.0.0.1. Un service multi-client hébergé nécessite sessions et identité par client, stockage sécurisé des jetons et adaptation de l’URI de retour HTTPS.
Tests : node --test work/google-search.test.cjs (fournisseur simulé).

IA photo : les appels du navigateur passent désormais uniquement par le serveur du constructeur, sans priorité donnée au serveur compagnon 8787. Un serveur qui annonce encore Gemini bloque les analyses et demande un redémarrage. La clé Cloudflare et l’activation du modèle restent nécessaires après le redémarrage.
