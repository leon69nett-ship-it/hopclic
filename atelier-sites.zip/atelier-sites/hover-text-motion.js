// Legacy preference migration: text must remain still on hover.
(() => {
  const validateBeforeHoverTextMotion = validate;
  validate = saved => ({ ...validateBeforeHoverTextMotion(saved), hoverTextMotion: false });
  const pageBeforeHoverTextMotion = page;
  page = () => pageBeforeHoverTextMotion();
  if (typeof state === 'object') state.hoverTextMotion = false;
})();
