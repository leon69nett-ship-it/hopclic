function homeCtaSettings(block) {
  if (block.homeCtasInitialized && Array.isArray(block.homeCtas)) return block.homeCtas;
  const contact = state.blocks.find(item => item.type === 'contact' && item.visible !== false);
  block.homeCtas = contact ? [{ label: 'Nous contacter', targetId: contact.id, icon: 'plus' }] : [];
  block.homeCtasInitialized = true;
  return block.homeCtas;
}

const pageBeforeHomeCtaControls = page;
page = function () {
  const doc = parseRenderedPage(pageBeforeHomeCtaControls());
  const block = state.blocks.find(item => item.type === 'intro' && item.visible);
  const hero = doc.querySelector('.hero');
  if (!block || !hero) return serializeRenderedPage(doc);

  const contactBlock = state.blocks.find(item => item.type === 'contact' && item.visible !== false);
  const contactSection = doc.querySelector('body > section.contact') || doc.querySelector('.quote-form')?.closest('section');
  if (contactBlock && contactSection) {
    doc.querySelectorAll('[id="devis"]').forEach(element => { if (element !== contactSection) element.removeAttribute('id'); });
    contactSection.id = 'devis';
  }

  const buttons = homeCtaSettings(block);
  let actions = hero.querySelector('.template-hero-actions')
    || hero.querySelector('.meta-actions')
    || hero.querySelector('.habitat-hero-actions')
    || hero.querySelector('.actions');
  if (!actions) {
    actions = doc.createElement('div');
    actions.className = 'template-hero-actions';
    (hero.querySelector('.premium-hero-copy') || hero).append(actions);
  }
  for (const duplicate of hero.querySelectorAll('.template-hero-actions,.meta-actions,.habitat-hero-actions,.actions')) {
    if (duplicate !== actions) duplicate.remove();
  }
  actions.classList.add('template-hero-actions');
  actions.replaceChildren();

  for (const button of buttons) {
    const destination = button.targetId === 'phone'
      ? null
      : state.blocks.find(item => item.id === button.targetId && item.visible !== false);
    const href = button.targetId === 'phone' && state.phone
      ? 'tel:' + state.phone.replace(/[^+\d]/g, '')
      : destination
        ? destination.type === 'contact' ? '#devis' : '#rubrique-' + destination.id
        : '';
    if (!href || !button.label?.trim()) continue;
    const link = doc.createElement('a');
    link.href = href;
    link.textContent = button.label.trim();
    if (destination?.type === 'contact') {
      link.setAttribute('onclick', "event.preventDefault();const contact=document.querySelector('section.contact')||document.getElementById('devis');if(contact)contact.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'})");
    }
    link.dataset.freePlacementBlock = block.id;
    link.dataset.freePlacementKey = 'bouton-0';
    const placement = block.freePlacements?.['bouton-0'] || { x: 0, y: 0 };
    link.dataset.freePlacementX = String(placement.x || 0);
    link.dataset.freePlacementY = String(placement.y || 0);
    const buttonScale = Math.max(.55, Math.min(1.5, Number(block.homeCtaScale) || 1));
    link.dataset.homeCta = 'true';
    link.dataset.homeCtaScale = String(buttonScale);
    link.style.position = 'relative';
    link.style.scale = String(buttonScale);
    const resizeHandle = doc.createElement('span');
    resizeHandle.className = 'home-cta-resize';
    resizeHandle.textContent = '↘';
    resizeHandle.setAttribute('aria-hidden', 'true');
    link.append(resizeHandle);
    actions.append(link);
  }
  if (!actions.childElementCount) actions.remove();
  const resizeStyle = doc.createElement('style');
  resizeStyle.textContent = '.home-cta-resize{display:none;position:absolute;right:-8px;bottom:-8px;z-index:3;place-items:center;width:22px;height:22px;border:2px solid #fff;border-radius:50%;background:#8e3d25;color:#fff;font:700 14px/1 Arial;box-shadow:0 2px 8px #2b1b1670;cursor:nwse-resize}body.free-placement-mode .home-cta-resize{display:grid}';
  doc.head.append(resizeStyle);
  return serializeRenderedPage(doc);
};

update();
