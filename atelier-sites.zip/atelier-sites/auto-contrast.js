function contrastRGB(hex){return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255)}
function contrastLuminance(hex){return contrastRGB(hex).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4).reduce((sum,v,i)=>sum+v*[.2126,.7152,.0722][i],0)}
function contrastRatio(a,b){const x=contrastLuminance(a),y=contrastLuminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)}
function mixContrastColor(a,b,t){return '#'+contrastRGB(a).map((v,i)=>Math.round((v*(1-t)+contrastRGB(b)[i]*t)*255).toString(16).padStart(2,'0')).join('')}
function prepareContrastPalette(){
 const background=state.background||'#faf3ed';
 const light=contrastLuminance(background)>.35;
 const block= mixContrastColor(background,light?'#ffffff':'#000000',light?.68:.25);
 const text=['#241b17','#ffffff'].sort((a,b)=>Math.min(contrastRatio(b,background),contrastRatio(b,block))-Math.min(contrastRatio(a,background),contrastRatio(a,block)))[0];
 let accent=state.accent||'#a74729';
 for(let i=0;i<100&&(contrastRatio(accent,background)<4.5||contrastRatio(accent,block)<4.5);i++)accent=mixContrastColor(accent,text,.06);
 state.blockBackground=block;state.textColor=text;state.secondaryColor=text;
 state.borderColor=mixContrastColor(block,text,.3);state.accent=accent;state.selectionColor=accent;state.useCardColors=false;
 render();update();
}
const renderBeforeAutoContrast=render;
render=function(){renderBeforeAutoContrast();if(tab!=='design')return;
 const panel=document.createElement('div');const heading=document.createElement('h3');heading.textContent='Couleurs automatiques';
 const note=document.createElement('p');note.className='hint';note.textContent='Conservez votre fond et adaptez automatiquement les blocs, les textes et les boutons pour un rendu lisible.';
 const button=document.createElement('button');button.type='button';button.textContent='🎨 Harmoniser avec mon fond';button.onclick=prepareContrastPalette;
 panel.append(heading,note,button);document.querySelector('#editor').prepend(panel);
};
const pageBeforeAutoContrast=page;
page=function(){const doc=parseRenderedPage(pageBeforeAutoContrast());
 const style=doc.createElement('style');const onAccent=contrastRatio(state.accent,'#ffffff')>=4.5?'#ffffff':'#241b17';
 style.textContent=`body>header a:not(.button),footer a{color:inherit}.zone{color:${onAccent}}.zone p{color:${onAccent}}.service-info-button,.promotion-buy,a.button,.contact button[type=submit]{background:${state.accent};color:${onAccent}!important}`;
 doc.head.append(style);return serializeRenderedPage(doc);
};
render();
