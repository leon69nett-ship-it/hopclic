const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');

const app = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8');
const start = app.indexOf('function normaliseSavedPlacements(');
const end = app.indexOf('function validate(s)', start);
if (start < 0 || end < 0) throw new Error('Placement validation helper was not found');
const normaliseSavedPlacements = Function(`${app.slice(start, end)}; return normaliseSavedPlacements`)();
const placementCode = fs.readFileSync(path.join(__dirname, 'free-block-placement.js'), 'utf8');
const builderPage = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const paymentPage = fs.readFileSync(path.join(__dirname, 'paiement.html'), 'utf8');
const stylesheet = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
const neonBlockSelector = fs.readFileSync(path.join(__dirname, 'builder-block-selector-neon.css'), 'utf8');
const neonNavStyle = fs.readFileSync(path.join(__dirname, 'builder-nav-neon.css'), 'utf8');
const photoLibrary = fs.readFileSync(path.join(__dirname, 'library.js'), 'utf8');
const videoLibrary = fs.readFileSync(path.join(__dirname, 'video-library.js'), 'utf8');
const siteWidthScript = fs.readFileSync(path.join(__dirname, 'site-width.js'), 'utf8');
const buttonSelector = fs.readFileSync(path.join(__dirname, 'design-button-selector.js'), 'utf8');
const modernButtons = fs.readFileSync(path.join(__dirname, 'modern-site-buttons.js'), 'utf8');
const siteButtonsModern = fs.readFileSync(path.join(__dirname, 'site-buttons-modern.js'), 'utf8');
const siteLayout = fs.readFileSync(path.join(__dirname, 'site-layout-picker.js'), 'utf8');
const directPreviewEdit = fs.readFileSync(path.join(__dirname, 'direct-preview-edit.js'), 'utf8');
const homeTitleAnimation = fs.readFileSync(path.join(__dirname, 'home-title-animation.js'), 'utf8');
const homeLoadingAnimation = fs.readFileSync(path.join(__dirname, 'home-loading-animation.js'), 'utf8');
const previewLayoutControls = fs.readFileSync(path.join(__dirname, 'preview-layout-controls.js'), 'utf8');
const previewBlockResize = fs.readFileSync(path.join(__dirname, 'preview-block-resize.js'), 'utf8');
const hoverTextMotion = fs.readFileSync(path.join(__dirname, 'hover-text-motion.js'), 'utf8');
const siteOrganization = fs.readFileSync(path.join(__dirname, 'site-organization.js'), 'utf8');
const scrollMediaTransition = fs.readFileSync(path.join(__dirname, 'scroll-media-transition.js'), 'utf8');
const paymentPageBlock = fs.readFileSync(path.join(__dirname, 'payment-page-block.js'), 'utf8');
const promotions = fs.readFileSync(path.join(__dirname, 'promotions.js'), 'utf8');
const paymentPageReferenceLayout = fs.readFileSync(path.join(__dirname, 'payment-page-reference-layout.js'), 'utf8');
const paintSplash = fs.readFileSync(path.join(__dirname, 'palette-paint-splash.js'), 'utf8');
const interactiveProjects = fs.readFileSync(path.join(__dirname, 'interactive-projects.js'), 'utf8');
const beforeAfter = fs.readFileSync(path.join(__dirname, 'project-before-after.js'), 'utf8');
const placementGroups = placementCode.match(/const buttonGroupFor = target => target\.closest\('([^']+)'\)/)?.[1] || '';

test('saved button position and size survive initial state validation', () => {
  assert.deepEqual(normaliseSavedPlacements({
    'bouton-0': { x: -18, y: 26, scale: 1.2, width: 144, height: 52, anchor: 'service-card-centered' },
    'image-2': { x: 8, y: -4 },
    'bouton-2': { x: 12, y: -8, anchor: 'responsive-copy' },
    broken: { x: 8, y: 3 },
    'bouton-1': { x: 'bad', y: 0 }
  }), {
    'bouton-0': { x: -18, y: 26, scale: 1.2, width: 144, height: 52, anchor: 'service-card-centered' },
    'image-2': { x: 8, y: -4 },
    'bouton-2': { x: 12, y: -8, anchor: 'responsive-copy' }
  });
});

test('buttons can move across their whole block while service detail links stay anchored to their cards', () => {
  assert.match(placementCode, /const placementBasisFor = \(target, section\) => serviceCardFor\(target\) \|\| section/);
  assert.match(placementCode, /isResponsiveCopyAnchor\(saved\.anchor\)[\s\S]*?x: rect\.width \? copyRect\.width \* saved\.x \/ rect\.width[\s\S]*?anchor: undefined/);
  assert.match(builderPage, /free-block-placement\.js\?v=39/);
});

test('published positioning script keeps service buttons centered and inside their cards', () => {
  const template = placementCode.match(/positionScript\.textContent = `([\s\S]*?)`;/)?.[1];
  assert.ok(template, 'published positioning script should exist');
  const script = Function(`return \`${template}\``)();
  assert.doesNotThrow(() => new Function(script));
  assert.match(script, /service-card-centered/);
  assert.match(script, /responsive-copy/);
  assert.match(script, /margin-left/);
  assert.match(script, /correction/);
  assert.match(script, /contentLeft/);
});

test('preview lets clients resize blocks, move the left navigation and resize the left column', () => {
  assert.doesNotMatch(app, /\[data-editor-block\]\{padding-top:max\(50px,4%\)!important\}/, 'editor controls must not add spacing that changes the visitor layout');
  assert.ok(builderPage.includes('preview-layout-controls.js?v=9'));
  assert.match(previewLayoutControls, /renderSize: cleanSize\(saved\?\.blocks\?\.\[index\]\?\.renderSize\)/);
  assert.doesNotMatch(previewLayoutControls, /preview-block-resize/, 'height controls are managed by one preview script');
  assert.match(previewLayoutControls, /Déplacer le menu dans la colonne de gauche/);
  assert.match(builderPage, /preview-rail-resize-overlay/);
  assert.match(builderPage, /Tirer pour régler la largeur de la colonne de gauche/);
  assert.match(builderPage, /state\.railWidth = clampRail\(drag\.width \+ \(\(event\.clientX \|\| drag\.x\) - drag\.x\) \/ drag\.scale\)/);
  assert.match(previewLayoutControls, /railMenuX/);
  assert.match(previewLayoutControls, /railMenuY/);
  assert.doesNotMatch(previewLayoutControls, /validLayout\(/, 'the preview controls must not call a helper scoped to another script');
  assert.match(previewLayoutControls, /update\(\)/);
});

test('button design panel offers the emerald and gold look in its preview and published style', () => {
  assert.match(builderPage, /\['emerald', 'Émeraude & or'\]/);
  assert.match(builderPage, /look-emerald/);
  assert.match(builderPage, /data-site-button-look="emerald"/);
  assert.match(buttonSelector, /id: 'emerald', title: 'Émeraude & or'/);
  assert.match(buttonSelector, /body\[data-site-button-look="emerald"\]/);
  assert.match(buttonSelector, /Choisir le style/);
  assert.match(buttonSelector, /site-button-look-choice strong\{display:none!important/);
  assert.match(builderPage, /site-button-look-choice strong\{display:none!important/);
  assert.match(buttonSelector, /Angulaire/);
  assert.match(buttonSelector, /Rectangulaire/);
  assert.match(buttonSelector, /Pilule/);
  assert.match(buttonSelector, /Forme du bouton classique/);
  assert.match(buttonSelector, /if \(look === 'classic'\) button\.style\.setProperty\('border-radius'/);
});

test('builder navigation uses the orange arrow color for its neon highlight', () => {
  assert.match(neonNavStyle, /#fe7d01/);
  assert.match(neonNavStyle, /#tabs button\.active/);
  assert.match(neonNavStyle, /#65360f/);
});

test('builder content menu uses independent neon cards and retains visibility states', () => {
  assert.match(builderPage, /builder-block-selector-neon\.css\?v=9/);
  assert.match(neonBlockSelector, /#editor > \.content-menu/);
  assert.match(neonBlockSelector, /button\.content-choice\.is-current/);
  assert.match(neonBlockSelector, /button\.content-choice:not\(\.is-visible\):not\(\.is-current\)/);
  assert.match(neonBlockSelector, /\.choice-copy strong/);
  assert.match(neonBlockSelector, /\.choice-icon svg/);
  assert.match(neonBlockSelector, /color: #fff !important/);
  assert.match(neonBlockSelector, /min-height: 96px !important/);
  assert.match(neonNavStyle, /-webkit-text-fill-color: #fff !important/);
  assert.match(neonBlockSelector, /prefers-reduced-motion: reduce/);
  assert.match(neonBlockSelector, /#fe7d01/);
  assert.doesNotMatch(neonBlockSelector, /#(?:51204d|211326|160f1c|a55a9d|ff9ce9|f257da)/i);
});

test('existing builder navigation keeps its actions and receives the logo-orange neon style', () => {
  for (const tab of ['blocks', 'design', 'effects', 'buttons', 'platform']) {
    assert.ok(builderPage.includes(`data-tab="${tab}"`), `missing existing tab: ${tab}`);
  }
  assert.match(photoLibrary, /dataset\.tab='library'/);
  assert.match(videoLibrary, /dataset\.tab='videos'/);
  assert.match(neonNavStyle, /#tabs button\.active/);
  assert.match(neonNavStyle, /#fe7d01/);
  assert.doesNotMatch(neonNavStyle, /#(?:421c40|211325|160e1b|87518b|f6a3ee|ff9de7)/i);
  assert.match(neonNavStyle, /#tabs button:nth-last-child\(2\)/);
  assert.doesNotMatch(neonNavStyle, /#tabs\[aria-hidden=/);
  assert.match(builderPage, /builder-nav-neon\.css\?v=6/);
  assert.doesNotMatch(builderPage, /builder-type-menu/);
});

test('video library places PC import first and accepts secure video links', () => {
  assert.match(videoLibrary, /editor\.append\(heading,help,upload,input,add,manage\)/);
  assert.match(videoLibrary, /Importer des vidéos depuis mon PC/);
  assert.match(videoLibrary, /Ajouter une vidéo par lien/);
  assert.match(videoLibrary, /videoSource\(url\.value\.trim\(\)\)/);
  assert.match(builderPage, /video-library\.js\?v=cloudflare-photo-184/);
});

test('button resize scale is preserved in the visitor site and block controls stay compact', () => {
  assert.match(placementCode, /target\.style\.setProperty\('scale', String\(siteScale \* savedScale\), 'important'\)/);
  assert.match(app, /preview-block-tools button\{display:flex!important;align-items:center!important;justify-content:center!important;padding:0!important;width:28px!important/);
  assert.match(builderPage, /for \(const button of doc\.querySelectorAll\('\.preview-block-tools button'\)\)/);
  assert.match(builderPage, /minWidth: '20px'/);
  assert.match(builderPage, /minHeight: '20px'/);
});

test('classic button shape controls are inserted into the panel shown in the builder', () => {
  assert.match(builderPage, /ensureButtonShapeControl\(existing\)/);
  assert.match(builderPage, /ensureButtonShapeControl\(panel\)/);
  assert.match(builderPage, /site-button-shape-control/);
  assert.match(builderPage, /state\.siteButtonShape = id/);
  assert.match(builderPage, /site-button-shape-sample'\)\.style, \{/);
  assert.match(builderPage, /background: state\.accent, color: '#fff'/);
  assert.match(builderPage, /color: '#fff'/);
  assert.match(builderPage, /setProperty\('-webkit-text-fill-color', '#fff', 'important'\)/);
  assert.match(buttonSelector, /background:\$\{state\.accent\}!important;color:\$\{paletteButtonText\(state\.accent\)\}/);
  assert.match(buttonSelector, /site-button-shape-control\{[^}]*background:#fff/);
});

test('service detail buttons keep their label and icon inside narrow cards', () => {
  assert.match(app, /\.service-info-button\{display:flex;width:max-content;margin:10px auto 0\}/);
  assert.match(placementCode, /measureText\(labelText\)/);
  assert.match(placementCode, /target\.dataset\.serviceButtonCompact = String\(compact\)/);
  assert.match(placementCode, /target\.style\.setProperty\('display', 'flex', 'important'\)/);
  assert.match(placementCode, /el\.style\.setProperty\('display','flex','important'\)/);
  assert.match(placementCode, /el\.style\.setProperty\('margin-left','auto','important'\)/);
  assert.match(modernButtons, /\.modern-action-button\.service-info-button::after\{flex-basis:22px;width:22px;height:22px/);
  assert.match(modernButtons, /data-service-button-compact="true"\]::after\{display:none!important/);
});

test('selected block layout overrides conflicting template and organization widths', () => {
  assert.match(app, /z-index:2147483001/);
  assert.match(app, /z-index:2147483000;box-shadow:0 8px 30px/);
  assert.match(siteLayout, /section\.classList\.contains\('hero'\) \? 'Entreprise'/);
  assert.match(siteLayout, /section\.classList\.contains\('services-section'\) \? 'Prestations'/);
  assert.match(siteLayout, /filter\(section => !section\.classList\.contains\('services-section'\)\)/);
  assert.match(siteLayout, /nav\.setAttribute\('aria-label', 'Navigation principale'\)/);
  assert.match(siteLayout, /grid-template-columns:minmax\(220px,280px\) minmax\(0,1fr\)!important/);
  assert.match(siteLayout, /z-index:2147483000!important;isolation:isolate/);
  assert.match(siteLayout, /body\[data-block-presentation="left-rail"\]>header \.call\{display:none!important\}/);
  assert.match(siteLayout, /body\[data-block-presentation="left-rail"\]>header nav,body\[data-block-presentation="right-rail"\]>header nav\{display:flex!important;flex-direction:column;align-items:stretch;width:100%;max-height:none;overflow:visible;gap:0\}/);
  assert.match(siteLayout, /body\[data-block-presentation="left-rail"\]>section\.hero\{grid-column:2!important;grid-row:1/);
  assert.match(siteLayout, /diagram-content-header/);
  assert.match(siteLayout, /#editor \.diagram-left-rail \.diagram-block:nth-of-type\(4\),#editor \.diagram-left-rail \.diagram-block:nth-of-type\(5\)\{display:none\}/);
  assert.match(siteLayout, /description: 'Logo et menu à gauche, en-tête du contenu en haut à droite\.'/);
  assert.match(siteLayout, /link\.setAttribute\('onclick', "event\.preventDefault\(\);event\.stopPropagation\(\);const target=document\.getElementById\(this\.hash\.slice\(1\)\)/);
  assert.match(siteLayout, /target\.scrollIntoView\(\{behavior:\['compact','static'\]\.includes\(document\.body\.dataset\.siteMenuPresentation\)\?'instant':window\.matchMedia/);
  assert.match(siteLayout, /body\[data-site-menu-presentation="compact"\]>header :is\(\.site-menu-toggle,nav\.site-menu,nav\.site-menu a\)\{animation:none!important;transition:none!important\}/);
  assert.match(siteLayout, /header\?\.classList\.remove\('menu-open'\)/);
  assert.match(siteLayout, /railWidth: \{ initial: 280, min: 220, max: 420/);
  assert.match(siteLayout, /railCompanyHeight: \{ initial: 180, min: 120, max: 420/);
  assert.match(siteLayout, /const validMenuPresentation = mode => \['compact', 'static'\]\.includes\(mode\) \? mode : 'bar'/);
  assert.match(siteLayout, /result\.siteMenuPresentation = validMenuPresentation\(saved\?\.siteMenuPresentation \?\? state\.siteMenuPresentation\)/);
  assert.match(siteLayout, /site-menu-presentation/);
  assert.match(siteLayout, /Classique puis compact au défilement/);
  assert.match(siteLayout, /Menu compact comme sur mobile/);
  assert.match(siteLayout, /Menu classique sans animation/);
  assert.match(siteLayout, /const ensureMenuEffectsControl = \(\) =>/);
  assert.match(siteLayout, /if \(tab !== 'effects'\) return;/);
  assert.match(siteLayout, /body\[data-site-menu-presentation="static"\]>header :is\(\.site-menu-toggle,nav\.site-menu,nav\.site-menu a\)\{animation:none!important;transition:none!important\}/);
  assert.match(siteLayout, /body\[data-site-menu-presentation="static"\]>header,body\[data-site-menu-presentation="static"\]>header \*\{animation:none!important;animation-timeline:auto!important;transition:none!important;transform:none!important;scroll-behavior:auto!important\}/);
  assert.match(siteLayout, /body\[data-site-menu-presentation="static"\]>\.site-menu-flight\{display:none!important;visibility:hidden!important;animation:none!important;transform:none!important\}/);
  assert.match(siteLayout, /body\[data-site-menu-presentation="static"\]>header \.site-menu-toggle\{display:inline-flex!important;position:fixed!important/);
  assert.match(siteLayout, /const threshold = 140/);
  assert.ok(siteLayout.includes("header.classList.add('menu-scrolled')"));
  assert.match(siteLayout, /body\[data-site-menu-presentation="bar"\]>header\.menu-scrolled \.site-menu-toggle\{display:inline-flex!important;position:fixed!important/);
  assert.match(siteLayout, /body\[data-site-menu-presentation="bar"\]>header\.menu-scrolled\.menu-open nav\.site-menu\{display:flex!important;position:fixed!important/);
  assert.match(siteLayout, /link\.animate\(\[/);
  assert.match(siteLayout, /target\.x - \(rect\.left \+ rect\.width \/ 2\)/);
  assert.match(siteLayout, /const formationPoint = \(\) =>/);
  assert.match(siteLayout, /const dx = target\.x - destination\.x;/);
  assert.match(siteLayout, /const nx = -uy;/);
  assert.match(siteLayout, /const ny = ux;/);
  assert.match(siteLayout, /flightElement = toggle\.cloneNode\(true\)/);
  assert.match(siteLayout, /flightElement\.className = 'site-menu-toggle site-menu-flight'/);
  assert.match(siteLayout, /flightElement\.removeAttribute\('onclick'\)/);
  assert.match(siteLayout, /font:\$\{toggleStyle\.font\}/);
  assert.match(siteLayout, /flightElement\.animate\(frames/);
  assert.match(siteLayout, /menu-flight-active/);
  assert.match(siteLayout, /offset: \.1, transform: `translate\(\$\{dx\}px,\$\{dy\}px\) scale\(1\) rotate\(0\)`/);
  assert.match(siteLayout, /const loopRadius = Math\.min\(46, Math\.max\(18, distance \* \.08\)\)/);
  assert.match(siteLayout, /const centerX = dx \* \.5;/);
  assert.match(siteLayout, /const centerY = dy \* \.5;/);
  assert.match(siteLayout, /offset: \.24, transform: `translate\(\$\{loopEntryX\}px,\$\{loopEntryY\}px\)/);
  assert.match(siteLayout, /for \(let step = 0; step <= 32; step\+\+\)/);
  assert.match(siteLayout, /Math\.cos\(angle\)/);
  assert.match(siteLayout, /rotate\(\$\{step \* 11\.25\}deg\)/);
  assert.match(siteLayout, /duration: 1800/);
  assert.match(siteLayout, /}, 1900\);/);
  assert.match(siteLayout, /header\.classList\.remove\('menu-flight-active'\);/);
  assert.match(siteLayout, /header\.classList\.remove\('menu-transition-in', 'menu-flight-active'\)/);
  assert.match(siteLayout, /menu-transition-in/);
  assert.match(siteLayout, /header:not\(\.menu-scrolled\) nav\.site-menu\{position:static!important;display:flex!important;flex:0 0 auto!important;flex-direction:column!important;align-items:stretch!important;justify-content:flex-start!important;gap:4px!important/);
  assert.match(siteLayout, /body\[data-block-presentation="left-rail"\]\[data-site-menu-presentation="bar"\]>header\.with-business-card>div\.site-company-panel\{flex:0 0 auto!important\}/);
  assert.match(siteLayout, /body\[data-site-menu-presentation="compact"\]>header nav\.site-menu\{display:none!important;position:fixed!important/);
  assert.match(directPreviewEdit, /text\.closest\('\.carousel-photo-card,\.gallery-window,\.interactive-photo-card'\)/);
  assert.ok(directPreviewEdit.includes("libraryPhoto&&text.matches('h3')?{obj:libraryPhoto,key:'title'}"));
  assert.ok(interactiveProjects.includes('.interactive-detail-dialog h2{font:400 clamp(38px,5vw,48px)/1.12 Georgia!important'), 'interactive photo detail titles should be enlarged');
  assert.ok(interactiveProjects.includes('.interactive-photo-card>h3{font-size:clamp(24px,3vw,34px);line-height:1.15'), 'interactive photo captions should be enlarged');
  assert.ok(builderPage.includes('interactive-projects.js?v=403'), 'the builder should load the draggable photo markers');
  assert.doesNotMatch(siteLayout, /railMenuWidth: \{ initial:/);
  assert.doesNotMatch(siteLayout, /railMenuOffset: \{ initial:/);
  assert.match(siteLayout, /editor\.addEventListener\('click', event =>/);
  assert.match(siteLayout, /state\.blockPresentation = layout/);
  assert.match(siteLayout, /getElementById\('block-presentation-layouts'\)\?\.remove\(\)/);
  assert.match(siteLayout, /Hauteur du bloc Entreprise/);
  assert.match(siteLayout, /Le menu prend la largeur du bloc Entreprise et remplit l’espace disponible à gauche/);
  assert.doesNotMatch(siteLayout, /Largeur du menu/);
  assert.doesNotMatch(siteLayout, /Espace avant le menu/);
  assert.match(siteLayout, /className = 'site-company-panel'/);
  assert.match(siteLayout, /body\[data-block-presentation="left-rail"\]>header\{padding:20px 24px!important;gap:10px!important\}/);
  assert.match(siteLayout, /body\[data-block-presentation="left-rail"\]>header nav\.site-menu\{box-sizing:border-box;width:100%!important;min-width:0!important;min-height:120px;height:auto!important;max-height:calc\(100vh - \$\{state\.railCompanyHeight\}px - 50px\)!important;flex:1 1 auto!important;margin-top:0!important;justify-content:flex-start;gap:8px!important/);
  assert.match(siteLayout, /#editor \.diagram-left-rail \.diagram-main\{grid-column:2\/-1;grid-row:2\/-1;background:#bdbdbd\}/);
  assert.ok(builderPage.includes('site-layout-picker.js?v=45'), 'the builder should load the updated layout controls');
  assert.match(siteLayout, /site-menu-heading-icon/);
  assert.match(siteLayout, /menuHeading\.prepend\(menuIcon\)/);
  assert.match(neonBlockSelector, /\.site-menu-heading-icon svg/);
  assert.match(builderPage, /normalizeBuilderTabLabels\(\)/);
  assert.match(builderPage, /builder-tab-label/);
  assert.match(builderPage, /font-size:12px!important/);
  assert.doesNotMatch(previewLayoutControls, /preview-block-resize/, 'height handles should have a single implementation');
  assert.match(siteLayout, /body\[data-block-presentation="centered"\]>section:not\(\.business-card\)\{width:min\(100%,1200px\);margin-inline:auto\}/);
  assert.match(siteLayout, /body\[data-block-presentation="centered"\] \.services-section \.services-grid,body\[data-block-presentation="centered"\] \.presentation-gallery\{grid-template-columns:minmax\(0,1fr\)!important\}/);
  assert.match(siteLayout, /body\[data-block-presentation="panorama"\] \.services-section \.services-grid\{grid-template-columns:repeat\(3,minmax\(0,1fr\)\)!important\}/);
  assert.match(siteLayout, /#editor \.diagram-centered\{grid-template-columns:minmax\(0,1fr\);grid-template-rows:10px repeat\(2,minmax\(0,1fr\)\)\}/);
  assert.match(siteLayout, /#editor \.diagram-centered \.diagram-main\{grid-column:1;grid-row:2\/-1;background:#bdbdbd\}/);
  assert.match(siteLayout, /#editor \.diagram-centered \.diagram-block:nth-of-type\(3\),#editor \.diagram-centered \.diagram-block:nth-of-type\(4\),#editor \.diagram-centered \.diagram-block:nth-of-type\(5\)\{display:none\}/);
  assert.match(siteLayout, /description: 'Blocs alignés dans une colonne équilibrée\.'/i);
  assert.match(siteLayout, /#editor \.diagram-cards\{grid-template-columns:repeat\(2,minmax\(0,1fr\)\);grid-template-rows:12px repeat\(2,minmax\(0,1fr\)\)\}/);
  assert.match(siteLayout, /#editor \.diagram-cards \.diagram-block:nth-of-type\(5\)\{grid-column:2;grid-row:3;display:block\}/);
  assert.ok(siteLayout.includes('body[data-block-presentation="cards"] .services-section .services-grid,body[data-block-presentation="cards"] .presentation-gallery{grid-template-columns:repeat(2,minmax(0,1fr))!important'));
  assert.ok(siteLayout.includes('body[data-block-presentation="cards"]{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important'));
  assert.ok(siteLayout.includes('body[data-block-presentation="cards"]>header,body[data-block-presentation="cards"]>section.business-card,body[data-block-presentation="cards"]>section.hero,body[data-block-presentation="cards"]>footer{grid-column:1/-1!important}'));
  assert.ok(siteLayout.includes('body[data-block-presentation="cards"]>section:not(.business-card):not(.hero){box-sizing:border-box;width:auto!important'));
  assert.ok(siteLayout.includes('body[data-block-presentation="cards"]{grid-template-columns:minmax(0,1fr)!important;row-gap:14px}'));
  assert.ok(siteLayout.includes('body[data-block-presentation="panorama"]{width:100%!important;max-width:none!important}'));
  assert.match(siteOrganization, /const panorama = state\.blockPresentation === 'panorama'/);
  assert.match(siteOrganization, /const sideNavigation = state\.blockPresentation === 'left-rail' \|\| state\.blockPresentation === 'right-rail'/);
  assert.match(siteOrganization, /const fullWidth = panorama \|\| sideNavigation \|\| state\.organizationWidth === 'full' \|\| state\.siteWidth === 'full'/);
  assert.match(siteOrganization, /body>section:not\(\.business-card\):not\(\.scroll-media-transition\)/);
});

test('the company name no longer animates', () => {
  assert.match(homeTitleAnimation, /result\.companyNameAnimation = 'none'/);
  assert.match(homeTitleAnimation, /state\.companyNameAnimation = 'none'/);
  assert.doesNotMatch(homeTitleAnimation, /Rejouer l’animation du nom de l’entreprise/);
  assert.doesNotMatch(homeTitleAnimation, /Animation du nom de l’entreprise/);
  assert.match(homeTitleAnimation, /if \(tab !== 'effects'\) return;/);
  assert.match(homeTitleAnimation, /effectsGroup\.append\(settings\)/);
  assert.ok(builderPage.includes('home-title-animation.js?v=16'), 'the builder should load the updated title behavior');
});

test('homepage loading animation is managed in Effects instead of inside the content block', () => {
  assert.match(homeLoadingAnimation, /if \(tab !== 'effects'\) return;/);
  assert.match(homeLoadingAnimation, /effectsGroup\.append\(group\)/);
  assert.match(homeLoadingAnimation, /effectsGroup\.lastElementChild !== loadingControls\) effectsGroup\.append\(loadingControls\)/);
  assert.match(homeLoadingAnimation, /new MutationObserver\(keepLoadingControlsAtBottom\)\.observe\(effectsGroup, \{childList: true\}\)/);
  assert.ok(builderPage.includes('home-loading-animation.js?v=11'));
});

test('text stays still on hover, including when loading an older saved configuration', () => {
  assert.match(app, /hoverTextMotion:false/);
  assert.match(hoverTextMotion, /hoverTextMotion: false/);
  assert.doesNotMatch(hoverTextMotion, /translate3d\(8px,-4px,0\)/);
  assert.doesNotMatch(hoverTextMotion, /Faire bouger le texte au survol/);
  assert.doesNotMatch(builderPage, /data-hover-text-motion="true"/);
  assert.doesNotMatch(builderPage, /Faire bouger le texte au survol/);
  assert.match(builderPage, /data-tab="effects">✨ Effets/);
});

test('pricing card titles animate letter by letter with alternating directions', () => {
  assert.match(paymentPage, /offer-card h2 \.hopclic-letter\{display:inline-block/);
  assert.match(paymentPage, /offer-card h2\{min-height:calc\(1\.25em \+ 18px\);padding:9px 8px/);
  assert.match(paymentPage, /@keyframes hopclic-letter-rise/);
  assert.match(paymentPage, /@keyframes hopclic-letter-fall/);
  assert.match(paymentPage, /hopclic-letters-active \.hopclic-letter\.from-top\{animation-name:hopclic-letter-fall\}/);
  const pricingTitleScript = paymentPage.match(/<script id="hopclic-title-moves-only">([\s\S]*?)<\/script>/)?.[1] || '';
  assert.doesNotMatch(pricingTitleScript, /new IntersectionObserver/);
  assert.match(paymentPage, /Array\.from\(text\)\.map/);
  assert.match(paymentPage, /heading\.setAttribute\('aria-label',text\)/);
  assert.match(paymentPage, /prefers-reduced-motion:reduce/);
  assert.match(paymentPage, /id="hopclic-title-moves-only"/);
  assert.match(paymentPage, /card\.addEventListener\('pointermove'/);
  assert.match(paymentPage, /titleTimer=setTimeout\(\(\)=>card\.classList\.remove\('hopclic-title-press'\),900\)/);
  assert.doesNotMatch(paymentPage, /card\.addEventListener\('pointerdown'/);
  assert.match(paymentPage, /offer-card\.hopclic-title-press h2 \.hopclic-letter\{animation:/);
});

test('pricing cards press toward the pointer with a broad neon glow and replay title letters', () => {
  assert.match(paymentPage, /\.offergrid \.offer-card\{--press-x:0deg;--press-y:0deg/);
  assert.match(paymentPage, /\.offergrid \.offer-card:hover\{transform:perspective\(900px\) translateY\(4px\) rotateX\(var\(--press-x\)\) rotateY\(var\(--press-y\)\)/);
  assert.match(paymentPage, /var\(--glow-x\) var\(--glow-y\) 125px 48px #ffb53670/);
  assert.match(paymentPage, /\.offer-card:is\(:hover,:focus-within\) h2 \.hopclic-letter/);
  assert.match(paymentPage, /hopclic-title-press h2 \.hopclic-letter/);
  assert.match(paymentPage, /event\.clientX-rect\.left/);
  assert.match(paymentPage, /event\.clientY-rect\.top/);
  assert.match(paymentPage, /if\(!card\.classList\.contains\('hopclic-title-press'\)\)\{card\.classList\.add\('hopclic-title-press'\)\}/);
  assert.doesNotMatch(paymentPage, /card\.addEventListener\('pointerdown'/);
  assert.match(paymentPage, /prefers-reduced-motion:reduce[^}]*offer-card/);
});

test('landing cards use stronger pointer tilt and a softer shadow cast right and down', () => {
  assert.match(paymentPage, /id="hopclic-offer-card-directional-hover"/);
  assert.match(paymentPage, /translateY\(6px\) rotateX\(var\(--press-x\)\) rotateY\(var\(--press-y\)\) scale\(\.975\)/);
  assert.match(paymentPage, /16px 22px 54px 4px #ffb52d85,22px 32px 78px 12px #ff8e2870/);
  assert.match(paymentPage, /id="hopclic-step-card-motion"/);
  assert.match(paymentPage, /id="hopclic-step-card-motion-script"/);
  assert.match(paymentPage, /concept-steps article:hover/);
  assert.match(paymentPage, /event\.clientX-rect\.left/);
});

test('the creation details continue inline without a disclosure button', () => {
  assert.match(paymentPage, /<div class="hopclic-more"><div class="hopclic-more-content">/);
  assert.doesNotMatch(paymentPage, /<summary>Découvrez ce que vous allez créer/);
  assert.match(paymentPage, /id="concept"/);
  assert.match(stylesheet, /details\.hopclic-more:not\(\[open\]\)>.hopclic-more-content\{display:none\}/);
});

test('the two offer cards have a very dark visible frame', () => {
  assert.match(paymentPage, /id="hopclic-offer-card-dark-frame"/);
  assert.match(paymentPage, /\.offergrid \.offer-card\{border:2px solid #38251b!important\}/);
  assert.match(paymentPage, /id="hopclic-offer-card-rounded-restore"/);
  assert.match(paymentPage, /\.offergrid \.offer-card\{border-radius:28px!important\}/);
});

test('the main concept button uses a mouse pointer icon instead of an arrow', () => {
  assert.match(paymentPage, /id="hopclic-concept-cursor-icon"/);
  assert.match(paymentPage, /a\.concept-cta::after\{content:''!important/);
  assert.match(paymentPage, /mask:url\("data:image\/svg\+xml/);
  assert.match(paymentPage, /a\.concept-cta:hover::after\{transform:translate\(2px,-2px\)\}/);
});

test('all payment page buttons use the orange sampled from the logo arrow', () => {
  assert.match(paymentPage, /id="hopclic-logo-orange-buttons"/);
  assert.match(paymentPage, /--hopclic-logo-orange:#fe7d01/);
  assert.match(paymentPage, /:is\(a\.button,button\)\{background:var\(--hopclic-logo-orange\)!important/);
  assert.match(paymentPage, /color:var\(--hopclic-logo-brown\)!important/);
  assert.match(paymentPage, /id="hopclic-logo-orange-final-fix"/);
  assert.match(paymentPage, /:is\(a\.button\.primary,button\.primary,\.concept-cta\)\{background:#fe7d01!important/);
  assert.match(paymentPage, /a\.concept-cta::after\{background:#471c0b!important;transform:rotate\(90deg\)!important/);
  assert.match(paymentPage, /a\.concept-cta:active::after\{transform:translateX\(5px\) rotate\(90deg\)!important\}/);
});

test('all HopClic landing buttons share the orange cursor and press interaction', () => {
  assert.match(paymentPage, /id="hopclic-all-page-cursor-buttons"/);
  assert.match(paymentPage, /:is\(a\.button,button\)::after\{content:''!important/);
  assert.match(paymentPage, /:is\(a\.button,button\):active\{transform:translateY\(4px\) scale\(\.98\)!important/);
  assert.match(paymentPage, /<h2>Un site qui donne envie de vous connaître<\/h2>/);
  assert.match(paymentPage, /id="hopclic-buttons-unified-final"/);
  assert.match(paymentPage, /min-height:64px!important;padding:8px 8px 8px 24px!important;border:1px solid #fe7d01!important;border-radius:999px!important/);
  assert.match(paymentPage, /M20 16v14l3\.2-3\.2 2\.6 5\.1/);
  assert.match(paymentPage, /:is\(a\.button,button\):active[^}]*translateY\(5px\) scale\(\.98\)!important/);
  assert.match(paymentPage, /id="hopclic-cursor-visible-motion"/);
  assert.match(paymentPage, /id="hopclic-cursor-right-anchor-fix"/);
  assert.match(paymentPage, /a\.button::before,html body\.hopclic-landing button::before\{content:''!important;position:absolute!important;inset:auto!important;top:50%!important;right:37px!important;left:auto!important/);
  assert.match(paymentPage, /width:12px!important;height:16px!important/);
  assert.match(paymentPage, /:is\(a\.button,button\):active::before\{transform:translate\(9px,-50%\) rotate\(90deg\)!important/);
  assert.match(paymentPage, /id="hopclic-cursor-centered-hover-motion"/);
  assert.match(paymentPage, /right:24px!important;width:16px!important;height:22px!important/);
  assert.match(paymentPage, /right:24px!important;width:16px!important;height:22px!important;transform:translateY\(-50%\) rotate\(90deg\);transition:none!important/);
  assert.match(paymentPage, /a\.button:hover::before,html body\.hopclic-landing button:hover::before\{animation:hopclic-cursor-fly-click \.92s cubic-bezier\(\.2,\.8,\.2,1\) both!important/);
});

test('all landing buttons show a moving mirror shine only while hovered without covering the cursor', () => {
  assert.match(paymentPage, /id="hopclic-button-mirror-hover"/);
  assert.match(paymentPage, /id="hopclic-button-mirror-overlay-script"/);
  assert.match(paymentPage, /button\.prepend\(shine\)/);
  assert.match(paymentPage, /\.hopclic-mirror-shine\{position:absolute!important;inset:0!important;z-index:1!important;display:block!important;overflow:hidden!important;border-radius:inherit!important;pointer-events:none!important\}/);
  assert.match(paymentPage, /\.hopclic-mirror-shine::before\{content:'';position:absolute;top:-55%;bottom:-55%;left:-85%;width:58%;background:linear-gradient\(112deg,transparent 0%,#fff8 31%,#ffffff 50%,#fff9 69%,transparent 100%\)/);
  assert.match(paymentPage, /:is\(a\.button,button\):hover>\.hopclic-mirror-shine::before\{animation:hopclic-button-mirror-sweep 1\.35s cubic-bezier\(\.2,\.7,\.2,1\) infinite\}/);
  assert.match(paymentPage, /prefers-reduced-motion:reduce\)[^{]*\{[^}]*hopclic-mirror-shine::before/);
});

test('landing buttons animate a HopClic-colored pointer arriving and clicking on hover', () => {
  assert.match(paymentPage, /id="hopclic-button-cursor-fly-click"/);
  assert.match(paymentPage, /@keyframes hopclic-cursor-fly-click\{0%\{opacity:0;transform:translate\(30px,-32%\) rotate\(25deg\) scale\(\.72\)\}/);
  assert.match(paymentPage, /background:#ff8a00!important;filter:drop-shadow\(1px 0 #fff7e8\) drop-shadow\(-1px 0 #fff7e8\)/);
  assert.match(paymentPage, /:is\(a\.button,button\):is\(:hover,:focus-visible\)::before\{opacity:1;animation:hopclic-cursor-fly-click/);
  assert.match(paymentPage, /66%\{opacity:1;transform:translate\(8px,-43%\) rotate\(0\) scale\(\.82\)\}/);
  assert.match(paymentPage, /prefers-reduced-motion:reduce\)[^{]*\{[^}]*animation:none!important/);
});

test('landing page pointer and clickable hand use the bright logo orange', () => {
  assert.match(paymentPage, /id="hopclic-brand-arrow-and-hand-cursors"/);
  assert.match(paymentPage, /body\.hopclic-landing\{cursor:url\("data:image\/svg\+xml,[^"]*%23ff8a00[^"]*"\) 4 3,auto!important\}/);
  assert.match(paymentPage, /:is\(a,button,\[role="button"\],summary,label,input\[type="button"\],input\[type="submit"\],input\[type="reset"\]\)\{cursor:url\("data:image\/svg\+xml,[^"]*%23ff8a00[^"]*"\) 10 6,pointer!important\}/);
  assert.match(paymentPage, /\[contenteditable="true"\]\)\{cursor:text!important\}/);
  assert.match(paymentPage, /button:disabled,\[aria-disabled="true"\]\)\{cursor:not-allowed!important\}/);
});

test('the main heading scatters its letters on hover and settles back when the pointer leaves', () => {
  assert.match(paymentPage, /<h1>Un déclic \?<br><span>Envie d’avoir votre propre site \?<\/span><\/h1>/);
  assert.doesNotMatch(paymentPage, /Vos clients veulent voir ce que vous faites/);
  assert.match(paymentPage, /id="hopclic-intro-title-scatter"/);
  assert.match(paymentPage, /hopclic-offer-intro h1\.hopclic-hover-scatter:is\(:hover,:focus-visible\) \.hopclic-scatter-letter\{transform:translate3d\(var\(--scatter-x,0px\),var\(--scatter-y,0px\),0\) rotate\(var\(--scatter-rotate,0deg\)\)/);
  assert.match(paymentPage, /transition:transform \.24s cubic-bezier\(\.2,\.8,\.2,1\)/);
  assert.match(paymentPage, /id="hopclic-intro-title-scatter-script"/);
  assert.match(paymentPage, /influence=Math\.max\(0,1-distance\/145\)/);
  assert.match(paymentPage, /dx\*direction\*24\*influence/);
  assert.match(paymentPage, /letter\.getBoundingClientRect\(\)/);
  assert.match(paymentPage, /heading\.setAttribute\('aria-label',heading\.innerText/);
  assert.match(paymentPage, /prefers-reduced-motion:reduce[^}]*hopclic-scatter-letter/);
});

test('the introductory paragraph has no pointer magnification or hover scaling', () => {
  assert.doesNotMatch(paymentPage, /concept-lead-magnifier|concept-word-magnifier|strength=Math\.max\(0,1-distance\/110\)/);
  assert.doesNotMatch(paymentPage, /\.concept-lead:hover\{[^}]*transform:scale/);
  assert.match(paymentPage, /class="concept-lead">Un beau chantier, une prestation soignée/);
  assert.match(paymentPage, /id="hopclic-concept-lead-scroll-reveal"/);
  assert.match(paymentPage, /id="hopclic-concept-lead-scroll-reveal-style"/);
  assert.match(paymentPage, /lead\.classList\.add\('is-revealed'\)/);
  assert.match(paymentPage, /transition-delay:calc\(var\(--lead-line-index\)\*130ms\)/);
  assert.match(paymentPage, /threshold:\.18/);
});

test('the achievements card has a photo-focus and video-play hover animation', () => {
  assert.match(paymentPage, /class="concept-feature-media"/);
  assert.match(paymentPage, /class="concept-media-icon" aria-hidden="true">📸/);
  assert.match(paymentPage, /id="hopclic-photo-video-card-motion"/);
  assert.match(paymentPage, /concept-feature-media:hover \.concept-media-icon\{animation:hopclic-camera-focus/);
  assert.match(paymentPage, /content:'▶'/);
  assert.match(paymentPage, /@keyframes hopclic-camera-focus/);
  assert.match(paymentPage, /prefers-reduced-motion:reduce[^}]*concept-feature-grid>div/);
});

test('all concept feature cards lift and each non-photo icon animates on hover', () => {
  assert.match(paymentPage, /concept-feature-grid>div:hover\{transform:perspective\(900px\) translateY\(-5px\) rotateX\(var\(--feature-tilt-x,0deg\)\) rotateY\(var\(--feature-tilt-y,0deg\)\);border-color:#fe9a37;box-shadow:0 8px 0 #c65e0030,0 18px 32px #c65e0023,0 0 24px #fe9a3726/);
  assert.match(paymentPage, /id="hopclic-feature-card-tilt-script"/);
  assert.match(paymentPage, /card\.addEventListener\('pointermove'/);
  assert.match(paymentPage, /\(\.5-y\)\*8/);
  assert.match(paymentPage, /\(x-\.5\)\*8/);
  assert.match(paymentPage, /card\.addEventListener\('pointerleave',\(\)=>\{card\.style\.removeProperty\('--feature-tilt-x'\)/);
  assert.match(paymentPage, /class="concept-feature-icon feature-tools-icon" aria-hidden="true">🛠/);
  assert.match(paymentPage, /class="concept-feature-icon feature-pin-icon" aria-hidden="true">📍/);
  assert.match(paymentPage, /class="concept-feature-icon feature-palette-icon" aria-hidden="true">🎨/);
  assert.match(paymentPage, /feature-tools-icon\{animation:hopclic-tools-tap/);
  assert.match(paymentPage, /feature-pin-icon\{animation:hopclic-pin-drop/);
  assert.match(paymentPage, /feature-palette-icon\{animation:hopclic-palette-swish/);
  assert.match(paymentPage, /@keyframes hopclic-tools-tap[\s\S]*?100%\{transform:rotate\(0\) scale\(1\.35\)\}/);
  assert.match(paymentPage, /@keyframes hopclic-camera-focus[\s\S]*?100%\{transform:scale\(1\.08\) rotate\(0\)\}/);
  assert.match(paymentPage, /@keyframes hopclic-pin-drop[\s\S]*?100%\{transform:translateY\(0\) scale\(1\)\}/);
  assert.match(paymentPage, /@keyframes hopclic-palette-swish[\s\S]*?100%\{transform:rotate\(0\) scale\(1\)\}/);
  assert.match(paymentPage, /prefers-reduced-motion:reduce\)[^{]*\{[^}]*concept-feature-grid>div/);
});

test('the identity palette is replaced by the transparent paint artwork on hover', () => {
  assert.match(paymentPage, /class="concept-feature-icon feature-palette-icon" aria-hidden="true">🎨/);
  assert.match(paintSplash, /feature-palette-original[^}]*opacity:0/);
  assert.match(paintSplash, /feature-paint-splash[^}]*animation:hopclic-palette-replace/);
  assert.match(paintSplash, /splash\.src='identity-paint-splash\.png\?v=1'/);
  assert.ok(fs.existsSync(path.join(__dirname, 'identity-paint-splash.png')));
});

test('the identity palette softly transforms into an expanding paint splash on hover', () => {
  assert.match(paintSplash, /feature-palette-original\{[^}]*transition:opacity \.22s ease,transform \.32s/);
  assert.match(paintSplash, /feature-palette-original[^}]*opacity:0;transform:scale\(\.55\)/);
  assert.match(paintSplash, /feature-paint-splash[^}]*animation:hopclic-palette-replace \.42s/);
  assert.match(paintSplash, /@keyframes hopclic-palette-replace[\s\S]*?100%\{opacity:1/);
  assert.match(paintSplash, /splash\.src='identity-paint-splash\.png\?v=1'/);
  assert.match(paintSplash, /object-fit:contain/);
  assert.ok(fs.existsSync(path.join(__dirname, 'identity-paint-splash.png')), 'the transparent splash artwork is included in the site files');
  assert.ok(paymentPage.includes('palette-paint-splash.js?v=7'), 'the payment page should load the updated hover transformation');
});

test('blocks can be stretched vertically in the preview and retain their height', () => {
  assert.match(previewBlockResize, /ensureBlockHeightControls/);
  assert.match(previewBlockResize, /title\.textContent = 'Hauteur du bloc'/);
  assert.match(previewBlockResize, /range\.type = 'range'/);
  assert.match(previewBlockResize, /block\.renderHeight = savedHeight\(range\.value\)/);
  assert.match(previewBlockResize, /reset\.textContent = 'Automatique'/);
  assert.match(previewBlockResize, /renderBeforeBlockHeightControls/);
  assert.match(previewBlockResize, /renderHeight: savedHeight\(savedBlocks\.get\(String\(block\.id\)\)\?\.renderHeight\)/);
  assert.match(previewBlockResize, /section\.style\.minHeight = `\$\{height\}px`/);
  assert.match(previewBlockResize, /getComputedStyle\(section\)\.position === 'static'\) section\.style\.position = 'relative'/);
  assert.match(previewBlockResize, /section\.style\.zIndex = String\(blockSections\.length - sectionIndex \+ 1\)/);
  assert.match(previewBlockResize, /className = 'preview-block-resize'/);
  assert.match(previewBlockResize, /handle\.setPointerCapture\(event\.pointerId\)/);
  assert.match(previewBlockResize, /handle\.textContent = '↕'/);
  assert.match(previewBlockResize, /left:50%;bottom:-14px;transform:translateX\(-50%\)/);
  assert.match(previewBlockResize, /block\.renderHeight = applyHeight\(section\.getBoundingClientRect\(\)\.height \+ 60\)/);
  assert.match(previewBlockResize, /width:28px!important;height:24px!important/);
  assert.match(previewBlockResize, /background:#fff8f1e8!important/);
  assert.match(previewBlockResize, /border:1px solid #94502a80!important/);
  assert.match(previewBlockResize, /event\.key === 'ArrowUp' \|\| event\.key === 'ArrowDown'/);
  assert.match(previewBlockResize, /event\.key === 'Home'/);
  assert.match(previewBlockResize, /className = 'preview-block-move'/);
  assert.match(previewBlockResize, /doc\.body\.dataset\.blockPresentation === 'cards'/);
  assert.match(previewBlockResize, /doc\.elementFromPoint\(event\.clientX, event\.clientY\)/);
  assert.match(previewBlockResize, /state\.blocks\[sourceIndex\], state\.blocks\[targetIndex\]/);
  assert.ok(builderPage.includes('preview-block-resize.js?v=12'), 'the builder should load block height controls and preview resizing');
  assert.match(app, /classList\.contains\('preview-block-resize'\)/, 'preview refreshes should preserve resize handles');
  assert.ok(builderPage.includes('home-preview-centering.js?v=1'), 'the builder should center the homepage hero in the preview');
  assert.ok(builderPage.includes('preview-block-action-controls.js?v=1'), 'the builder should restore block move and hide controls after a preview refresh');
});

test('the compact floating menu is limited to mobile so desktop side navigation stays visible', () => {
  const compactMenu = app.slice(app.indexOf('const pageBeforeVisibleMobileMenu='));
  assert.match(compactMenu, /style\.textContent='@media\(max-width:760px\)\{body>header \.site-menu-toggle\{display:inline-flex!important/);
  assert.match(compactMenu, /body>header \.site-menu\{display:none!important\}body>header\.menu-open \.site-menu\{display:flex!important/);
  assert.ok(builderPage.includes('app.js?v=400'), 'the builder should load the updated menu and preview rules');
});

test('only buttons can move or resize; images keep their original responsive layout', () => {
  assert.match(placementCode, /querySelectorAll\('a\[href\], button, \[role="button"\]'\)\]\s*\.filter\(isResizableButton\)/);
  assert.match(placementCode, /querySelectorAll\('a\[href\], button, \[role="button"\]'\)\]\s*\.filter\(isResizableButton\)/g);
  assert.doesNotMatch(placementCode, /querySelectorAll\('img|imageIndex|!image\s*&&/);
  assert.match(placementCode, /width', `\$\{width\}px`, 'important'\)/);
  assert.match(placementCode, /available \/ scale/);
  assert.match(placementCode, /white-space', 'nowrap'/);
  assert.match(placementCode, /gap', '6px'/);
  assert.match(app, /service-card\.photo-side\{grid-template-columns:minmax\(0,1fr\);gap:12px\}/);
});

test('comparison and request buttons resize as one group inside a project card', () => {
  assert.match(placementGroups, /project-comparison-actions/);
  assert.match(placementGroups, /custom-site-actions/);
  assert.match(beforeAfter, /actions\.className='project-comparison-actions'/);
  assert.match(interactiveProjects, /actions\.append\(button\)/);
  assert.match(interactiveProjects, /target\.querySelector\('\.request-project-style'\)/);
  assert.match(placementCode, /member\.style\.translate = '0px 0px'/);
});

test('linked project photos remain visible to visitors when their point text is still empty', () => {
  assert.match(interactiveProjects, /linkedNotes=\(block\.interactiveNotes\|\|\[\]\)\.filter\(p=>Boolean\(p\.photoId\)\)/);
  assert.match(interactiveProjects, /if\(!linked\.length\)continue/);
  assert.match(interactiveProjects, /if\(points\.length\)addPoints\(card,image,photo,points,caption\.textContent\)/);
});

test('media transitions are managed as pages in site organization', () => {
  assert.match(app, /'promotions','transition','payment'\]\.includes\(b\.type\)/);
  assert.match(scrollMediaTransition, /Choisir une photo/);
  assert.match(scrollMediaTransition, /Choisir une vidéo/);
  assert.match(scrollMediaTransition, /\+ Ajouter une page de transition/);
  assert.match(scrollMediaTransition, /Pages de transition/);
  assert.match(scrollMediaTransition, /Emplacement dans le site/);
  assert.match(scrollMediaTransition, /choice\.hidden = true/);
  assert.match(scrollMediaTransition, /card\.hidden = true/);
  assert.match(scrollMediaTransition, /option\[value="transition"\]/);
  assert.match(scrollMediaTransition, /transitionPhotoId/);
  assert.match(scrollMediaTransition, /transitionVideoId/);
  assert.match(scrollMediaTransition, /cover\.classList\.add\('scroll-transition-neighbor'\)/);
  assert.match(scrollMediaTransition, /La photo reste fixe en fond pendant le défilement/);
  assert.match(scrollMediaTransition, /Supprimer cette page de transition/);
  assert.match(scrollMediaTransition, /event\.stopPropagation\(\);\s*state\.blocks = state\.blocks\.filter\(item => item\.id !== block\.id\)/);
  assert.match(scrollMediaTransition, /block\.visible = active\.checked; disableMotionEffectsForTransitions\(\); refreshEditor\(\)/);
  assert.match(scrollMediaTransition, /state\.blocks\.filter\(block => block\.visible && block\.type === 'transition'\)/);
  assert.match(scrollMediaTransition, /function disableMotionEffectsForTransitions\(\)/);
  assert.match(scrollMediaTransition, /state\.hoverTextMotion = false/);
  assert.match(scrollMediaTransition, /state\.homeLoadingAnimation = 'none'/);
  assert.match(scrollMediaTransition, /state\.siteMenuPresentation = 'static'/);
  assert.match(scrollMediaTransition, /block\.titleAnimation = 'none'/);
  assert.match(scrollMediaTransition, /block\.photoAnimation = 'none'/);
  assert.match(scrollMediaTransition, /disableMotionEffectsForTransitions\(\);\s*refreshEditor\(\)/);
  assert.match(scrollMediaTransition, /\.scroll-transition-fixed-photo\{background-position:center;background-size:cover;background-repeat:no-repeat;background-attachment:fixed;transform:none!important;animation:none!important;transition:none!important;filter:none!important\}/);
  assert.match(scrollMediaTransition, /body>section\.scroll-media-transition\{position:relative;left:50%;isolation:isolate;box-sizing:border-box;width:100vw!important;max-width:none!important;height:100vh/);
  assert.match(scrollMediaTransition, /\.scroll-transition-stage\{position:relative;box-sizing:border-box;width:100%;height:100vh/);
  assert.match(scrollMediaTransition, /body>section:not\(\.business-card\)\.scroll-transition-cover\{position:relative!important;left:50%!important;width:100vw!important;max-width:none!important;z-index:3!important;margin-left:-50vw!important;margin-right:0!important;margin-top:-40vh!important/);
  assert.match(scrollMediaTransition, /body>section:not\(\.business-card\)\.scroll-transition-before\{position:relative!important;z-index:3!important;margin-bottom:-12vh!important/);
  assert.match(scrollMediaTransition, /body>section\.scroll-media-transition,body>section\.scroll-media-transition \*,body>section\.scroll-transition-neighbor,body>section\.scroll-transition-neighbor \*\{animation:none!important;animation-timeline:auto!important;transition:none!important;transform:none!important/);
  assert.match(scrollMediaTransition, /\.scroll-transition-media,\.scroll-transition-placeholder\{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border:0;z-index:0;transform:none!important;animation:none!important;animation-timeline:auto!important;transition:none!important;filter:none!important\}/);
  assert.match(scrollMediaTransition, /body>section\.scroll-media-transition,body>section\.scroll-media-transition \*,body>section\.scroll-transition-neighbor,body>section\.scroll-transition-neighbor \*\{animation:none!important;animation-timeline:auto!important;transition:none!important;transform:none!important;filter:none!important;scroll-behavior:auto!important\}/);
  assert.match(scrollMediaTransition, /doc\.documentElement\.dataset\.scrollMediaTransitions = 'true'/);
  assert.match(scrollMediaTransition, /html\[data-scroll-media-transitions="true"\] body>section:not\(\.scroll-media-transition\),html\[data-scroll-media-transitions="true"\] body>section:not\(\.scroll-media-transition\) \*\{animation:none!important;animation-timeline:auto!important;transition:none!important;transform:none!important;filter:none!important\}/);
  assert.match(scrollMediaTransition, /html\[data-scroll-media-transitions="true"\],html\[data-scroll-media-transitions="true"\] body\{scroll-behavior:auto!important\}/);
  assert.match(scrollMediaTransition, /\.scroll-transition-copy\{position:absolute;z-index:2;/);
  assert.doesNotMatch(scrollMediaTransition, /LA SUITE/);
  assert.match(scrollMediaTransition, /\.scroll-transition-copy\{position:absolute;z-index:2;top:0;right:0;bottom:0;left:0;box-sizing:border-box;width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center/);
  assert.match(scrollMediaTransition, /body\[data-block-presentation="left-rail"\]>section\.scroll-media-transition,body\[data-block-presentation="right-rail"\]>section\.scroll-media-transition,body\[data-block-presentation="left-rail"\]>section\.scroll-transition-neighbor,body\[data-block-presentation="right-rail"\]>section\.scroll-transition-neighbor\{grid-column:1\/-1!important\}/);
  assert.match(scrollMediaTransition, /\.scroll-transition-copy\{position:absolute;z-index:2;top:0;right:0;bottom:0;left:0;box-sizing:border-box;width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center/);
  assert.match(scrollMediaTransition, /\.scroll-transition-copy h2\{justify-self:center;width:100%;font:italic 700 clamp\(44px,7\.2vw,96px\)\/1\.02 "\$\{state\.font\}",serif;letter-spacing:-\.045em;max-width:1200px;margin:0 auto;color:white;text-align:center!important/);
  assert.match(scrollMediaTransition, /font:italic 700 clamp\(44px,7\.2vw,96px\)\/1\.02 "\$\{state\.font\}",serif/);
  assert.match(app, /const sameBlocks=JSON\.stringify\(currentSections\.map\(section=>section\.id\)\)/);
  assert.match(siteOrganization, /body>section:not\(\.business-card\):not\(\.scroll-media-transition\)/);
  assert.match(scrollMediaTransition, /scroll-transition-before\{margin-bottom:-12vh!important\}/);
  assert.match(scrollMediaTransition, /scroll-transition-cover\{margin-top:-36vh!important/);
  assert.ok(builderPage.includes('scroll-media-transition.js?v=24'), 'the builder should load the updated media transition controls');
  assert.doesNotMatch(builderPage, /image-reveal\.js/, 'the old image-only reveal control should be removed');
});

test('special effects keep chapter controls and remove the text hover effect', () => {
  assert.doesNotMatch(builderPage, /Faire bouger le texte au survol/);
  assert.doesNotMatch(hoverTextMotion, /Faire bouger le texte au survol/);
  assert.match(scrollMediaTransition, /title: 'Un nouveau chapitre'/);
  assert.match(scrollMediaTransition, /editor\.querySelector\('\.design-special-effects'\)/);
  assert.match(scrollMediaTransition, /tab !== 'effects'/);
  assert.match(scrollMediaTransition, /lastElementChild !== group\) editor\.append\(group\)/);
  assert.match(scrollMediaTransition, /renderTransitionOrganization\(group\)/);
  assert.match(stylesheet, /#editor>\.design-special-effects\[open\]>summary::before/);
});

test('full-width setting expands both the published page and builder preview', () => {
  assert.match(siteWidthScript, /classList\.toggle\('site-full-width',state\.siteWidth==='full'\)/);
  assert.match(siteWidthScript, /html\{width:100%!important;max-width:none!important\}body\{width:100%!important;max-width:none!important;margin:0!important/);
  assert.match(stylesheet, /\.browser\.site-full-width\{max-width:none!important;width:100%\}/);
  assert.match(stylesheet, /\.browser\.site-full-width\.mobile\{max-width:390px!important;width:100%\}/);
  assert.match(siteOrganization, /state\.siteWidth === 'full' \? 'full' : state\.organizationWidth/);
  assert.match(siteOrganization, /state\.siteWidth==='full'/);
});

test('interactive photo markers use the requested glass button style', () => {
  assert.match(interactiveProjects, /\.interactive-photo-point\{[^}]*border-radius:12px/);
  assert.match(interactiveProjects, /\.interactive-photo-point\{[^}]*backdrop-filter:blur\(9px\)/);
  assert.match(interactiveProjects, /\.interactive-photo-point\{[^}]*inset 0 1px 2px rgba\(255,255,255/);
  assert.match(interactiveProjects, /button\.textContent='\+'/);
  assert.match(interactiveProjects, /interactive-point-editable/);
  assert.match(interactiveProjects, /parent\.postMessage\(\{type:'interactive-point-position'/);
  assert.match(interactiveProjects, /type!=='interactive-point-position'/);
  assert.match(interactiveProjects, /point\.x=Math\.max\(3,Math\.min\(97,Number\(event\.data\.x\)\|\|50\)\)/);
});

test('existing checkout pages remain editable and hand off to a secure payment provider', () => {
  assert.doesNotMatch(builderPage, /video-chapters\.js/);
  assert.match(app, /'transition','payment'\]\.includes\(b\.type\)/);
  assert.match(app, /v\.blocks=v\.blocks\.filter\(\(block,index,blocks\)=>block\.type!=='payment'\|\|blocks\.findIndex\(candidate=>candidate\.type==='payment'\)===index\)/);
  assert.match(app, /paymentUrl:typeof b\.paymentUrl==='string'/);
  assert.match(app, /paymentCurrency:\['EUR','USD','GBP'\]/);
  assert.match(builderPage, /payment-page-block\.js\?v=4/);
  assert.doesNotMatch(paymentPageBlock, /Ajouter une page de paiement/);
  assert.match(paymentPageBlock, /Continuer avec Google/);
  assert.match(paymentPageBlock, /Continuer avec Apple/);
  assert.match(paymentPageBlock, /Continuer avec Facebook/);
  assert.match(paymentPageBlock, /Continuer avec un e-mail/);
  assert.match(paymentPageBlock, /doivent être activées par un service d’identification/);
  assert.match(paymentPageBlock, /Lien de paiement de secours/);
  assert.match(paymentPageBlock, /section\.hidden = true/);
  assert.match(paymentPageBlock, /blocks\.slice\(1\)[\s\S]*?remove\(\)/);
  assert.match(paymentPageBlock, /data-shop-payment/);
  assert.match(promotions, /Voir le paiement/);
  assert.match(promotions, /data-shop-payment data-product-name/);
  assert.match(paymentPageBlock, /Résumé de commande/);
  assert.match(paymentPageBlock, /target="_blank" rel="noopener noreferrer"/);
  assert.match(paymentPageBlock, /Le règlement est traité par votre prestataire sécurisé/);
  assert.doesNotMatch(paymentPageBlock, /checkout-signin|Déjà inscrit|Se connecter<\/button>/);
  assert.doesNotMatch(paymentPageBlock, /option\.value = 'payment'/, 'checkout creation appears as one dedicated action');
  assert.match(paymentPageReferenceLayout, /checkout-optin,\.checkout-optout/);
  assert.doesNotMatch(paymentPageReferenceLayout, /Recevoir des conseils et des inspirations|Vous pourrez vous désinscrire/);
  assert.match(paymentPageReferenceLayout, /checkout-policy/);
  assert.match(paymentPageReferenceLayout, /Créer le compte et continuer/);
  assert.match(paymentPageReferenceLayout, /checkout-footer/);
  assert.match(paymentPageReferenceLayout, /\.checkout-auth-options \.checkout-auth-button\{box-sizing:border-box!important/);
  assert.match(siteButtonsModern, /button:not\(\.checkout-auth-button\)/);
  assert.match(placementCode, /!target\.matches\('\.checkout-auth-button,\.interactive-photo-point,\.preview-block-resize,\.preview-block-move'\)/);
  assert.match(placementCode, /target\.closest\('\.checkout-auth-options'\)[\s\S]*?buttonIndex\+\+;/);
  assert.ok(builderPage.includes('payment-page-reference-layout.js?v=3'));
  assert.ok(builderPage.includes('payment-page-block.js?v=4'));
});
