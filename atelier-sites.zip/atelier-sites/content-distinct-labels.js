const renderBeforeDistinctLabels=render;
render=function(){
 renderBeforeDistinctLabels();if(tab!=='blocks')return;
 const galleries=state.blocks.filter(block=>block.type==='gallery');if(galleries.length<2)return;
 galleries.forEach((block,index)=>{
  const button=[...document.querySelectorAll('#editor .content-choice')].find(button=>button.dataset.id===block.id);if(!button)return;
  const label=(block.menuLabel||contentNames.gallery)+' '+(index+1);
  const title=button.querySelector('strong');if(title)title.textContent=label;else button.textContent=label;
  button.title=label+' — '+block.title;
 });
};
render();
