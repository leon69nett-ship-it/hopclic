const homeTitleAnimationOptions = [
  ['none', 'Aucune'],
  ['fade', 'Fondu doux'],
  ['rise', 'Montée légère'],
  ['zoom', 'Zoom discret'],
  ['wipe', 'Balayage cinématique'],
  ['stagger', 'Apparition ligne par ligne'],
  ['kinetic', 'Kinetic · mots en mouvement'],
  ['shine', 'Reflet doré']
];
const homePhotoAnimationOptions = [
  ['none', 'Aucune'],
  ['cinema', 'Entrée cinématique'],
  ['zoom', 'Zoom vivant'],
  ['float', 'Flottement doux'],
  ['depth', 'Mouvement 3D léger']
];
const validateBeforeCompanyNameAnimation = validate;
validate = function (saved) {
  const result = validateBeforeCompanyNameAnimation(saved);
  result.companyNameAnimation = 'none';
  return result;
};
state.companyNameAnimation = 'none';

const renderBeforeHomeTitleAnimation = render;
render = function () {
  renderBeforeHomeTitleAnimation();
  if (tab !== 'effects') return;
  const block = state.blocks.find(item => item.type === 'intro');
  const editor = document.querySelector('#editor');
  if (!editor) return;
  let effectsGroup = editor.querySelector('.design-special-effects');
  if (!effectsGroup) {
    effectsGroup = document.createElement('details');
    effectsGroup.className = 'design-special-effects';
    effectsGroup.open = true;
    const summary = document.createElement('summary');
    summary.textContent = 'Effets spéciaux';
    effectsGroup.append(summary);
    editor.append(effectsGroup);
  }
  if (effectsGroup.querySelector('.home-title-animation-settings')) return;

  const settings = document.createElement('section');
  settings.className = 'home-title-animation-settings';
  const heading = document.createElement('h3');
  heading.textContent = 'Animations de la page d’accueil';
  settings.append(heading);
  if (!block) {
    const hint = document.createElement('p');
    hint.className = 'hint';
    hint.textContent = 'Ajoutez une rubrique d’accueil pour régler son titre et sa photo.';
    settings.append(hint);
    effectsGroup.append(settings);
    return;
  }

  const label = document.createElement('label');
  label.className = 'home-title-animation-control';
  label.textContent = 'Animation du titre d’accueil';
  const select = document.createElement('select');
  select.setAttribute('aria-label', 'Animation du titre d’accueil');
  for (const [value, caption] of homeTitleAnimationOptions) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = caption;
    select.append(option);
  }
  select.value = block.titleAnimation || 'none';
  select.onchange = () => {
    block.titleAnimation = select.value;
    update();
  };
  label.append(select);
  const hint = document.createElement('p');
  hint.className = 'hint';
  hint.textContent = 'Choisissez une animation d’entrée pour donner du style à votre titre.';
  const photoLabel = document.createElement('label');
  photoLabel.className = 'home-photo-animation-control';
  photoLabel.textContent = 'Animation de la photo d’accueil';
  const photoSelect = document.createElement('select');
  photoSelect.setAttribute('aria-label', 'Animation de la photo d’accueil');
  for (const [value, caption] of homePhotoAnimationOptions) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = caption;
    photoSelect.append(option);
  }
  photoSelect.value = block.photoAnimation || 'none';
  photoSelect.onchange = () => {
    block.photoAnimation = photoSelect.value;
    update();
  };
  photoLabel.append(photoSelect);
  const photoHint = document.createElement('p');
  photoHint.className = 'hint';
  photoHint.textContent = 'Anime la photo principale sans la remplacer ni la recadrer.';
  settings.append(label, hint, photoLabel, photoHint);
  effectsGroup.append(settings);
};

const pageBeforeHomeTitleAnimation = page;
page = function () {
  const doc = parseRenderedPage(pageBeforeHomeTitleAnimation());
  const companyName = doc.querySelector('body>header strong');
  if (companyName && state.companyNameAnimation === 'ground') {
    const label = companyName.textContent.trim();
    companyName.classList.add('company-name-ground');
    companyName.setAttribute('aria-label', label);
    const centerIndex = (label.length - 1) / 2;
    companyName.replaceChildren(...[...label].map((character, index) => {
      if (/\s/.test(character)) return doc.createTextNode(character);
      const letter = doc.createElement('span');
      letter.className = 'company-name-ground-letter';
      letter.setAttribute('aria-hidden', 'true');
      const side = index % 2 === 0 ? -1 : 1;
      const distanceFromCenter = Math.abs(index - centerIndex);
      letter.style.setProperty('--name-start-x', `${side * (0.8 + Math.min(distanceFromCenter * 0.09, 0.6))}em`);
      letter.style.setProperty('--name-start-y', `${(index % 3 - 1) * (0.55 + Math.min(distanceFromCenter * 0.08, 0.45))}em`);
      letter.style.setProperty('--name-start-rotate', `${side * (24 + (index % 3) * 13)}deg`);
      letter.style.setProperty('--name-start-yaw', `${-side * (38 + (index % 2) * 18)}deg`);
      letter.style.animationDelay = Math.min(distanceFromCenter * 85, 850) + 'ms';
      letter.textContent = character;
      return letter;
    }));
  }
  const block = state.blocks.find(item => item.type === 'intro' && item.visible !== false);
  const title = doc.querySelector('.hero h1');
  const titleEffect = block?.titleAnimation || 'none';
  const photoEffect = block?.photoAnimation || 'none';
  if ((!title || titleEffect === 'none') && photoEffect === 'none' && (!companyName || state.companyNameAnimation !== 'ground')) return serializeRenderedPage(doc);

  if (title && titleEffect !== 'none') title.classList.add('home-title-motion', 'home-title-motion-' + titleEffect);
  if (title && (titleEffect === 'stagger' || titleEffect === 'kinetic')) {
    const lines = [];
    let line = doc.createElement('span');
    line.className = titleEffect === 'stagger' ? 'home-title-motion-line' : 'home-title-kinetic-line';
    let wordIndex = 0;
    for (const node of [...title.childNodes]) {
      if (node.nodeName === 'BR') {
        lines.push(line);
        line = doc.createElement('span');
        line.className = titleEffect === 'stagger' ? 'home-title-motion-line' : 'home-title-kinetic-line';
      } else {
        const tokens = node.textContent.match(/\s+|[^\s]+/g) || [];
        for (const token of tokens) {
          if (titleEffect === 'stagger' || /^\s+$/.test(token)) {
            line.append(doc.createTextNode(token));
          } else {
            const mask = doc.createElement('span');
            mask.className = 'home-title-kinetic-mask';
            const word = doc.createElement('span');
            word.className = 'home-title-kinetic-word';
            word.textContent = token;
            word.style.animationDelay = Math.min(wordIndex * 65, 780) + 'ms';
            mask.append(word);
            line.append(mask);
            wordIndex++;
          }
        }
      }
    }
    lines.push(line);
    title.replaceChildren(...lines);
    if (titleEffect === 'kinetic') title.setAttribute('aria-label', title.textContent.replace(/\s+/g, ' ').trim());
  }
  const heroPhoto = doc.querySelector('.hero .premium-hero-visual img, .hero .habitat-hero-photo');
  if (heroPhoto && photoEffect !== 'none') heroPhoto.classList.add('home-photo-motion', 'home-photo-motion-' + photoEffect);
  const style = doc.createElement('style');
  style.textContent = `
    @keyframes companyNameAssemble3D { 0% { opacity: 0; transform: perspective(700px) translate3d(var(--name-start-x),var(--name-start-y),1em) rotateX(-52deg) rotateY(var(--name-start-yaw)) rotateZ(var(--name-start-rotate)) scale(.72); filter: blur(3px) brightness(.72); text-shadow: none; } 48% { opacity: 1; transform: perspective(700px) translate3d(0,-.08em,.16em) rotateX(10deg) rotateY(-8deg) rotateZ(2deg) scale(1.12); filter: blur(0) brightness(1.08) drop-shadow(-.3em .52em .08em #24170f99); text-shadow: 1px 1px 0 #8f6d57, 3px 3px 0 #745944, 5px 5px 0 #5c4537, 7px 7px 0 #45342b; } 68% { opacity: 1; transform: perspective(700px) translate3d(0,.035em,-.04em) rotateX(-4deg) rotateY(3deg) rotateZ(-.7deg) scale(.96); filter: drop-shadow(-.42em .82em .12em #24170f99); text-shadow: 1px 1px 0 #8f6d57, 3px 3px 0 #745944, 5px 5px 0 #5c4537, 7px 7px 0 #45342b; } 84% { opacity: 1; transform: perspective(700px) translate3d(0,-.025em,.03em) rotateX(2deg) rotateY(-1deg) rotateZ(.25deg) scale(1.025); filter: drop-shadow(-.38em .74em .12em #24170f99); } 100% { opacity: 1; transform: perspective(700px) translate3d(0,0,0) rotateX(0) rotateY(0) rotateZ(0) scale(1); filter: drop-shadow(-.34em .72em .13em #24170f99); text-shadow: 1px 1px 0 #8f6d57, 3px 3px 0 #745944, 5px 5px 0 #5c4537, 7px 7px 0 #45342b; } }
    @keyframes companyNameGroundLine { 0% { transform: perspective(120px) rotateX(68deg) scaleX(.12) translateY(-.25em); opacity: 0; filter: blur(5px); } 48% { transform: perspective(120px) rotateX(68deg) scaleX(1.05) translateY(.05em); opacity: .6; filter: blur(1px); } 100% { transform: perspective(120px) rotateX(68deg) scaleX(1.2) translateY(.14em); opacity: .34; filter: blur(4px); } }
    .company-name-ground { display: inline-block; position: relative; perspective: 700px; transform-style: preserve-3d; font-family: 'Arial Black', Arial, sans-serif !important; font-weight: 900 !important; letter-spacing: -.04em; }
    .company-name-ground::after { content: ''; position: absolute; z-index: -1; left: -.08em; right: -.08em; bottom: -.32em; height: .44em; transform-origin: center center; background: radial-gradient(ellipse, #24170f55 0%, #24170f2b 42%, transparent 74%); animation: companyNameGroundLine 2100ms ease-out both; }
    .company-name-ground-letter { display: inline-block; transform-origin: 50% 55%; animation: companyNameAssemble3D 2100ms cubic-bezier(.18,.74,.2,1) both; }
    @keyframes homeTitleFade { from { opacity: 0; filter: blur(5px); } to { opacity: 1; filter: blur(0); } }
    @keyframes homeTitleRise { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes homeTitleZoom { from { opacity: 0; filter: blur(7px); transform: scale(.93); } to { opacity: 1; filter: blur(0); transform: scale(1); } }
    @keyframes homeTitleWipe { from { clip-path: inset(0 100% 0 0); } to { clip-path: inset(0 0 0 0); } }
    @keyframes homeTitleShine { 0% { background-position: 140% 0; } 100% { background-position: -40% 0; } }
    @keyframes homeTitleKinetic { 0% { opacity: 0; filter: blur(5px); transform: translateY(115%) rotateX(-70deg); } 100% { opacity: 1; filter: blur(0); transform: translateY(0) rotateX(0); } }
    @keyframes homePhotoCinema { from { opacity: 0; transform: translateX(34px) scale(.96); filter: blur(5px); } to { opacity: 1; transform: translateX(0) scale(1); filter: blur(0); } }
    @keyframes homePhotoZoom { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.055); } }
    @keyframes homePhotoFloat { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-9px); } }
    @keyframes homePhotoDepth { 0%, 100% { transform: perspective(900px) rotateY(0) scale(1); } 50% { transform: perspective(900px) rotateY(-4deg) scale(1.025); } }
    .home-title-motion { animation-duration: 850ms; animation-delay: 80ms; animation-fill-mode: both; animation-timing-function: cubic-bezier(.2,.75,.25,1); }
    .home-title-motion-fade { animation-name: homeTitleFade; }
    .home-title-motion-rise { animation-name: homeTitleRise; }
    .home-title-motion-zoom { animation-name: homeTitleZoom; transform-origin: left center; }
    .home-title-motion-wipe { animation-name: homeTitleWipe; }
    .home-title-motion-stagger { opacity: 1; }
    .home-title-motion-line { display: block; opacity: 0; animation: homeTitleRise 700ms cubic-bezier(.2,.75,.25,1) both; }
    .home-title-motion-line:nth-child(2) { animation-delay: 180ms; }
    .home-title-motion-line:nth-child(3) { animation-delay: 320ms; }
    .home-title-kinetic-line { display: block; perspective: 700px; }
    .home-title-kinetic-mask { display: inline-block; overflow: hidden; vertical-align: bottom; padding-block: .08em; margin-block: -.08em; }
    .home-title-kinetic-word { display: inline-block; opacity: 0; animation: homeTitleKinetic 780ms cubic-bezier(.2,.8,.2,1) both; }
    .home-title-motion-shine { color: var(--c-text, #493022); background: linear-gradient(105deg, var(--c-text, #493022) 0%, var(--c-text, #493022) 39%, #f4bd54 47%, #fff0c6 50%, #d88737 53%, var(--c-text, #493022) 61%, var(--c-text, #493022) 100%); background-size: 240% 100%; background-position: 140% 0; background-clip: text; -webkit-background-clip: text; -webkit-text-fill-color: transparent; animation-name: homeTitleShine; animation-duration: 1300ms; }
    .home-photo-motion { will-change: transform, opacity; }
    .home-photo-motion-cinema { animation: homePhotoCinema 950ms cubic-bezier(.2,.8,.2,1) both; }
    .home-photo-motion-zoom { animation: homePhotoZoom 8s ease-in-out infinite; transform-origin: center; }
    .home-photo-motion-float { animation: homePhotoFloat 5s ease-in-out infinite; }
    .home-photo-motion-depth { animation: homePhotoDepth 6s ease-in-out infinite; transform-origin: center; }
    @media (prefers-reduced-motion: reduce) { .home-title-motion { animation: none !important; } }
    @media (prefers-reduced-motion: reduce) { .home-title-motion-line { opacity: 1 !important; animation: none !important; } }
    @media (prefers-reduced-motion: reduce) { .home-title-kinetic-word { opacity: 1 !important; animation: none !important; } }
    @media (prefers-reduced-motion: reduce) { .home-photo-motion { animation: none !important; will-change: auto !important; } }
    @media (prefers-reduced-motion: reduce) { .company-name-ground::after,.company-name-ground-letter { animation: none !important; opacity: 1 !important; transform: none !important; filter: drop-shadow(-.34em .78em .12em #24170f88) !important; clip-path: none !important; text-shadow: 1px 1px 0 #786556, 2px 2px 0 #605248, 3px 3px 0 #483d34 !important; } }
    .company-name-ground.company-name-animation-preview .company-name-ground-letter { animation: companyNameAssemble3D 2100ms cubic-bezier(.18,.74,.2,1) both !important; }
    .company-name-ground.company-name-animation-preview::after { animation: companyNameGroundLine 2100ms ease-out both !important; }
  `;
  doc.head.append(style);
  return serializeRenderedPage(doc);
};

render();
update();
