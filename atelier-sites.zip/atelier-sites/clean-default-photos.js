async function cleanDefaultPhotos(){
  if(!CLIENT||localStorage.getItem(KEY+'-clean-photos-v1'))return;
  await window.photoLibraryReady;
  const photos=structuredClone(state.photoLibrary||[]);
  const key=KEY+'-removed-default-photos';
  if(photos.length)await libraryStore(key,photos);
  state.photoLibrary=[];
  librarySelection=null;
  // Remove image selections too, so a saved gallery cannot revive demonstration media.
  for(const block of state.blocks){
    block.photos=[];block.galleryPhotoIds=[];
    block.servicePhotos=[];block.detailsPhotos=[];
    for(const product of block.products||[])product.photo='';
  }
  await libraryStore(KEY,[]);
  localStorage.setItem(KEY+'-clean-photos-v1','1');
  render();update();
}
cleanDefaultPhotos().catch(()=>{$('#status').textContent='Nettoyage des photos impossible. Réessayez après rechargement.'});
const restoreDefaultPhotos=document.createElement('button');
restoreDefaultPhotos.type='button';restoreDefaultPhotos.textContent='Récupérer les anciennes photos';
restoreDefaultPhotos.onclick=async()=>{const photos=await libraryStore(KEY+'-removed-default-photos');if(!photos?.length){$('#status').textContent='Aucune ancienne photo archivée.';return;}state.photoLibrary=normalisePhotoLibrary(photos);render();update();$('#status').textContent='Anciennes photos récupérées dans la bibliothèque.'};
document.querySelector('aside .tools').append(restoreDefaultPhotos);
