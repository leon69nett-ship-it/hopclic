function focusGalleryPhotoChoice(block){
  selectEditorBlock(block.id);render();syncContentMenu();
  const panel=[...document.querySelectorAll('#editor .block')].find(card=>card.dataset.blockId===block.id);
  const button=panel?.querySelector('.gallery-library-picker label button');
  if(button){button.scrollIntoView({behavior:'instant',block:'center'});button.focus({preventScroll:true});button.click();}
}
function bindGalleryPhotoShortcut(){
  const doc=previewFrame.contentDocument;if(!doc||doc.galleryPhotoShortcutBound)return;
  doc.galleryPhotoShortcutBound=true;
  doc.addEventListener('click',event=>{
    const target=event.target.closest('.gallery-window .placeholder,.slideshow-empty');
    if(!target)return;
    const section=target.closest('[data-editor-block]');
    const block=state.blocks.find(item=>item.id===section?.dataset.editorBlock);
    if(!block||block.type!=='gallery')return;
    event.preventDefault();event.stopImmediatePropagation();focusGalleryPhotoChoice(block);
  },true);
}
previewFrame.addEventListener('load',bindGalleryPhotoShortcut);bindGalleryPhotoShortcut();
document.querySelector('#editor').addEventListener('click',event=>{
  const note=event.target.closest('.gallery-library-note');if(!note)return;
  const panel=note.closest('.block');const block=state.blocks.find(item=>item.id===panel?.dataset.blockId);
  if(block){event.preventDefault();event.stopImmediatePropagation();focusGalleryPhotoChoice(block);}
},true);
