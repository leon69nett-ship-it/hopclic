@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js est introuvable. Lancez ce fichier sur le meme ordinateur que HopClic.
  pause
  exit /b 1
)
node install-novice.cjs
echo.
pause
