const bindBeforePartnerRemove=bindPreviewCardMenus;
bindPreviewCardMenus=function(){
 bindBeforePartnerRemove();
 const doc=previewFrame.contentDocument;if(!doc?.body)return;
 for(const section of doc.querySelectorAll('.partners-section[data-editor-block]')){
  const block=state.blocks.find(item=>item.id===section.dataset.editorBlock);if(!block)continue;
  if(!section.querySelector('.partner-add')){const add=doc.createElement('button');add.type='button';add.className='partner-add';add.textContent='+ Ajouter un partenaire';add.style.cssText='display:block;margin:16px 0';add.disabled=(block.partners||[]).length>=40;section.append(add)}
  [...section.querySelectorAll('.grid > article')].forEach((card,index)=>{
   if(card.querySelector('.partner-remove'))return;
   const button=doc.createElement('button');button.type='button';button.className='partner-remove';button.textContent='× Supprimer';
   button.setAttribute('aria-label','Supprimer '+(block.partners[index]?.name||'ce partenaire'));
   button.style.cssText='padding:6px 10px;font-size:11px;margin-bottom:12px;display:block;margin-left:auto';
   card.prepend(button);
  });
 }
 if(!doc.partnerRemoveBound){doc.partnerRemoveBound=true;doc.addEventListener('click',event=>{
  const button=event.target.closest('.partner-remove,.partner-add');if(!button)return;
  event.preventDefault();event.stopImmediatePropagation();
  const section=button.closest('[data-editor-block]'),block=state.blocks.find(item=>item.id===section.dataset.editorBlock);
  if(button.classList.contains('partner-add')){if(!block||(block.partners||[]).length>=40)return;block.partners??=[];block.partners.push({name:'',kind:'Partenaire',logo:'',url:''});update();render();selectEditorBlock(block.id,true);const editorCard=[...document.querySelectorAll('#editor .block')].find(card=>card.dataset.blockId===block.id);const fields=editorCard?.querySelectorAll('.library-details');const last=fields?.[fields.length-1];last?.scrollIntoView({behavior:'smooth',block:'center'});last?.querySelector('input')?.focus({preventScroll:true});return}
  const index=[...section.querySelectorAll('.grid > article')].indexOf(button.closest('article'));
  if(block&&index>=0){block.partners.splice(index,1);update();render()}
 },true)}
};
bindPreviewCardMenus();
