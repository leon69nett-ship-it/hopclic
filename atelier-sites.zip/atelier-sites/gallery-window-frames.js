const galleryBeforeWindowFrames=galleryPresentationMarkup;
galleryPresentationMarkup=function(block){
  const html=galleryBeforeWindowFrames(block);if(block.galleryMode==='slideshow')return html;
  const doc=new DOMParser().parseFromString(html,'text/html'),section=doc.querySelector('.realisations-section'),grid=section?.querySelector('.presentation-gallery');if(!grid)return html;
  const count=Math.max(1,Math.min(3,Number(block.galleryWindows)||3));
  grid.style.gridTemplateColumns='repeat('+count+',minmax(0,1fr))';
  while(grid.children.length<count){const card=doc.createElement('article');card.className='gallery-window';grid.append(card)}
  while(grid.children.length>count)grid.lastElementChild.remove();
  [...grid.children].forEach((card,index)=>{
    card.style.cssText+=';border:1px solid '+state.borderColor+';border-radius:10px;padding:16px;min-height:180px;box-sizing:border-box';
    const empty=!card.querySelector('img,video,iframe,.service-card-video-thumb');
    if(empty){card.replaceChildren();const label=doc.createElement('p');label.textContent='Fenêtre '+(index+1);label.style.cssText='margin:0 0 22px;font-size:12px;opacity:.65';const actions=doc.createElement('div');actions.className='gallery-window-add';actions.dataset.windowIndex=index;actions.style.cssText='display:flex;gap:12px;justify-content:center;flex-wrap:wrap';for(const [kind,text]of [['photo','📷 Photo'],['video','🎬 Vidéo']]){const button=doc.createElement('button');button.type='button';button.dataset.mediaKind=kind;button.textContent=text;button.style.cssText='background:transparent;color:inherit;border:1px dashed currentColor;border-radius:8px;padding:12px';actions.append(button)}card.append(label,actions)}
  });return section.outerHTML;
};
function bindWindowFrameActions(){
  const doc=previewFrame.contentDocument;if(!doc||doc.windowFrameActionsBound)return;doc.windowFrameActionsBound=true;
  doc.addEventListener('click',event=>{
    const button=event.target.closest('.gallery-window-add button');if(!button)return;
    const section=button.closest('[data-editor-block]'),block=state.blocks.find(item=>item.id===section?.dataset.editorBlock);if(!block)return;
    event.preventDefault();event.stopImmediatePropagation();
    selectEditorBlock(block.id);
    if(button.dataset.mediaKind==='photo')openUnifiedPhotoPicker([],false,ids=>{if(!ids.length)return;block.galleryPhotoIds=galleryLibraryPhotos(block).map(photo=>photo.id);if(!block.galleryPhotoIds.includes(ids[0]))block.galleryPhotoIds.push(ids[0]);update();render()});
    else openUnifiedVideoPicker([],false,ids=>{if(!ids.length)return;block.galleryVideos??=[];if(!block.galleryVideos.some(video=>video.libraryId===ids[0]))block.galleryVideos.push({libraryId:ids[0]});update();render()});
  },true);
}
previewFrame.addEventListener('load',bindWindowFrameActions);bindWindowFrameActions();update();
