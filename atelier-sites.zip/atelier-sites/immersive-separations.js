const immersiveSeparations=[['stack','Blocs empilés'],['opening','Ouverture centrale'],['depth','Passage en profondeur']];
const renderBeforeImmersiveSeparations=render;
render=function(){renderBeforeImmersiveSeparations();if(tab!=='design')return;const select=document.querySelector('[aria-label="Découpe des séparations"]');if(!select)return;for(const [id,title]of immersiveSeparations){const option=document.createElement('option');option.value=id;option.textContent=title;select.append(option)}select.value=state.blockSeparator||'none'};
const pageBeforeImmersiveSeparations=page;
page=function(){const doc=parseRenderedPage(pageBeforeImmersiveSeparations());const mode=state.blockSeparator;if(!immersiveSeparations.some(([id])=>id===mode))return serializeRenderedPage(doc);const sections=[...doc.querySelectorAll('body>.modern-section,body>section[id^="rubrique-"],body>section#devis')];sections.forEach((section,index)=>{section.classList.add('immersive-boundary','boundary-'+mode);section.style.setProperty('--boundary-layer',String(index+1));section.querySelector('.block-separator-art')?.remove();if(mode==='opening'){for(const side of ['left','right']){const curtain=doc.createElement('span');curtain.className='boundary-curtain curtain-'+side;curtain.setAttribute('aria-hidden','true');section.append(curtain)}}});const style=doc.createElement('style');style.id='immersive-boundaries-style';style.textContent=`
 body>.immersive-boundary{background-color:${state.blockBackground}!important;isolation:isolate;scroll-margin-top:24px}
 body>.boundary-stack{position:sticky!important;top:18px;z-index:var(--boundary-layer);border-radius:24px 24px 0 0!important;box-shadow:0 -14px 35px #00000026!important;border-top:1px solid ${state.borderColor};margin-bottom:0!important;animation:none!important;scale:none!important;translate:none!important}
 .boundary-curtain{display:none;pointer-events:none}
 @supports(animation-timeline:view()){
 .boundary-opening>.boundary-curtain{display:block;position:absolute;top:0;bottom:0;width:50.1%;z-index:4;background:${state.background};pointer-events:none;animation:boundary-open linear both;animation-timeline:view();animation-range:entry 0% entry 85%}
 .boundary-opening>.curtain-left{left:0;transform-origin:left;border-right:1px solid ${state.accent}55}.boundary-opening>.curtain-right{right:0;transform-origin:right;border-left:1px solid ${state.accent}55}
 body>.boundary-depth{animation:boundary-depth-arrive linear both!important;animation-timeline:view()!important;animation-range:entry 0% entry 95%!important;transform-origin:center;box-shadow:0 25px 50px #00000020;border-radius:24px!important}
 }
 @keyframes boundary-open{0%{transform:scaleX(1);opacity:1}85%{opacity:1}100%{transform:scaleX(0);opacity:0}}
 @keyframes boundary-depth-arrive{from{scale:.86;translate:0 45px;opacity:.4}to{scale:1;translate:0 0;opacity:1}}
 @media(max-width:760px){body>.boundary-stack{position:relative!important;top:auto;border-radius:16px!important;margin-top:18px!important}.boundary-opening>.boundary-curtain{animation-range:entry 0% entry 65%}body>.boundary-depth{border-radius:16px!important}@keyframes boundary-depth-arrive{from{scale:.97;translate:0 12px;opacity:.7}to{scale:1;translate:0 0;opacity:1}}}
 @media(prefers-reduced-motion:reduce){body>.immersive-boundary{position:relative!important;top:auto;animation:none!important;translate:none!important;scale:none!important;opacity:1!important}.boundary-curtain{display:none!important}}
 @media print{body>.boundary-stack{position:static!important}.boundary-curtain{display:none!important}}
 `;doc.head.append(style);return serializeRenderedPage(doc)};render();update();
