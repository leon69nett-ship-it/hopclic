function removeServiceVideoChoices(root){
 for(const node of root.querySelectorAll('.service-video-settings,.service-empty-video'))node.remove();
 for(const label of root.querySelectorAll('label'))if(/^Vidéo de la bibliothèque/.test(label.textContent.trim()))label.remove();
 for(const button of root.querySelectorAll('button'))if(/vidéo/i.test(button.textContent))button.remove();
}
const serviceFieldsBeforePhotosOnly=renderServiceItems;
renderServiceItems=function(card,block){serviceFieldsBeforePhotosOnly(card,block);removeServiceVideoChoices(card)};
const renderBeforePhotosOnly=render;
render=function(){renderBeforePhotosOnly();for(const card of document.querySelectorAll('#editor .block'))if(state.blocks.find(b=>b.id===card.dataset.blockId)?.type==='services')removeServiceVideoChoices(card)};
const pageBeforePhotosOnly=page;
page=function(){
 const saved=state.blocks.filter(b=>b.type==='services').map(block=>({block,serviceVideoIds:block.serviceVideoIds,detailsVideoIds:block.detailsVideoIds}));
 try{
  for(const item of saved){item.block.serviceVideoIds=[];item.block.detailsVideoIds=[]}
  const doc=parseRenderedPage(pageBeforePhotosOnly());for(const section of doc.querySelectorAll('.services-section'))removeServiceVideoChoices(section);return serializeRenderedPage(doc);
 }finally{for(const item of saved){item.block.serviceVideoIds=item.serviceVideoIds;item.block.detailsVideoIds=item.detailsVideoIds}}
};
function removePreviewServiceVideoChoices(){const doc=previewFrame.contentDocument;if(doc)for(const section of doc.querySelectorAll('.services-section'))removeServiceVideoChoices(section)}
previewFrame.addEventListener('load',removePreviewServiceVideoChoices);
const refreshBeforePhotosOnly=refreshPreviewWithoutBlink;
refreshPreviewWithoutBlink=function(){refreshBeforePhotosOnly();removePreviewServiceVideoChoices()};
render();update();
