// Apply the requested palette once; later personal design choices stay saved.
if(!localStorage.getItem(KEY+'-terracotta-v1')){
  Object.assign(state,{accent:'#a74729',background:'#faf3ed',blockBackground:'#fffaf6',textColor:'#3f2b23',secondaryColor:'#765b4f',borderColor:'#e8cdbf',selectionColor:'#a74729',useCardColors:false});
  localStorage.setItem(KEY+'-terracotta-v1','1');
  render();update();
}
