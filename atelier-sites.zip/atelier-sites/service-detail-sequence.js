const renderServiceItemsBeforeDetailSequence = renderServiceItems;
renderServiceItems = function (card, block) {
  renderServiceItemsBeforeDetailSequence(card, block);
  if (serviceDetailsEditingKey !== block.id + ':' + selectedServiceIndex) return;
  const fields = card.querySelector('.service-item-fields');
  if (!fields) return;

  block.serviceDetailSequence ??= [];
  block.serviceDetailSequence[selectedServiceIndex] ??= ['', '', ''];
  const sequence = block.serviceDetailSequence[selectedServiceIndex];
  const panel = document.createElement('fieldset');
  panel.className = 'service-detail-sequence-editor';
  const legend = document.createElement('legend');
  legend.textContent = 'Fenêtre sur votre savoir-faire';
  const hint = document.createElement('p');
  hint.className = 'hint';
  hint.textContent = 'Créez une mini-visite en 3 images. Vos visiteurs les feront défiler dans « En savoir plus ».';
  panel.append(legend, hint);

  for (let index = 0; index < 3; index++) {
    const row = document.createElement('div');
    row.className = 'service-detail-sequence-row';
    if (sequence[index]) row.classList.add('has-image');
    const number = document.createElement('span');
    number.className = 'service-detail-sequence-number';
    number.textContent = String(index + 1).padStart(2, '0');
    row.append(number);
    const label = document.createElement('strong');
    label.textContent = 'Image ' + (index + 1);
    row.append(label);
    if (sequence[index]) {
      const image = document.createElement('img');
      image.src = sequence[index];
      image.alt = 'Aperçu de l’image ' + (index + 1);
      row.append(image);
    } else {
      const placeholder = document.createElement('span');
      placeholder.className = 'service-detail-sequence-placeholder';
      placeholder.textContent = '+';
      placeholder.setAttribute('aria-hidden', 'true');
      row.append(placeholder);
    }
    const choose = document.createElement('button');
    choose.type = 'button';
    choose.className = 'service-detail-sequence-choose';
    choose.textContent = sequence[index] ? 'Remplacer' : '+ Ajouter une photo';
    choose.onclick = () => {
      const current = state.photoLibrary.find(photo => photo.src === sequence[index]);
      openUnifiedPhotoPicker(current ? [current.id] : [], false, ids => {
        sequence[index] = state.photoLibrary.find(photo => photo.id === ids[0])?.src || '';
        update();
        render();
      });
    };
    row.append(choose);
    if (sequence[index]) {
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'service-detail-sequence-remove';
      remove.textContent = 'Retirer';
      remove.setAttribute('aria-label', 'Retirer l’image ' + (index + 1));
      remove.onclick = () => {
        sequence[index] = '';
        update();
        render();
      };
      row.append(remove);
    }
    panel.append(row);
  }
  fields.append(panel);
};

function detailSequenceNavigate(event, direction) {
  event.preventDefault();
  const gallery = event.currentTarget.closest('.service-detail-sequence');
  if (!gallery) return;
  const slides = [...gallery.querySelectorAll('.service-detail-sequence-slide')];
  if (slides.length < 2) return;
  const requestedIndex = event.currentTarget.dataset.slideIndex;
  let index = requestedIndex === undefined
    ? Number(gallery.dataset.activeIndex || 0) + direction
    : Number(requestedIndex);
  index = (index + slides.length) % slides.length;
  gallery.dataset.activeIndex = String(index);
  slides.forEach((slide, position) => { slide.hidden = position !== index; });
  const label = String(index + 1).padStart(2, '0') + ' / ' + String(slides.length).padStart(2, '0');
  gallery.querySelector('.service-detail-sequence-count').textContent = label;
  gallery.querySelector('.service-detail-sequence-position').textContent = label;
  gallery.querySelectorAll('.service-detail-sequence-thumb').forEach((thumb, position) => {
    const active = position === index;
    thumb.classList.toggle('is-active', active);
    thumb.setAttribute('aria-pressed', String(active));
  });
}

const pageBeforeDetailSequence = page;
page = function () {
  const doc = parseRenderedPage(pageBeforeDetailSequence());
  for (const block of state.blocks.filter(item => item.type === 'services' && item.visible)) {
    const section = doc.getElementById('rubrique-' + block.id);
    if (!section) continue;
    section.querySelectorAll('.service-card').forEach((card, index) => {
      const photos = (block.serviceDetailSequence?.[index] || []).filter(Boolean).slice(0, 3);
      if (!photos.length) return;
      const dialog = card.querySelector('.service-info-dialog');
      if (!dialog || dialog.querySelector('.service-detail-sequence')) return;
      const sequence = doc.createElement('div');
      sequence.className = 'service-detail-sequence';
      sequence.dataset.activeIndex = '0';
      sequence.setAttribute('aria-label', 'Photos de présentation');
      const slides = doc.createElement('div');
      slides.className = 'service-detail-sequence-slides';
      photos.forEach((src, position) => {
        const image = doc.createElement('img');
        image.className = 'service-detail-sequence-slide';
        image.src = src;
        image.alt = 'Fenêtre sur votre savoir-faire · image ' + (position + 1);
        image.hidden = position !== 0;
        image.loading = 'lazy';
        slides.append(image);
      });
      const position = doc.createElement('span');
      position.className = 'service-detail-sequence-position';
      position.textContent = '01 / ' + String(photos.length).padStart(2, '0');
      slides.append(position);
      const controls = doc.createElement('div');
      controls.className = 'service-detail-sequence-controls';
      const previous = doc.createElement('button');
      previous.type = 'button';
      previous.textContent = '←';
      previous.setAttribute('aria-label', 'Image précédente');
      previous.setAttribute('onclick', '(' + detailSequenceNavigate.toString() + ')(event,-1)');
      const count = doc.createElement('span');
      count.className = 'service-detail-sequence-count';
      count.setAttribute('aria-live', 'polite');
      count.textContent = '01 / ' + String(photos.length).padStart(2, '0');
      const next = doc.createElement('button');
      next.type = 'button';
      next.textContent = '→';
      next.setAttribute('aria-label', 'Image suivante');
      next.setAttribute('onclick', '(' + detailSequenceNavigate.toString() + ')(event,1)');
      controls.append(previous, count, next);
      const thumbnails = doc.createElement('div');
      thumbnails.className = 'service-detail-sequence-thumbnails';
      thumbnails.setAttribute('aria-label', 'Choisir une image');
      photos.forEach((src, position) => {
        const thumbnail = doc.createElement('button');
        thumbnail.type = 'button';
        thumbnail.className = 'service-detail-sequence-thumb' + (position === 0 ? ' is-active' : '');
        thumbnail.setAttribute('aria-label', 'Afficher l’image ' + (position + 1));
        thumbnail.setAttribute('aria-pressed', String(position === 0));
        thumbnail.dataset.slideIndex = String(position);
        thumbnail.setAttribute('onclick', '(' + detailSequenceNavigate.toString() + ')(event,0)');
        const thumbnailImage = doc.createElement('img');
        thumbnailImage.src = src;
        thumbnailImage.alt = '';
        thumbnailImage.loading = 'lazy';
        thumbnail.append(thumbnailImage);
        thumbnails.append(thumbnail);
      });
      sequence.append(slides, controls, thumbnails);
      const title = dialog.querySelector('h2');
      if (title) title.after(sequence);
      else dialog.querySelector('.service-info-close')?.after(sequence);
    });
  }
  const style = doc.createElement('style');
  style.textContent = '.service-detail-sequence{margin:22px 0}.service-detail-sequence-slides{position:relative;overflow:hidden;border-radius:18px;background:#f3e8de;box-shadow:0 16px 36px #492c1d24}.service-detail-sequence-slide{display:block;width:100%;max-height:55vh;aspect-ratio:16/10;object-fit:cover}.service-detail-sequence-slide[hidden]{display:none!important}.service-detail-sequence-position{position:absolute;right:14px;bottom:14px;padding:7px 11px;border:1px solid #ffffff80;border-radius:999px;background:#2d1c17c9;color:#fff;font:600 11px/1 Arial,sans-serif;letter-spacing:.1em;backdrop-filter:blur(8px)}.service-detail-sequence-controls{display:flex;align-items:center;justify-content:center;gap:16px;margin:14px 0}.service-detail-sequence-controls button{min-width:42px;min-height:42px;border:1px solid #d9bca5;border-radius:50%;background:#fffaf5;color:#603c2a;box-shadow:0 5px 14px #492c1d16;transition:transform .2s,box-shadow .2s}.service-detail-sequence-controls button:hover{transform:translateY(-2px);box-shadow:0 9px 20px #492c1d28}.service-detail-sequence-count{min-width:70px;text-align:center;color:#72523e;font:600 12px/1 Arial,sans-serif;letter-spacing:.12em}.service-detail-sequence-thumbnails{display:flex;justify-content:center;gap:10px}.service-detail-sequence-thumb{width:68px;height:52px;padding:3px;border:1px solid transparent;border-radius:11px;background:transparent;opacity:.62;cursor:pointer;transition:opacity .2s,transform .2s,border-color .2s}.service-detail-sequence-thumb:hover{opacity:1;transform:translateY(-2px)}.service-detail-sequence-thumb.is-active{border-color:#99501f;opacity:1;box-shadow:0 4px 12px #492c1d20}.service-detail-sequence-thumb img{display:block;width:100%;height:100%;object-fit:cover;border-radius:7px}.service-detail-sequence-editor{margin:20px 0;padding:18px;border:1px solid var(--ui-border,#ddcbbb);border-radius:16px;background:linear-gradient(145deg,#fffaf5,#f8eee4);box-shadow:0 10px 26px #49302212}.service-detail-sequence-editor legend{padding:0 8px;color:#493022;font-size:16px;font-weight:700;letter-spacing:.01em}.service-detail-sequence-editor>.hint{margin:2px 0 16px;line-height:1.5}.service-detail-sequence-row{display:grid;grid-template-columns:34px minmax(58px,1fr) 86px auto auto;align-items:center;gap:10px;margin:9px 0;padding:10px;border:1px solid #ead9ca;border-radius:14px;background:#fffdf9;transition:border-color .2s,box-shadow .2s}.service-detail-sequence-row.has-image{border-color:#d2ae90;box-shadow:0 5px 16px #492c1d0d}.service-detail-sequence-number{display:grid;place-items:center;width:30px;height:30px;border-radius:50%;background:#f4e6d9;color:#82502e;font:700 11px/1 Arial,sans-serif;letter-spacing:.04em}.service-detail-sequence-row strong{color:#493022;font-size:14px}.service-detail-sequence-row img,.service-detail-sequence-placeholder{display:grid;place-items:center;width:86px;height:58px;object-fit:cover;border-radius:9px}.service-detail-sequence-placeholder{border:1px dashed #d6bba4;background:#fbf2e9;color:#a27451;font-size:22px}.service-detail-sequence-row button{min-height:38px;border-radius:999px}.service-detail-sequence-row .service-detail-sequence-choose{padding:8px 14px;border:0;background:#493022;color:#fff8ee;font-weight:600;white-space:nowrap}.service-detail-sequence-row .service-detail-sequence-choose:hover{background:#75462a;box-shadow:0 5px 14px #49302235;transform:translateY(-1px)}.service-detail-sequence-row .service-detail-sequence-remove{padding:7px 10px;border:1px solid #e7d5c5;background:transparent;color:#795b49;font-size:12px}.service-detail-sequence-row .service-detail-sequence-remove:hover{background:#f8eee4}@media(max-width:600px){.service-detail-sequence-row{grid-template-columns:30px 1fr auto;gap:8px}.service-detail-sequence-row img,.service-detail-sequence-placeholder{grid-column:2;width:100%;height:90px}.service-detail-sequence-row .service-detail-sequence-choose{grid-column:2}.service-detail-sequence-row .service-detail-sequence-remove{grid-column:3;grid-row:2}.service-detail-sequence-thumb{width:58px;height:46px}}';
  doc.head.append(style);
  return serializeRenderedPage(doc);
};

if (!document.getElementById('service-detail-sequence-editor-style')) {
  const editorStyle = document.createElement('style');
  editorStyle.id = 'service-detail-sequence-editor-style';
  editorStyle.textContent = '.service-detail-sequence-editor{margin:20px 0;padding:18px;border:1px solid var(--ui-border,#ddcbbb);border-radius:16px;background:linear-gradient(145deg,#fffaf5,#f8eee4);box-shadow:0 10px 26px #49302212}.service-detail-sequence-editor legend{padding:0 8px;color:#493022;font-size:16px;font-weight:700;letter-spacing:.01em}.service-detail-sequence-editor>.hint{margin:2px 0 16px;line-height:1.5}.service-detail-sequence-row{display:grid;grid-template-columns:34px minmax(58px,1fr) 86px auto auto;align-items:center;gap:10px;margin:9px 0;padding:10px;border:1px solid #ead9ca;border-radius:14px;background:#fffdf9;transition:border-color .2s,box-shadow .2s}.service-detail-sequence-row.has-image{border-color:#d2ae90;box-shadow:0 5px 16px #492c1d0d}.service-detail-sequence-number{display:grid;place-items:center;width:30px;height:30px;border-radius:50%;background:#f4e6d9;color:#82502e;font:700 11px/1 Arial,sans-serif;letter-spacing:.04em}.service-detail-sequence-row strong{color:#493022;font-size:14px}.service-detail-sequence-row img,.service-detail-sequence-placeholder{display:grid;place-items:center;width:86px;height:58px;object-fit:cover;border-radius:9px}.service-detail-sequence-placeholder{border:1px dashed #d6bba4;background:#fbf2e9;color:#a27451;font-size:22px}.service-detail-sequence-row button{min-height:38px;border-radius:999px}.service-detail-sequence-row .service-detail-sequence-choose{padding:8px 14px;border:0;background:#493022;color:#fff8ee;font-weight:600;white-space:nowrap}.service-detail-sequence-row .service-detail-sequence-choose:hover{background:#75462a;box-shadow:0 5px 14px #49302235;transform:translateY(-1px)}.service-detail-sequence-row .service-detail-sequence-remove{padding:7px 10px;border:1px solid #e7d5c5;background:transparent;color:#795b49;font-size:12px}.service-detail-sequence-row .service-detail-sequence-remove:hover{background:#f8eee4}@media(max-width:600px){.service-detail-sequence-row{grid-template-columns:30px 1fr auto;gap:8px}.service-detail-sequence-row img,.service-detail-sequence-placeholder{grid-column:2;width:100%;height:90px}.service-detail-sequence-row .service-detail-sequence-choose{grid-column:2}.service-detail-sequence-row .service-detail-sequence-remove{grid-column:3;grid-row:2}}';
  document.head.append(editorStyle);
}

render();
update();
