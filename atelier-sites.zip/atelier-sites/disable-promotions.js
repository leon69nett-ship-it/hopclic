function hidePromotionBlocks(blocks){return blocks.filter(block=>block.type!=='promotions')}
