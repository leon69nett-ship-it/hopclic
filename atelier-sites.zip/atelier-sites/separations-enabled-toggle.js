// Let the user show or hide the complete separation settings panel.
const separationPanelVisibilityKey = KEY + '-separation-panel-visible';
const renderBeforeSeparationPanelVisibility = render;
render = function () {
  renderBeforeSeparationPanelVisibility();
  if (tab !== 'design') return;
  const effect = document.querySelector('[aria-label="Découpe des séparations"]');
  const panel = effect?.closest('section');
  if (!panel || document.querySelector('#editor .separation-panel-visibility')) return;

  const label = document.createElement('label');
  label.className = 'separation-panel-visibility';
  label.textContent = 'Afficher le panneau des séparations';
  const select = document.createElement('select');
  select.setAttribute('aria-label', 'Afficher le panneau des séparations');
  select.innerHTML = '<option value="show">Afficher</option><option value="hide">Masquer</option>';
  let visible = true;
  try { visible = localStorage.getItem(separationPanelVisibilityKey) !== 'hide'; } catch {}
  select.value = visible ? 'show' : 'hide';
  panel.hidden = !visible;
  select.onchange = () => {
    panel.hidden = select.value === 'hide';
    try { localStorage.setItem(separationPanelVisibilityKey, select.value); } catch {}
  };
  label.append(select);
  panel.before(label);
};
render();
