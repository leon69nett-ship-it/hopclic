const companyDesignStyles=[
 {name:'Artisan chaleureux',note:'Bâtiment, rénovation et savoir-faire',colors:['#fbf4ee','#ffffff','#402d25','#786054','#a44829','#e5d3c5'],font:'Georgia',radius:'8',relief:30},
 {name:'Entreprise moderne',note:'Services, conseil et activités professionnelles',colors:['#f1f5fa','#ffffff','#182c46','#596b80','#245fa2','#cfdae7'],font:'Arial',radius:'8',relief:20},
 {name:'Nature & bien-être',note:'Jardin, artisanat et accompagnement',colors:['#f5f7ed','#ffffff','#263c32','#53664e','#315b47','#d6ddd4'],font:'Trebuchet MS',radius:'20',relief:20},
 {name:'Créatif & dynamique',note:'Communication, loisirs et indépendants',colors:['#f6f0ff','#ffffff','#332344','#69527c','#7740a5','#dcc9ee'],font:'Verdana',radius:'20',relief:40},
 {name:'Élégance premium',note:'Décoration, architecture et prestations soignées',colors:['#fbf8f1','#ffffff','#30291e','#71644e','#80601e','#dfd4bd'],font:'Georgia',radius:'0',relief:15},
 {name:'Commerce vitaminé',note:'Boutique, restauration et offres locales',colors:['#fff3ee','#ffffff','#44241e','#795047','#b63b28','#efc7bb'],font:'Trebuchet MS',radius:'20',relief:35}
];
const renderBeforeCompanyStyles=render;
render=function(){
 renderBeforeCompanyStyles();
 document.querySelectorAll('#editor .company-style-choices').forEach(section=>section.remove());
};
render();

