(() => {
  const minBlockHeight = 180;
  const maxBlockHeight = 1800;
  const savedHeight = value => {
    const height = Number(value);
    return Number.isFinite(height) && height > 0
      ? Math.round(Math.max(minBlockHeight, Math.min(maxBlockHeight, height)))
      : null;
  };

  const ensureBlockHeightControls = () => {
    if (tab !== 'blocks') return;
    const cards = [...document.querySelectorAll('#editor article.block')];
    cards.forEach((card, index) => {
      const block = state.blocks[index];
      const details = card.querySelector('details');
      if (!block || !details || details.querySelector('.block-height-setting')) return;

      const setting = document.createElement('section');
      setting.className = 'block-height-setting';
      setting.style.cssText = 'display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:8px;margin-top:14px;padding:12px;border:1px solid #e5caba;border-radius:10px;background:#fffaf5';
      const label = document.createElement('label');
      label.style.cssText = 'display:grid;grid-template-columns:1fr auto;align-items:center;gap:5px 10px;color:#38281f;font-size:12px;font-weight:700';
      const title = document.createElement('span');
      title.textContent = 'Hauteur du bloc';
      const value = document.createElement('output');
      const range = document.createElement('input');
      range.type = 'range';
      range.min = String(minBlockHeight);
      range.max = String(maxBlockHeight);
      range.step = '20';
      range.value = String(savedHeight(block.renderHeight) || 420);
      range.style.cssText = 'grid-column:1/-1;width:100%;accent-color:#8e3d25';
      range.setAttribute('aria-label', `Hauteur du bloc ${block.title}`);
      const refresh = () => {
        value.value = block.renderHeight ? `${block.renderHeight} px` : 'Automatique';
        value.textContent = value.value;
      };
      range.addEventListener('input', () => {
        block.renderHeight = savedHeight(range.value);
        refresh();
        update();
      });
      const reset = document.createElement('button');
      reset.type = 'button';
      reset.className = 'block-height-reset';
      reset.textContent = 'Automatique';
      reset.style.cssText = 'padding:6px 9px;border:1px solid #b88e70;border-radius:7px;background:#fff;color:#38281f;font-size:11px;cursor:pointer';
      reset.addEventListener('click', () => {
        block.renderHeight = null;
        range.value = '420';
        refresh();
        update();
      });
      label.append(title, value, range);
      setting.append(label, reset);
      details.append(setting);
      refresh();
    });
  };

  const renderBeforeBlockHeightControls = render;
  render = function () {
    renderBeforeBlockHeightControls();
    ensureBlockHeightControls();
  };

  const validateBeforePreviewBlockResize = validate;
  validate = function (saved) {
    const result = validateBeforePreviewBlockResize(saved);
    const savedBlocks = new Map((saved?.blocks || []).map(block => [String(block.id), block]));
    result.blocks = result.blocks.map(block => ({
      ...block,
      renderHeight: savedHeight(savedBlocks.get(String(block.id))?.renderHeight)
    }));
    return result;
  };

  const pageBeforePreviewBlockResize = page;
  page = function () {
    const doc = parseRenderedPage(pageBeforePreviewBlockResize());
    const blocks = state.blocks.filter(block => block.visible);
    doc.querySelectorAll('body>section:not(.business-card)').forEach((section, index) => {
      const height = savedHeight(blocks[index]?.renderHeight);
      if (height) section.style.minHeight = `${height}px`;
    });
    return serializeRenderedPage(doc);
  };

  const previewFrameForBlockResize = document.getElementById('preview');
  const installBlockResizeHandles = () => {
    const doc = previewFrameForBlockResize?.contentDocument;
    if (!doc?.body) return;
    let style = doc.getElementById('preview-block-resize-style-v3');
    if (!style) {
      style = doc.createElement('style');
      style.id = 'preview-block-resize-style-v3';
      style.textContent = '.preview-block-resize{position:absolute;left:50%;bottom:-14px;transform:translateX(-50%);z-index:2147483002;display:flex;align-items:center;justify-content:center;min-width:28px!important;width:28px!important;height:24px!important;min-height:24px!important;padding:0!important;border:1px solid #94502a80!important;border-radius:9px!important;background:#fff8f1e8!important;backdrop-filter:none;-webkit-backdrop-filter:none;color:#823b1f!important;box-shadow:0 1px 3px #4b291a24!important;text-shadow:none!important;font:700 18px/1 Arial!important;cursor:ns-resize!important;touch-action:none!important;user-select:none}.preview-block-resize:hover,.preview-block-resize:focus-visible{background:#fff!important;border-color:#94502a!important;outline:2px solid #94502a55;outline-offset:2px}.preview-block-resizing{transition:none!important}.preview-block-move{position:absolute;left:8px;top:8px;z-index:12;display:flex;align-items:center;justify-content:center;min-width:28px!important;width:28px!important;height:28px!important;min-height:28px!important;padding:0!important;border:1px solid var(--selection-color)!important;border-radius:7px!important;background:#fff!important;color:var(--selection-color)!important;box-shadow:0 2px 7px #0002!important;font:18px/1 Arial!important;cursor:grab!important;touch-action:none!important;user-select:none}.preview-block-move:active{cursor:grabbing!important}.preview-block-moving{opacity:.62!important;outline:2px dashed var(--selection-color)!important}.preview-block-drop-target{outline:3px solid var(--selection-color)!important;outline-offset:-3px}';
      doc.head.append(style);
    }
    const blockSections = [...doc.querySelectorAll('[data-editor-block]')];
    for (const [sectionIndex, section] of blockSections.entries()) {
      if (section.querySelector('.preview-block-resize')) continue;
      const block = state.blocks.find(item => item.id === section.dataset.editorBlock);
      if (!block) continue;
      const initialHeight = savedHeight(block.renderHeight);
      if (initialHeight) section.style.minHeight = `${initialHeight}px`;
      if (doc.defaultView.getComputedStyle(section).position === 'static') section.style.position = 'relative';
      section.style.zIndex = String(blockSections.length - sectionIndex + 1);
      const handle = doc.createElement('button');
      handle.type = 'button';
      handle.className = 'preview-block-resize';
      handle.textContent = '↕';
      handle.setAttribute('role', 'slider');
      handle.setAttribute('aria-orientation', 'vertical');
      handle.setAttribute('aria-valuemin', String(minBlockHeight));
      handle.setAttribute('aria-valuemax', String(maxBlockHeight));
      handle.setAttribute('aria-label', `Tirer pour ajuster la hauteur du bloc ${block.title}. Double-cliquer pour réinitialiser.`);
      handle.title = 'Cliquer pour agrandir, tirer pour ajuster la hauteur · double-cliquer pour réinitialiser';
      handle.style.cssText = 'position:absolute!important;left:50%!important;right:auto!important;bottom:4px!important;transform:translateX(-50%)!important;z-index:2147483002!important;display:flex!important;align-items:center!important;justify-content:center!important;width:28px!important;min-width:28px!important;height:24px!important;min-height:24px!important;padding:0!important;border:1px solid #94502a80!important;border-radius:9px!important;background:#fff8f1e8!important;color:#823b1f!important;box-shadow:0 1px 3px #4b291a24!important;font:700 18px/1 Arial!important;cursor:ns-resize!important;touch-action:none!important;user-select:none!important;pointer-events:auto!important;opacity:1!important';
      let drag = null;
      let suppressClick = false;
      const applyHeight = height => {
        const bounded = Math.round(Math.max(minBlockHeight, Math.min(maxBlockHeight, height)));
        section.style.minHeight = `${bounded}px`;
        handle.setAttribute('aria-valuenow', String(bounded));
        handle.title = `Hauteur minimale : ${bounded}px`;
        return bounded;
      };
      handle.addEventListener('pointerdown', event => {
        event.preventDefault();
        event.stopPropagation();
        drag = { y: event.clientY, height: section.getBoundingClientRect().height, pointerId: event.pointerId, moved: false };
        section.classList.add('preview-block-resizing');
        handle.setPointerCapture(event.pointerId);
      });
      handle.addEventListener('pointermove', event => {
        if (!drag || drag.pointerId !== event.pointerId) return;
        drag.moved ||= Math.abs(event.clientY - drag.y) > 3;
        applyHeight(drag.height + event.clientY - drag.y);
      });
      const finish = event => {
        if (!drag || (event.pointerId !== undefined && drag.pointerId !== event.pointerId)) return;
        const moved = drag.moved || Math.abs((event.clientY ?? drag.y) - drag.y) > 3;
        const height = moved ? applyHeight(drag.height + (event.clientY ?? drag.y) - drag.y) : null;
        drag = null;
        section.classList.remove('preview-block-resizing');
        if (moved) {
          suppressClick = event.type === 'pointerup';
          block.renderHeight = height;
          update();
        }
      };
      handle.addEventListener('pointerup', finish);
      handle.addEventListener('pointercancel', finish);
      handle.addEventListener('click', event => {
        event.preventDefault();
        if (suppressClick) { suppressClick = false; return; }
        block.renderHeight = applyHeight(section.getBoundingClientRect().height + 60);
        update();
      });
      handle.addEventListener('keydown', event => {
        if (event.key === 'Home') {
          event.preventDefault();
          block.renderHeight = null;
          section.style.removeProperty('min-height');
          handle.removeAttribute('aria-valuenow');
          update();
        } else if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
          event.preventDefault();
          block.renderHeight = applyHeight(section.getBoundingClientRect().height + (event.key === 'ArrowUp' ? 20 : -20));
          update();
        }
      });
      handle.addEventListener('dblclick', event => {
        event.preventDefault();
        event.stopPropagation();
        block.renderHeight = null;
        section.style.removeProperty('min-height');
        handle.removeAttribute('aria-valuenow');
        handle.title = 'Tirer pour ajuster la hauteur · double-cliquer pour réinitialiser';
        update();
      });
      section.append(handle);
      if (initialHeight) handle.setAttribute('aria-valuenow', String(initialHeight));

      if (doc.body.dataset.blockPresentation === 'cards' && block.type !== 'intro') {
        const moveHandle = doc.createElement('button');
        moveHandle.type = 'button';
        moveHandle.className = 'preview-block-move';
        moveHandle.textContent = '⠿';
        moveHandle.setAttribute('aria-label', `Déplacer le bloc ${block.title} dans la grille avec les flèches du clavier ou en le tirant`);
        moveHandle.title = 'Tirer pour déplacer ce bloc dans la grille';
        const clearTargets = () => doc.querySelectorAll('.preview-block-drop-target').forEach(target => target.classList.remove('preview-block-drop-target'));
        const swapBlocks = targetId => {
          if (!targetId || targetId === block.id) return;
          const sourceIndex = state.blocks.findIndex(item => item.id === block.id);
          const targetIndex = state.blocks.findIndex(item => item.id === targetId);
          if (sourceIndex < 0 || targetIndex < 0 || state.blocks[targetIndex].type === 'intro') return;
          [state.blocks[sourceIndex], state.blocks[targetIndex]] = [state.blocks[targetIndex], state.blocks[sourceIndex]];
          render();
          update();
        };
        let moveDrag = null;
        moveHandle.addEventListener('pointerdown', event => {
          event.preventDefault();
          event.stopPropagation();
          moveDrag = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, moved: false };
          moveHandle.setPointerCapture(event.pointerId);
        });
        moveHandle.addEventListener('pointermove', event => {
          if (!moveDrag || moveDrag.pointerId !== event.pointerId) return;
          if (!moveDrag.moved && Math.hypot(event.clientX - moveDrag.x, event.clientY - moveDrag.y) < 6) return;
          moveDrag.moved = true;
          section.classList.add('preview-block-moving');
          clearTargets();
          const target = doc.elementFromPoint(event.clientX, event.clientY)?.closest('[data-editor-block]');
          const targetBlock = state.blocks.find(item => item.id === target?.dataset.editorBlock);
          if (target && targetBlock?.type !== 'intro') target.classList.add('preview-block-drop-target');
        });
        const finishMove = event => {
          if (!moveDrag || (event.pointerId !== undefined && moveDrag.pointerId !== event.pointerId)) return;
          const target = moveDrag.moved ? doc.elementFromPoint(event.clientX, event.clientY)?.closest('[data-editor-block]') : null;
          const targetId = target?.dataset.editorBlock;
          const moved = moveDrag.moved;
          moveDrag = null;
          section.classList.remove('preview-block-moving');
          clearTargets();
          if (moved) swapBlocks(targetId);
        };
        moveHandle.addEventListener('pointerup', finishMove);
        moveHandle.addEventListener('pointercancel', finishMove);
        moveHandle.addEventListener('keydown', event => {
          const columns = 2;
          const delta = event.key === 'ArrowLeft' ? -1 : event.key === 'ArrowRight' ? 1 : event.key === 'ArrowUp' ? -columns : event.key === 'ArrowDown' ? columns : 0;
          if (!delta) return;
          event.preventDefault();
          const visible = state.blocks.filter(item => item.visible && item.type !== 'intro');
          const current = visible.findIndex(item => item.id === block.id);
          const target = visible[current + delta];
          if (target) swapBlocks(target.id);
        });
        section.append(moveHandle);
      }
    }
  };

  previewFrameForBlockResize?.addEventListener('load', installBlockResizeHandles);
  installBlockResizeHandles();
})();
