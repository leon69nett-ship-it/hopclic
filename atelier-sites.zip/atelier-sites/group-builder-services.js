const renderBeforeBuilderServicesGroup=render;
render=function(){
 renderBeforeBuilderServicesGroup();if(tab!=='blocks')return;
 const menu=document.querySelector('#editor .content-menu');if(!menu)return;
 const services=state.blocks.find(b=>b.type==='services'),gallery=state.blocks.find(b=>b.type==='gallery');
 if(!services||!gallery)return;
 const serviceButton=[...menu.querySelectorAll('.content-choice')].find(b=>b.dataset.id===services.id),galleryButton=[...menu.querySelectorAll('.content-choice')].find(b=>b.dataset.id===gallery.id);if(!serviceButton||!galleryButton)return;
 const group=document.createElement('div');group.style.cssText='min-width:0';
 const trigger=document.createElement('button');trigger.type='button';trigger.textContent='🛠️ Prestations ▾';trigger.style.cssText='width:100%;height:100%;min-height:78px;text-align:left;padding:16px;font-weight:700';
 const panel=document.createElement('div');panel.hidden=true;panel.style.cssText='grid-column:1/-1;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;padding:10px;border:1px solid var(--ui-border);border-radius:10px';
 panel.id='builder-services-options';trigger.setAttribute('aria-controls',panel.id);trigger.setAttribute('aria-expanded','false');
 trigger.onclick=()=>{panel.hidden=!panel.hidden;panel.style.display=panel.hidden?'none':'grid';trigger.setAttribute('aria-expanded',String(!panel.hidden))};
 panel.style.display='none';
 serviceButton.before(group);group.append(trigger);menu.append(panel);panel.append(serviceButton,galleryButton);
 const first=serviceButton.querySelector('strong');if(first)first.textContent='Nos prestations';const second=galleryButton.querySelector('strong');if(second)second.textContent='Nos réalisations';
};
render();
