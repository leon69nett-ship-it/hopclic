(()=>{
 const query=new URLSearchParams(location.search),client=query.get('mode')==='client',draft=query.has('draft');
 const previewTargetOrigin=location.origin==='null'?'*':location.origin;
 const base=client?'atelier-artisans-client-published-v1':'atelier-artisans-template-v1';
 const label=document.querySelector('#label'),frame=document.querySelector('#site');
 const builder=(location.pathname.includes('demo-actions-site')?'demo-actions.html':'index.html')+(client?'?mode=client':'');
 document.querySelector('#return').href=builder;
 const display=html=>{if(typeof html!=='string'||!html.trim())return false;frame.srcdoc=html;label.textContent=draft?'Aperçu du brouillon · non publié':'Version validée';return true};
 if(draft){
  label.textContent='Chargement de votre site…';let ready=false,hidden;
  window.addEventListener('message',event=>{if(event.origin!==location.origin||event.source!==window.opener||event.data?.type!=='hopclic-preview')return;if(display(event.data.html)){ready=true;hidden?.remove()}});
  try{window.opener?.postMessage({type:'hopclic-request-preview'},previewTargetOrigin)}catch{}
  setTimeout(()=>{
   if(ready)return;
   hidden=document.createElement('iframe');hidden.hidden=true;hidden.src=builder;
   hidden.onload=async()=>{try{await hidden.contentWindow.photoLibraryReady;if(ready)return;const html=hidden.contentWindow.page();if(display(html)){ready=true;hidden.remove()}}catch{label.textContent='Aperçu indisponible. Revenez au constructeur et réessayez.'}};
   document.body.append(hidden);
  },500);
 }else{
  (async()=>{let html;try{html=localStorage.getItem(base+'-html');const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('hopclic-media-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('media');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});const saved=await new Promise((resolve,reject)=>{const r=db.transaction('media').objectStore('media').get(base);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});html=saved?.html||html;db.close()}catch{}if(!display(html)){label.textContent='Aucune version validée';frame.srcdoc='<p style="padding:40px;font-family:Arial">Aucune version validée. Revenez au constructeur pour publier vos modifications.</p>'}})();
 }
})();
