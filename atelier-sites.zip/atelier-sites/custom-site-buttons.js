// Create, manage and position custom call-to-action buttons in rendered blocks.
(() => {
  const safeUrl = value => {
    const url = String(value || '').trim();
    if (/^#[A-Za-z][\w:.-]*$/.test(url)) return url;
    if (/^(mailto:|tel:)[^\s<>]+$/i.test(url)) return url;
    try {
      if (!/^https?:\/\//i.test(url)) return '';
      const parsed = new URL(url);
      if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password) return '';
      return parsed.href;
    } catch { return ''; }
  };

  const previousValidate = validate;
  validate = function (saved) {
    const result = previousValidate(saved);
    const oldBlocks = Array.isArray(saved?.blocks) ? saved.blocks : [];
    const blockIds = new Map(oldBlocks.map((block, index) => [String(block?.id || ''), result.blocks[index]?.id]).filter(([id, next]) => id && next));
    result.customSiteButtons = (Array.isArray(saved?.customSiteButtons) ? saved.customSiteButtons : [])
      .slice(0, 30)
      .map(item => ({
        id: /^[\w-]{1,80}$/.test(String(item?.id || '')) ? String(item.id) : crypto.randomUUID(),
        blockId: blockIds.get(String(item?.blockId || '')) || '',
        label: String(item?.label || '').trim().slice(0, 80),
        subtitle: String(item?.subtitle || '').trim().slice(0, 100),
        scale: Math.max(.65, Math.min(1.8, Number(item?.scale) || 1)),
        indicator: item?.indicator === 'light' ? 'light' : 'plus',
        url: safeUrl(item?.url)
      }))
      .filter(item => item.blockId && item.label && item.url);
    return result;
  };

  const previousPage = page;
  page = function () {
    const doc = new DOMParser().parseFromString(previousPage(), 'text/html');
    const visibleBlocks = state.blocks.filter(block => block.visible);
    const sections = [...doc.querySelectorAll('body > section:not(.business-card)')];
    const style = doc.createElement('style');
    style.textContent = `
      .custom-site-actions{display:flex;flex-wrap:wrap;align-items:center;column-gap:16px;row-gap:16px;margin:22px 0 4px}
      .custom-site-button{position:relative;isolation:isolate;display:inline-flex;align-items:center;justify-content:space-between;gap:26px;min-width:190px;max-width:100%;min-height:64px;padding:10px 16px 10px 18px;border:1px solid #f9fafc;border-radius:24px;background:linear-gradient(150deg,#f9f9fb 0%,#eeeef2 58%,#e6e6eb 100%);color:#20212a;font:600 14px/1.2 Arial,sans-serif;text-align:left;text-decoration:none;box-shadow:7px 9px 14px rgba(45,46,55,.23),-5px -5px 12px rgba(255,255,255,.95),inset 1px 1px 2px rgba(255,255,255,.95),inset -1px -1px 2px rgba(80,82,94,.12);transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease}
      .custom-site-button-copy{display:grid;gap:3px;min-width:0}.custom-site-button-copy strong{font-size:15px;font-weight:700;overflow-wrap:anywhere}.custom-site-button-copy small{color:#757780;font-size:11px;font-weight:400;overflow-wrap:anywhere}
      .custom-site-button-indicator{display:grid;place-items:center;flex:0 0 26px;width:26px;height:26px;border-radius:50%;color:#252630;font-size:21px;font-weight:400;line-height:1;transition:color .2s ease,box-shadow .2s ease,background .2s ease}
      .custom-site-button[data-indicator="light"] .custom-site-button-indicator{width:15px;height:15px;flex-basis:15px;background:linear-gradient(145deg,#fff8d0,#f8c95c);box-shadow:0 0 8px #ffdf80,0 0 17px #f8b83a99,inset 1px 1px 2px #fff}
      .custom-site-button:hover,.custom-site-button:focus-visible{transform:translateY(-2px);border-color:#fff;box-shadow:9px 12px 18px rgba(45,46,55,.25),-5px -5px 13px rgba(255,255,255,.98),0 0 17px color-mix(in srgb,${state.accent} 20%,transparent),inset 1px 1px 2px #fff}
      .custom-site-button:hover .custom-site-button-indicator,.custom-site-button:focus-visible .custom-site-button-indicator{color:${state.accent};text-shadow:0 0 8px #ffce62,0 0 15px #ffa425}
      .custom-site-button-resize{display:none;position:absolute;right:-8px;bottom:-8px;z-index:3;place-items:center;width:22px;height:22px;border:2px solid #fff;border-radius:50%;background:${state.accent};color:#fff;font:700 15px/1 Arial;box-shadow:0 2px 8px #2b1b1670;cursor:nwse-resize}
      body.free-placement-mode .custom-site-button-resize{display:grid}
      .custom-site-button:focus-visible{outline:3px solid ${state.accent};outline-offset:3px}
      @media(max-width:600px){.custom-site-actions{gap:10px}.custom-site-button{max-width:100%;font-size:13px}}
      @media(prefers-reduced-motion:reduce){.custom-site-button{transition:none}}
    `;
    doc.head.append(style);
    for (const button of state.customSiteButtons || []) {
      const block = state.blocks.find(item => item.id === button.blockId && item.visible);
      const section = block ? sections[visibleBlocks.indexOf(block)] : null;
      if (!section) continue;
      let container = section.querySelector('.custom-site-actions');
      if (!container) {
        container = doc.createElement('div');
        container.className = 'custom-site-actions';
        section.append(container);
      }
      const link = doc.createElement('a');
      link.className = 'custom-site-button';
      link.href = safeUrl(button.url) || '#';
      link.dataset.customSiteButton = button.id;
      link.dataset.indicator = button.indicator === 'light' ? 'light' : 'plus';
      link.dataset.customScale = String(Math.max(.65, Math.min(1.8, Number(button.scale) || 1)));
      link.style.scale = link.dataset.customScale;
      const copy = doc.createElement('span');
      copy.className = 'custom-site-button-copy';
      const title = doc.createElement('strong');
      title.textContent = button.label;
      const subtitle = doc.createElement('small');
      subtitle.textContent = button.subtitle || 'Découvrir';
      copy.append(title, subtitle);
      const indicator = doc.createElement('span');
      indicator.className = 'custom-site-button-indicator';
      indicator.setAttribute('aria-hidden', 'true');
      indicator.textContent = button.indicator === 'light' ? '' : '+';
      const resize = doc.createElement('span');
      resize.className = 'custom-site-button-resize';
      resize.textContent = '↘';
      resize.setAttribute('aria-hidden', 'true');
      link.append(copy, indicator, resize);
      if (/^https?:/i.test(link.href)) {
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
      }
      link.dataset.freePlacementBlock = block.id;
      link.dataset.freePlacementKey = `bouton-custom-${button.id}`;
      const placement = block.freePlacements?.[link.dataset.freePlacementKey] || { x: 0, y: 0 };
      link.dataset.freePlacementX = String(placement.x || 0);
      link.dataset.freePlacementY = String(placement.y || 0);
      container.append(link);
    }
    const apply = doc.createElement('script');
    apply.textContent = `requestAnimationFrame(()=>window.applyFreeBlockPlacements?.());`;
    doc.body.append(apply);
    return '<!doctype html>\n' + doc.documentElement.outerHTML;
  };

  const previousRender = render;
  render = function () {
    previousRender();
    if (tab !== 'buttons' && tab !== 'blocks') return;
    state.customSiteButtons ||= [];
    const editor = $('#editor');

    if (tab === 'blocks') {
      const intro = state.blocks.find(block => block.type === 'intro');
      if (intro && !editor.querySelector('.home-photo-settings')) {
        const photoPanel = document.createElement('section');
        photoPanel.className = 'home-photo-settings';
        const heading = document.createElement('h2');
        heading.textContent = 'Photo de l’accueil';
        const note = document.createElement('p');
        note.className = 'hint';
        note.textContent = 'Ajoutez ou remplacez la photo de fond affichée derrière le titre de votre accueil.';
        const picker = document.createElement('input');
        picker.type = 'file';
        picker.accept = 'image/png,image/jpeg,image/webp';
        picker.hidden = true;
        const choose = document.createElement('button');
        choose.type = 'button';
        choose.textContent = intro.visible ? (state.heroImage ? '📷 Remplacer la photo' : '📷 Ajouter une photo') : 'Afficher Accueil pour ajouter une photo';
        choose.disabled = !intro.visible;
        choose.onclick = () => picker.click();
        picker.onchange = async () => {
          const file = picker.files?.[0];
          if (!file) return;
          if (!['image/png','image/jpeg','image/webp'].includes(file.type) || file.size > 25000000) {
            $('#status').textContent = 'Choisissez une image PNG, JPEG ou WebP de 25 Mo maximum.';
            return;
          }
          choose.disabled = true;
          $('#status').textContent = 'Préparation de la photo…';
          try {
            state.heroImage = (await optimiseLibraryPhoto(file)).src;
            update();
            render();
            $('#status').textContent = 'Photo d’accueil enregistrée.';
          } catch (error) {
            $('#status').textContent = error.message || 'La photo n’a pas pu être ajoutée.';
            choose.disabled = false;
          }
        };
        photoPanel.append(heading, note, choose, picker);
        if (state.heroImage) {
          const preview = document.createElement('img');
          preview.src = state.heroImage;
          preview.alt = 'Aperçu de la photo d’accueil';
          preview.className = 'home-photo-preview';
          photoPanel.append(preview);
          const remove = document.createElement('button');
          remove.type = 'button';
          remove.textContent = 'Retirer la photo';
          remove.onclick = () => { state.heroImage = ''; update(); render(); };
          photoPanel.append(remove);
        }
        const blockCards = [...editor.querySelectorAll('.block')];
        const introCard = blockCards[state.blocks.indexOf(intro)];
        const introDetails = introCard?.querySelector('details');
        if (introDetails) introDetails.append(photoPanel);
        else editor.prepend(photoPanel);
      }
    }

    const panel = document.createElement('section');
    panel.className = 'custom-site-buttons-panel';
    const heading = document.createElement('h2');
    heading.textContent = 'Créer et modifier les boutons';
    const help = document.createElement('p');
    help.className = 'hint';
    help.textContent = 'Modifiez le texte, le lien et l’icône de chaque bouton. Choisissez son bloc, puis déplacez-le ou redimensionnez-le dans l’aperçu avec « Placer images et boutons ». Le panneau est aussi disponible dans Contenu.';
    panel.append(heading, help);

    const form = document.createElement('form');
    form.className = 'custom-site-button-form';
    const labelField = document.createElement('label');
    labelField.textContent = 'Texte du bouton';
    const labelInput = document.createElement('input');
    labelInput.type = 'text';
    labelInput.maxLength = 80;
    labelInput.placeholder = 'Ex. Demander un devis';
    labelInput.required = true;
    labelField.append(labelInput);
    const urlField = document.createElement('label');
    urlField.textContent = 'Lien du bouton';
    const urlInput = document.createElement('input');
    urlInput.type = 'text';
    urlInput.inputMode = 'url';
    urlInput.placeholder = 'https://… ou lien de rubrique (#devis)';
    urlInput.required = true;
    urlField.append(urlInput);
    const subtitleField = document.createElement('label');
    subtitleField.textContent = 'Petite ligne sous le texte (facultatif)';
    const subtitleInput = document.createElement('input');
    subtitleInput.type = 'text';
    subtitleInput.maxLength = 100;
    subtitleInput.placeholder = 'Ex. Rénovation et aménagement';
    subtitleField.append(subtitleInput);
    const blockField = document.createElement('label');
    blockField.textContent = 'Afficher dans le bloc';
    const blockSelect = document.createElement('select');
    const availableBlocks = state.blocks.filter(block => block.visible);
    availableBlocks.forEach(block => {
      const option = document.createElement('option');
      option.value = block.id;
      option.textContent = block.menuLabel || block.title?.replace(/\s+/g, ' ').slice(0, 48) || 'Bloc du site';
      blockSelect.append(option);
    });
    blockField.append(blockSelect);
    const indicatorField = document.createElement('label');
    indicatorField.textContent = 'Icône du bouton';
    const indicatorSelect = document.createElement('select');
    indicatorSelect.innerHTML = '<option value="plus">Plus (+)</option><option value="light">Petite lumière</option>';
    indicatorField.append(indicatorSelect);
    const add = document.createElement('button');
    add.type = 'submit';
    add.className = 'custom-site-button-add';
    add.textContent = '+ Ajouter le bouton';
    add.disabled = !availableBlocks.length || state.customSiteButtons.length >= 30;
    form.append(labelField, urlField, subtitleField, blockField, indicatorField, add);
    form.onsubmit = event => {
      event.preventDefault();
      const url = safeUrl(urlInput.value);
      if (!url) {
        $('#status').textContent = 'Saisissez une adresse https://, http://, mailto:, tel: ou un lien interne commençant par #.';
        return;
      }
      state.customSiteButtons.push({ id: crypto.randomUUID(), blockId: blockSelect.value, label: labelInput.value.trim(), subtitle: subtitleInput.value.trim(), scale: 1, indicator: indicatorSelect.value, url });
      update();
      render();
    };
    panel.append(form);

    const list = document.createElement('div');
    list.className = 'custom-site-button-list';
    state.customSiteButtons.forEach((button, index) => {
      const row = document.createElement('article');
      row.className = 'custom-site-button-row';
      const copy = document.createElement('div');
      const title = document.createElement('strong');
      title.textContent = button.label;
      const detail = document.createElement('small');
      const block = state.blocks.find(item => item.id === button.blockId);
      detail.textContent = (block?.menuLabel || block?.title?.replace(/\s+/g, ' ') || 'Bloc masqué') + ' · ' + button.url;
      copy.append(title, detail);
      const edit = document.createElement('details');
      edit.className = 'custom-site-button-edit';
      const editSummary = document.createElement('summary');
      editSummary.textContent = 'Modifier';
      edit.append(editSummary);
      const addEditField = (caption, type, value, onChange) => {
        const label = document.createElement('label');
        label.textContent = caption;
        const input = document.createElement(type === 'select' ? 'select' : 'input');
        if (type !== 'select') input.type = type;
        if (type === 'select' && caption === 'Icône') input.innerHTML = '<option value="plus">Plus (+)</option><option value="light">Petite lumière</option>';
        if (type === 'select' && caption === 'Bloc') {
          state.blocks.filter(item => item.visible).forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = item.menuLabel || item.title?.replace(/\s+/g, ' ').slice(0, 48) || 'Bloc du site';
            input.append(option);
          });
          if (!state.blocks.some(item => item.id === value && item.visible)) {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = 'Bloc masqué';
            input.append(option);
          }
        }
        input.value = value;
        input.addEventListener('change', () => onChange(input.value));
        label.append(input);
        edit.append(label);
      };
      addEditField('Texte', 'text', button.label, value => { if (value.trim()) { button.label = value.trim().slice(0, 80); title.textContent = button.label; update(); } });
      addEditField('Lien', 'url', button.url, value => {
        const url = safeUrl(value);
        if (!url) { $('#status').textContent = 'Saisissez une adresse valide pour ce bouton.'; return; }
        button.url = url;
        detail.textContent = (state.blocks.find(item => item.id === button.blockId)?.menuLabel || state.blocks.find(item => item.id === button.blockId)?.title?.replace(/\s+/g, ' ') || 'Bloc masqué') + ' · ' + url;
        update();
      });
      addEditField('Petite ligne', 'text', button.subtitle || '', value => { button.subtitle = value.trim().slice(0, 100); update(); });
      addEditField('Bloc', 'select', button.blockId, value => {
        button.blockId = value;
        const destination = state.blocks.find(item => item.id === value);
        detail.textContent = (destination?.menuLabel || destination?.title?.replace(/\s+/g, ' ') || 'Bloc masqué') + ' · ' + button.url;
        update();
      });
      addEditField('Icône', 'select', button.indicator === 'light' ? 'light' : 'plus', value => { button.indicator = value === 'light' ? 'light' : 'plus'; update(); });
      const sizeLabel = document.createElement('label');
      sizeLabel.className = 'custom-site-button-size';
      const sizeText = document.createElement('small');
      const size = document.createElement('input');
      size.type = 'range';
      size.min = '65';
      size.max = '180';
      size.value = String(Math.round((button.scale || 1) * 100));
      sizeText.textContent = 'Taille : ' + size.value + ' %';
      size.oninput = () => {
        button.scale = Number(size.value) / 100;
        sizeText.textContent = 'Taille : ' + size.value + ' %';
        const previewButton = previewFrame.contentDocument?.querySelector('[data-custom-site-button="' + CSS.escape(button.id) + '"]');
        if (previewButton) previewButton.style.scale = String(button.scale);
        update();
      };
      sizeLabel.append(sizeText, size);
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'custom-site-button-remove';
      remove.textContent = 'Supprimer';
      remove.setAttribute('aria-label', 'Supprimer le bouton ' + button.label);
      remove.onclick = () => { state.customSiteButtons.splice(index, 1); update(); render(); };
      row.append(copy, edit, sizeLabel, remove);
      list.append(row);
    });
    if (state.customSiteButtons.length) panel.append(list);
    const style = document.createElement('style');
    style.textContent = `
      .custom-site-buttons-panel{margin-top:24px;padding:18px;border:1px solid #e5caba;border-radius:16px;background:#fffaf6}
      .home-photo-settings{margin:4px 0 18px;padding:16px;border:1px solid #e5caba;border-radius:16px;background:#fffaf6}.home-photo-settings h2{margin:0 0 6px;font-size:19px}.home-photo-settings .hint{margin:0 0 10px}.home-photo-preview{display:block;width:min(100%,360px);max-height:150px;object-fit:cover;margin:12px 0;border-radius:10px;border:1px solid #e5caba}
      .custom-site-buttons-panel h2{margin:0 0 8px;font-size:20px}
      .custom-site-buttons-panel .hint{margin:0 0 14px}
      .custom-site-button-form{display:grid;gap:12px}
      .custom-site-button-form label{display:grid;gap:5px;font-size:13px;font-weight:600}
      .custom-site-button-form input,.custom-site-button-form select{width:100%;min-height:42px;padding:9px 11px;border:1px solid #e5caba;border-radius:9px;background:#fff;color:#38281f;font:14px Arial}
      .custom-site-button-add{min-height:44px;border:0;border-radius:999px;background:linear-gradient(145deg,#fff,#f2e8df);color:#492e20;box-shadow:0 6px 15px #4b2e1c1c,inset 0 1px 1px #fff;font-weight:700}
      .custom-site-button-add:disabled{opacity:.55}
      .custom-site-button-list{display:grid;gap:8px;margin-top:14px}
      .custom-site-button-row{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;padding:10px 12px;border:1px solid #ead6c9;border-radius:12px;background:#fff;box-shadow:0 5px 12px #54351a12}.custom-site-button-row>div:first-child{flex:1 1 150px;min-width:0}
      .custom-site-button-edit{flex:1 1 180px;min-width:135px}.custom-site-button-edit>summary{cursor:pointer;color:#8c412b;font-size:12px;font-weight:700}.custom-site-button-edit[open]{display:grid;gap:8px}.custom-site-button-edit label{display:grid;gap:3px;color:#765f51;font-size:11px}.custom-site-button-edit input,.custom-site-button-edit select{width:100%;min-width:0;min-height:34px;padding:6px 8px;border:1px solid #e5caba;border-radius:7px;background:#fff;font-size:12px}
      .custom-site-button-size{display:grid;flex:0 1 115px;gap:3px;color:#765f51;font-size:11px}.custom-site-button-size input{width:100%;accent-color:#a74729}
      .custom-site-button-row strong,.custom-site-button-row small{display:block;overflow-wrap:anywhere}
      .custom-site-button-row small{margin-top:3px;color:#765f51;font-size:11px}
      .custom-site-button-remove{flex:0 0 auto;min-height:36px;padding:7px 11px;border:1px solid #e5caba;border-radius:999px;background:#fffaf6;color:#783e2c;font-weight:600}
      @media(max-width:600px){.custom-site-buttons-panel{padding:14px}.custom-site-button-row{align-items:flex-start}}
    `;
    editor.append(style, panel);
  };

  const previousPlacementRefresh = refreshPreviewWithoutBlink;
  refreshPreviewWithoutBlink = function () {
    previousPlacementRefresh();
    previewFrame.contentWindow?.applyFreeBlockPlacements?.();
  };

  render();
  update();
})();
