/* HopClic — confort pour les novices + correctifs d'affichage.
   Ce fichier ne modifie aucune donnée du site : il affiche/masque des éléments et reformule quelques libellés.
   Partout : lisibilité de la rubrique sélectionnée, logo de secours.
   Mode client (?mode=client) : libellés plus simples, rubriques secondaires repliées, réglages avancés masqués. */
(() => {
  'use strict';
  const CLIENT = new URLSearchParams(location.search).get('mode') === 'client';
  const $ = (s, r = document) => r.querySelector(s);
  const safeGet = k => { try { return localStorage.getItem(k); } catch { return null; } };
  const safeSet = (k, v) => { try { localStorage.setItem(k, v); } catch { /* stockage indisponible */ } };

  /* ---------- Styles ---------- */
  const style = document.createElement('style');
  style.id = 'novice-simplify-style';
  style.textContent = `
html body .workspace>aside #editor button.content-choice.content-choice:is(.is-current,[aria-pressed=true]){background:#99501f!important;border-color:#99501f!important;color:#fff!important}
html body .workspace>aside #editor button.content-choice.content-choice:is(.is-current,[aria-pressed=true]) :is(strong,span){color:#fff!important}
html body .workspace>aside #editor button.content-choice.content-choice:is(.is-current,[aria-pressed=true]) small{color:#f7e4d2!important}
.hopclic-text-logo{font:800 24px Arial,sans-serif;color:#472719;letter-spacing:-.02em}
#editor .content-choice.novice-extra-hidden{display:none!important}
.novice-more{display:block;width:100%;min-height:44px;margin:10px 0 0;padding:10px 14px;border:1.5px dashed #99501f;border-radius:14px;background:transparent;color:#6f3a14;font:700 14px Arial,sans-serif;cursor:pointer}
.novice-more:hover{background:#fff0dc}
.novice-mode{display:block;margin:8px 0 0;min-height:44px;padding:8px 0;border:0;background:none;color:#6f3a14;font:600 14px Arial,sans-serif;text-decoration:underline;cursor:pointer;text-align:left}
.novice-more:focus-visible,.novice-mode:focus-visible{outline:3px solid #f3c97b;outline-offset:3px}
body.novice-simple #editor article.block .novice-adv{display:none!important}
`;
  (document.body || document.documentElement).appendChild(style);

  /* ---------- Logo de secours (image absente ou illisible) ---------- */
  document.querySelectorAll('img.hopclic-logo').forEach(img => {
    const swap = () => {
      if (!img.isConnected) return;
      const t = document.createElement('span');
      t.className = 'hopclic-text-logo';
      t.textContent = 'HopClic';
      t.setAttribute('role', 'img');
      t.setAttribute('aria-label', 'HopClic — Votre site pro, en quelques clics.');
      img.replaceWith(t);
    };
    if (img.complete && img.naturalWidth === 0) swap();
    else img.addEventListener('error', swap, { once: true });
  });

  if (!CLIENT) return;

  /* ---------- Mode client : libellés plus simples ---------- */
  document.body.classList.toggle('novice-simple', safeGet('hopclic-novice-advanced') !== '1');

  const setText = (el, txt, title) => {
    if (!el) return;
    if (el.textContent.trim() !== txt) el.textContent = txt;
    if (title) el.title = title;
  };
  setText($('#backup'), 'Sauvegarder', 'Télécharger une sauvegarde de mon travail, à garder en lieu sûr');
  setText($('#export'), 'Télécharger mon site', 'Télécharger le site terminé (fichier HTML)');
  const imp = $('.importbutton');
  if (imp) {
    const tn = [...imp.childNodes].find(n => n.nodeType === 3 && n.nodeValue.trim());
    if (tn) tn.nodeValue = 'Restaurer';
    imp.title = 'Reprendre une sauvegarde téléchargée avec « Sauvegarder »';
  }

  /* ---------- Interrupteur « réglages avancés » ---------- */
  const intro = $('.workspace>aside .intro');
  const modeBtn = document.createElement('button');
  modeBtn.type = 'button';
  modeBtn.className = 'novice-mode';
  const paintMode = () => {
    const advanced = !document.body.classList.contains('novice-simple');
    modeBtn.textContent = advanced ? 'Masquer les réglages avancés' : 'Afficher les réglages avancés';
    modeBtn.title = 'Tailles, liens et dispositions des photos, vidéos et textes';
  };
  modeBtn.onclick = () => {
    document.body.classList.toggle('novice-simple');
    safeSet('hopclic-novice-advanced', document.body.classList.contains('novice-simple') ? '0' : '1');
    paintMode();
  };
  if (intro) intro.appendChild(modeBtn);
  paintMode();

  /* ---------- Rubriques : l'essentiel d'abord ---------- */
  const ESSENTIAL = new Set(['intro', 'services', 'gallery', 'zone', 'contact']);
  let showMore = false;
  const more = document.createElement('button');
  more.type = 'button';
  more.className = 'novice-more';
  more.onclick = () => { showMore = !showMore; apply(); };

  function apply() {
    const ed = $('#editor');
    if (!ed) return;

    ed.querySelectorAll('.content-choice').forEach(c => {
      const s = c.querySelector('small');
      if (s) {
        const t = s.textContent.trim();
        if (t === 'Masqué · cliquer pour afficher') s.textContent = 'Cliquer pour ajouter à mon site';
        else if (t === 'Visible sur le site') s.textContent = 'Sur mon site';
      }
      const a = c.getAttribute('aria-label');
      if (a && a.includes('Masqué ; cliquez pour afficher et modifier')) {
        c.setAttribute('aria-label', a.replace('Masqué ; cliquez pour afficher et modifier', 'pas encore sur le site ; cliquez pour l’ajouter et la modifier'));
      }
    });

    ed.querySelectorAll('.content-empty').forEach(p => {
      if (p.textContent.includes('rubriques vertes')) p.textContent = p.textContent.replace('Les rubriques vertes sont visibles sur votre site.', 'Les rubriques marquées « Sur mon site » sont déjà affichées.');
    });

    const extras = [...ed.querySelectorAll('.content-choice[data-id]')].filter(c => !ESSENTIAL.has(c.dataset.id));
    let foldable = 0;
    extras.forEach(c => {
      const inUse = c.classList.contains('is-visible') || c.classList.contains('is-current') || c.getAttribute('aria-pressed') === 'true';
      c.classList.toggle('novice-extra-hidden', !showMore && !inUse);
      if (!inUse) foldable++;
    });
    const menu = ed.querySelector('.content-menu');
    if (menu) {
      if (!foldable) more.remove();
      else {
        const label = showMore ? 'Voir moins de rubriques' : 'Plus de rubriques (' + foldable + ')';
        if (more.textContent !== label) more.textContent = label;
        more.setAttribute('aria-expanded', String(showMore));
        if (more.previousElementSibling !== menu) menu.insertAdjacentElement('afterend', more);
      }
    }

    ed.querySelectorAll('article.block').forEach(block => {
      block.querySelectorAll('input[type=range], input[type=url], select').forEach(inp => {
        const label = inp.closest('label');
        if (!label || label === block || label.classList.contains('novice-adv')) return;
        const advanced = inp.type === 'range' || inp.type === 'url' || /^(Disposition|Composition|Mode de présentation)/i.test(label.textContent.trim());
        if (advanced) label.classList.add('novice-adv');
      });
    });
  }

  let queued = false, runs = 0, windowStart = Date.now();
  const schedule = () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      if (Date.now() - windowStart > 5000) { windowStart = Date.now(); runs = 0; }
      if (++runs > 300) return; // garde-fou : jamais de boucle infinie avec un autre script
      apply();
    });
  };
  const editor = $('#editor');
  if (editor) new MutationObserver(schedule).observe(editor, { childList: true, subtree: true });
  apply();
})();
