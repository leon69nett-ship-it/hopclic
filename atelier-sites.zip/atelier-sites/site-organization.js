// Réglages des blocs regroupés dans Design > Organisation de votre site.
(() => {
  const widths = [
    ['small', 'Petit', '760px'],
    ['medium', 'Moyen', '960px'],
    ['large', 'Grand', '1200px'],
    ['full', 'Plein écran', '100%']
  ];
  const backgrounds = [
    ['#ffffff', 'Blanc'], ['#fffaf5', 'Ivoire'], ['#f1efed', 'Gris clair'],
    ['#efe3d5', 'Sable'], ['#e5e9ef', 'Gris bleuté'], ['#d8d8d8', 'Gris']
  ];
  const frameColors = [
    ['#ffffff', 'Blanc'], ['#dedede', 'Gris clair'], ['#aaaaaa', 'Gris'],
    ['#777777', 'Gris foncé'], ['#333333', 'Anthracite'], ['#111111', 'Noir']
  ];
  const frameSizes = [['none', 'Sans cadre'], ['small', 'Petit'], ['large', 'Grand']];
  const shadows = [['none', 'Sans ombre'], ['soft', 'Douce'], ['strong', 'Marquée']];
  const isHex = value => /^#[0-9a-f]{6}$/i.test(value || '');
  const valid = (value, choices, fallback) => choices.some(([key]) => key === value) ? value : fallback;

  const previousValidate = validate;
  validate = function (saved) {
    const result = previousValidate(saved);
    result.organizationWidth = valid(saved?.organizationWidth, widths, 'large');
    result.organizationBackground = isHex(saved?.organizationBackground) ? saved.organizationBackground : (isHex(saved?.blockBackground) ? saved.blockBackground : '#ffffff');
    result.organizationFrame = valid(saved?.organizationFrame, frameSizes, 'none');
    result.organizationFrameColor = isHex(saved?.organizationFrameColor) ? saved.organizationFrameColor : (isHex(saved?.borderColor) ? saved.borderColor : '#dedede');
    result.organizationShadow = valid(saved?.organizationShadow, shadows, 'none');
    return result;
  };
  state.organizationWidth = valid(state.organizationWidth, widths, 'large');
  state.organizationBackground = isHex(state.organizationBackground) ? state.organizationBackground : (isHex(state.blockBackground) ? state.blockBackground : '#ffffff');
  state.organizationFrame = valid(state.organizationFrame, frameSizes, 'none');
  state.organizationFrameColor = isHex(state.organizationFrameColor) ? state.organizationFrameColor : (isHex(state.borderColor) ? state.borderColor : '#dedede');
  state.organizationShadow = valid(state.organizationShadow, shadows, 'none');

  const group = (panel, title, choices, current, callback, color = false) => {
    const section = document.createElement('div');
    section.className = 'site-org-group';
    const heading = document.createElement('strong');
    heading.textContent = title;
    const options = document.createElement('div');
    options.className = color ? 'site-org-options site-org-colors' : 'site-org-options';
    for (const [value, label, extra] of choices) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = color ? 'site-org-swatch' : 'site-org-option';
      button.setAttribute('aria-label', label);
      button.title = label;
      button.setAttribute('aria-pressed', String(value === current));
      if (color) button.style.setProperty('--swatch', value);
      else button.textContent = label;
      button.addEventListener('click', () => {
        callback(value);
        for (const option of options.querySelectorAll('button')) option.setAttribute('aria-pressed', String(option === button));
      });
      options.append(button);
    }
    section.append(heading, options);
    panel.append(section);
    return section;
  };

  const ensureOrganizationControls = () => {
    const panel = document.querySelector('#editor .block-presentation-panel');
    if (tab !== 'design' || !panel || panel.querySelector('.site-org-settings')) return;
    const settings = document.createElement('div');
    settings.className = 'site-org-settings';
    const title = document.createElement('h3');
    title.textContent = 'Apparence des blocs';
    const hint = document.createElement('p');
    hint.textContent = 'Ces réglages s’appliquent aux blocs principaux du site.';
    settings.append(title, hint);
    group(settings, 'Largeur du site', widths.map(([id, name]) => [id, name]), state.siteWidth === 'full' ? 'full' : state.organizationWidth, value => {
      state.organizationWidth = value;
      state.siteWidth = value === 'full' ? 'full' : 'centered';
      update();
    });
    const bgGroup = group(settings, 'Couleur de fond', backgrounds, state.organizationBackground, value => { state.organizationBackground = value; update(); }, true);
    const customBackground = document.createElement('label');
    customBackground.className = 'site-org-custom-color';
    customBackground.textContent = 'Autre couleur de fond';
    const bgInput = document.createElement('input');
    bgInput.type = 'color';
    bgInput.value = state.organizationBackground;
    bgInput.setAttribute('aria-label', 'Choisir une autre couleur de fond');
    bgInput.addEventListener('input', () => {
      state.organizationBackground = bgInput.value;
      bgGroup.querySelectorAll('button').forEach(button => button.setAttribute('aria-pressed', 'false'));
      update();
    });
    customBackground.append(bgInput);
    settings.append(customBackground);
    group(settings, 'Cadre autour du bloc', frameSizes, state.organizationFrame, value => { state.organizationFrame = value; update(); });
    const borderGroup = group(settings, 'Couleur du cadre', frameColors, state.organizationFrameColor, value => { state.organizationFrameColor = value; update(); }, true);
    const customBorder = document.createElement('label');
    customBorder.className = 'site-org-custom-color';
    customBorder.textContent = 'Autre couleur de cadre';
    const borderInput = document.createElement('input');
    borderInput.type = 'color';
    borderInput.value = state.organizationFrameColor;
    borderInput.setAttribute('aria-label', 'Choisir une autre couleur de cadre');
    borderInput.addEventListener('input', () => {
      state.organizationFrameColor = borderInput.value;
      borderGroup.querySelectorAll('button').forEach(button => button.setAttribute('aria-pressed', 'false'));
      update();
    });
    customBorder.append(borderInput);
    settings.append(customBorder);
    group(settings, 'Ombre des blocs', shadows, state.organizationShadow, value => { state.organizationShadow = value; update(); });
    panel.append(settings);
  };

  const previousRender = render;
  render = function () {
    previousRender();
    ensureOrganizationControls();
    // Les anciens réglages séparés sont désormais regroupés dans ce panneau.
    const editor = document.querySelector('#editor');
    for (const label of editor?.querySelectorAll('label') || []) {
      if (label.firstChild?.textContent?.trim() === 'Largeur du site') {
        const note = label.nextElementSibling;
        label.remove();
        note?.remove();
      }
    }
    for (const heading of editor?.querySelectorAll('h3') || []) {
      if (heading.textContent.trim() === 'Relief et ombres') heading.parentElement.remove();
    }
  };

  const editor = document.querySelector('#editor');
  if (editor && 'MutationObserver' in window) {
    const panelObserver = new MutationObserver(() => ensureOrganizationControls());
    panelObserver.observe(editor, { childList: true, subtree: true });
  }
  document.querySelector('#tabs')?.addEventListener('click', () => setTimeout(ensureOrganizationControls, 0));
  setTimeout(ensureOrganizationControls, 0);

  const previousPage = page;
  page = function () {
    const doc = parseRenderedPage(previousPage());
    doc.body.dataset.organizationWidth = state.organizationWidth;
    const panorama = state.blockPresentation === 'panorama';
    const sideNavigation = state.blockPresentation === 'left-rail' || state.blockPresentation === 'right-rail';
    const fullWidth = panorama || sideNavigation || state.organizationWidth === 'full' || state.siteWidth === 'full';
    const width = widths.find(([id]) => id === state.organizationWidth)?.[2] || '1200px';
    const frame = state.organizationFrame === 'none' ? '0' : state.organizationFrame === 'large' ? '3px' : '1px';
    const shadow = state.organizationShadow === 'none' ? 'none' : state.organizationShadow === 'strong' ? '0 12px 34px #24170f30' : '0 5px 18px #24170f14';
    doc.getElementById('site-organization-settings')?.remove();
    const style = doc.createElement('style');
    style.id = 'site-organization-settings';
    style.textContent = `
      body{width:${fullWidth?'100%':'calc(100% - 64px)'}!important;max-width:${fullWidth?'none':'1200px'}!important;margin:${sideNavigation?'0':'0 auto'}!important;box-shadow:${state.organizationWidth==='full'||state.siteWidth==='full'||sideNavigation?'none':'0 0 32px #00000012'}!important}
      body>section:not(.business-card):not(.scroll-media-transition){box-sizing:border-box;width:${fullWidth?'100%':`min(calc(100% - 36px),${width})`}!important;max-width:${panorama||sideNavigation||fullWidth?'none':width}!important;margin-inline:${sideNavigation?'0':'auto'}!important;background:${state.organizationBackground}!important;border:${frame} solid ${state.organizationFrameColor}!important;border-radius:${state.organizationFrame==='large'?'18px':'8px'}!important;box-shadow:${shadow}!important}
      body>section.business-card{max-width:min(calc(100% - 36px),${width})!important;margin-inline:auto!important}
      @media(max-width:760px){body>section:not(.business-card):not(.scroll-media-transition){width:${fullWidth?'100%':'calc(100% - 24px)'}!important;max-width:100%!important}body>section.business-card{max-width:calc(100% - 24px)!important}}
    `;
    doc.head.append(style);
    const hero = doc.querySelector('body>section.hero');
    if (hero) {
      hero.style.setProperty('width', fullWidth ? '100%' : `min(calc(100% - 36px),${width})`, 'important');
      hero.style.setProperty('max-width', fullWidth ? 'none' : width, 'important');
      hero.style.setProperty('margin-inline', sideNavigation ? '0' : 'auto', 'important');
      hero.style.setProperty('background', state.organizationBackground, 'important');
      hero.style.setProperty('border', `${frame} solid ${state.organizationFrameColor}`, 'important');
      hero.style.setProperty('border-radius', state.organizationFrame === 'large' ? '18px' : '8px', 'important');
      hero.style.setProperty('box-shadow', shadow, 'important');
    }
    return serializeRenderedPage(doc);
  };

  const css = document.createElement('style');
  css.textContent = `
    #editor .site-org-settings{margin:20px 0 4px;padding-top:18px;border-top:1px solid #e5caba}
    #editor .site-org-settings h3{margin:0 0 5px;font-size:17px;color:#38281f}
    #editor .site-org-settings>p{margin:0 0 18px;color:#604b3f;font-size:12px;line-height:1.5}
    #editor .site-org-group{margin:0 0 17px}
    #editor .site-org-group>strong{display:block;margin-bottom:8px;font-size:13px;color:#38281f}
    #editor .site-org-options{display:flex;flex-wrap:wrap;gap:7px}
    #editor .site-org-option{min-height:34px;padding:7px 11px;border:1px solid #b88e70;border-radius:8px;background:#fff;color:#38281f;font-size:12px;cursor:pointer}
    #editor .site-org-option[aria-pressed=true]{border:2px solid #8e3d25;background:#fff1e3;font-weight:700}
    #editor .site-org-swatch{width:34px;height:32px;padding:4px;border:1px solid #b88e70;border-radius:6px;background:#fff;cursor:pointer}
    #editor .site-org-swatch::before{content:'';display:block;width:100%;height:100%;border-radius:2px;background:var(--swatch)}
    #editor .site-org-swatch[aria-pressed=true]{outline:2px solid #8e3d25;outline-offset:2px}
    #editor .site-org-custom-color{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:-8px 0 17px;font-size:12px;color:#604b3f}
    #editor .site-org-custom-color input{width:48px;height:34px;padding:2px;border:1px solid #b88e70;border-radius:6px;background:#fff;cursor:pointer}
  `;
  document.head.append(css);
})();
