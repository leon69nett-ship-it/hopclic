const validateBeforeTextOnly=validate;
validate=function(saved){const result=validateBeforeTextOnly(saved);result.blocks.forEach((block,index)=>{for(const key of ['serviceTextOnly','detailsTextOnly'])block[key]=Array.isArray(saved.blocks[index]?.[key])?saved.blocks[index][key].slice(0,100).map(value=>value===true):[]});return result};
function chooseServiceTextOnly(block,index,details){
  const key=details?'detailsTextOnly':'serviceTextOnly';block[key]??=[];block[key][index]=true;
  selectEditorBlock(block.id);serviceDetailsEditingKey=details?block.id+':'+index:null;render();openServiceItem(block.id,index);update();
  const fields=document.querySelector('#editor .service-item-fields');
  const input=details?[...fields.querySelectorAll('label')].find(label=>label.textContent.includes('Contenu de la fiche explicative'))?.querySelector('textarea'):fields.querySelector('input');
  input?.scrollIntoView({behavior:'instant',block:'center'});input?.focus({preventScroll:true});
}
const renderServiceBeforeTextOnly=renderServiceItems;
renderServiceItems=function(card,block){
  renderServiceBeforeTextOnly(card,block);
  const fields=card.querySelector('.service-item-fields');if(!fields)return;
  const index=selectedServiceIndex,details=serviceDetailsEditingKey===block.id+':'+index;
  const button=document.createElement('button');button.type='button';button.textContent='Sans média';button.style.cssText='display:block;width:100%;text-align:left;padding-left:14px';button.onclick=()=>chooseServiceTextOnly(block,index,details);
  const photoLabel=[...fields.querySelectorAll('label')].find(label=>label.textContent.startsWith('Photo de la bibliothèque'));if(photoLabel)photoLabel.before(button);else fields.append(button);
  for(const choice of fields.querySelectorAll('button'))if(/Choisir une photo|Choisir une vidéo|Importer une photo|Importer une vidéo|^📷 Photo$|^🎬 Vidéo$/.test(choice.textContent))choice.addEventListener('click',()=>{const key=details?'detailsTextOnly':'serviceTextOnly';block[key]??=[];block[key][index]=false;update()});
};
const pageBeforeTextOnly=page;
page=function(){const doc=parseRenderedPage(pageBeforeTextOnly());const blocks=state.blocks.filter(block=>block.visible);const sections=[...doc.querySelectorAll('body>section:not(.business-card)')];blocks.forEach((block,index)=>{if(block.type!=='services')return;const section=doc.getElementById('rubrique-'+block.id)||sections[index];section?.querySelectorAll('.service-card').forEach((card,position)=>{if(block.serviceTextOnly?.[position])card.querySelectorAll('.service-empty-photo,.service-photo,.service-video,.service-card-video-thumb').forEach(media=>{if(!media.closest('.service-info-dialog'))media.remove()});if(block.detailsTextOnly?.[position])card.querySelector('.service-info-dialog .service-details-media')?.remove()})});return serializeRenderedPage(doc)};
const detailsShortcutsBeforeTextOnly=addDetailsMediaShortcuts;
addDetailsMediaShortcuts=function(){detailsShortcutsBeforeTextOnly();const doc=previewFrame.contentDocument;doc?.querySelectorAll('.details-media-shortcuts').forEach(actions=>{if(actions.querySelector('.details-text-only'))return;const button=doc.createElement('button');button.className='details-text-only';button.textContent='Sans média';button.style.cssText='display:block;width:100%;text-align:left;padding-left:14px';button.onclick=event=>{event.stopPropagation();const card=actions.closest('.service-card'),section=actions.closest('[data-editor-block]');const block=state.blocks.find(item=>item.id===section?.dataset.editorBlock);if(!block)return;const index=[...section.querySelectorAll('.service-card')].indexOf(card);actions.closest('dialog').close();chooseServiceTextOnly(block,index,true)};actions.append(button)})};
const pageBeforeNoMediaAlignment=page;
page=function(){
  const doc=parseRenderedPage(pageBeforeNoMediaAlignment());
  const blocks=state.blocks.filter(block=>block.visible),sections=[...doc.querySelectorAll('body>section:not(.business-card)')];
  blocks.forEach((block,index)=>{
    if(block.type!=='services')return;
    const section=doc.getElementById('rubrique-'+block.id)||sections[index];
    section?.querySelectorAll('.service-card').forEach((card,position)=>{
      if(block.serviceTextOnly?.[position])card.classList.add('service-without-media');
      if(block.detailsTextOnly?.[position])card.querySelector('.service-info-dialog')?.classList.add('details-without-media');
    });
  });
  const style=doc.createElement('style');
  style.textContent='.service-card.service-without-media{display:block!important}.service-without-media .service-copy{width:100%!important;grid-column:1/-1!important}.service-without-media .service-copy h3{margin-top:0!important}.details-without-media>h2{margin-top:0!important}';
  doc.head.append(style);return serializeRenderedPage(doc);
};
render();update();
