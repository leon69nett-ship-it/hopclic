function addPickerPCImport(dialog,kind,multiple,ids,apply){
 const list=dialog.children[1];
 const choices=document.createElement('div');choices.style.cssText='display:flex;gap:10px;flex-wrap:wrap;margin:16px 0';
 const library=document.createElement('button');library.type='button';library.textContent=kind==='photo'?'📚 Bibliothèque de photos':'📚 Bibliothèque de vidéos';library.setAttribute('aria-pressed','true');
 const libraryHeading=document.createElement('h3');libraryHeading.textContent='Choisir dans ma bibliothèque';
 library.onclick=()=>{libraryHeading.scrollIntoView({block:'nearest'});list?.querySelector('input')?.focus({preventScroll:true})};
 const input=document.createElement('input');input.type='file';input.hidden=true;input.multiple=multiple;input.accept=kind==='photo'?'image/jpeg,image/png,image/webp':'video/mp4,video/webm';
 const button=document.createElement('button');button.type='button';button.textContent=kind==='photo'?'Importer une photo depuis mon PC':'Importer une vidéo depuis mon PC';
 const status=document.createElement('p');status.setAttribute('role','status');
 button.onclick=()=>input.click();
 input.onchange=async()=>{
  const files=[...input.files];if(!files.length)return;button.disabled=true;status.textContent='Importation en cours…';
  try{
   const imported=[];
   for(const file of files){
    if(kind==='photo'){
     const photo=await optimiseLibraryPhoto(file);await cacheSitePhoto(photo.src,file.name.replace(/\.[^.]+$/,''));
     const item=state.photoLibrary.find(item=>item.src===photo.src);if(item)imported.push(item.id);
    }else{
     await importVideoFiles([file]);
     const item=state.videoLibrary[state.videoLibrary.length-1];if(item)imported.push(item.id);
    }
   }
   if(imported.length){apply(multiple?[...new Set([...ids,...imported])]:imported.slice(-1));dialog.close()}
   else status.textContent='Aucun média importé.';
  }catch(error){status.textContent=error.message||'Importation impossible.'}
  finally{button.disabled=false;input.value=''}
 };
 choices.append(library,button);dialog.insertBefore(choices,list||null);choices.after(input,status,libraryHeading);
}
