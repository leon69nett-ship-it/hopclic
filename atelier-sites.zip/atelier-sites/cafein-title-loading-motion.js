const pageBeforeCafeinTitleLoadingMotion = page;
page = function () {
  const doc = parseRenderedPage(pageBeforeCafeinTitleLoadingMotion());
  const titles = [...doc.querySelectorAll('body > section:not(.business-card) h2')];
  titles.forEach(title => title.classList.add('cafein-title-reveal'));

  const style = doc.createElement('style');
  style.id = 'cafein-title-loading-motion-style';
  style.textContent = `
    .cafein-title-reveal {
      opacity: 0;
      transform: translateY(30px);
      transition: opacity 720ms cubic-bezier(.2,.7,.25,1), transform 720ms cubic-bezier(.2,.7,.25,1);
      will-change: opacity, transform;
    }
    .cafein-title-reveal.is-visible { opacity: 1; transform: translateY(0); }
    .cafein-title-reveal::after {
      content: ""; display: block; width: 42px; height: 3px; margin-top: 13px;
      border-radius: 3px; background: var(--accent, #bd4b2b);
      transform: scaleX(0); transform-origin: left; transition: transform 620ms 160ms cubic-bezier(.2,.7,.25,1);
    }
    .cafein-title-reveal.is-visible::after { transform: scaleX(1); }
    .cafein-loading-screen {
      position: fixed; inset: 0; z-index: 99999; display: grid; place-items: center;
      padding: 24px; background: #f8f4ed; color: #38281f;
      opacity: 0; visibility: hidden; pointer-events: none; transition: opacity 360ms ease, visibility 360ms ease;
    }
    .cafein-loading-screen.is-loading { opacity: 1; visibility: visible; pointer-events: auto; }
    .cafein-loading-screen.is-done { opacity: 0; visibility: hidden; pointer-events: none; }
    .cafein-loading-card { width: min(340px, 90vw); text-align: center; }
    .cafein-loading-stage { position: relative; display: grid; place-items: center; width: min(240px, 76vw); aspect-ratio: 1; margin: 0 auto; }
    .cafein-loading-word { position: relative; z-index: 2; display: block; width: min(280px,78vw); aspect-ratio: 3 / 2; margin: 0 auto; background: #fff url("hopclic-logo-chargement.png") center / contain no-repeat; mix-blend-mode: normal; }
    .cafein-cursor-orbit { display:none; }
    .cafein-loading-screen.is-loading .cafein-loading-word { animation: cafein-word-breathe 2.8s ease-in-out infinite; }
    .cafein-loading-copy { margin: 0 auto 20px; color: #765f51; font: 13px/1.5 Arial,sans-serif; }
    .cafein-loading-track { height: 5px; overflow: hidden; border-radius: 5px; background: #eadfd3; }
    .cafein-loading-progress { width: 0; height: 100%; border-radius: inherit; background: linear-gradient(90deg,#b8492b,#e4a04c); }
    .cafein-loading-screen.is-loading .cafein-loading-progress { animation: cafein-loader-progress 1.5s cubic-bezier(.22,.65,.35,1) forwards; }
    .cafein-loading-percent { margin-top: 9px; color: #967d6c; font: 10px/1 Arial,sans-serif; letter-spacing: .12em; }
    @keyframes cafein-loader-spin { to { transform: translate(-50%,-50%) rotate(360deg); } }
    @keyframes cafein-word-breathe { 0%,100% { transform: scale(1); } 50% { transform: scale(1.035); } }
    @keyframes cafein-loader-progress { 0% { width: 0; } 78% { width: 83%; } 100% { width: 94%; } }
    .cafein-loading-screen.is-done .cafein-loading-progress { width: 100%; transition: width 220ms ease; animation: none; }
    @media (prefers-reduced-motion: reduce) {
      .cafein-title-reveal, .cafein-title-reveal::after { opacity: 1; transform: none; transition: none; animation: none; }
      .cafein-title-reveal::after { transform: scaleX(1); }
      .cafein-cursor-orbit, .cafein-loading-progress, .cafein-loading-word { animation: none; }
      .cafein-loading-progress { width: 100%; }
      .cafein-loading-screen { transition: none; }
    }
  `;
  doc.head.append(style);

  const loader = doc.createElement('div');
  loader.className = 'cafein-loading-screen';
  loader.setAttribute('role', 'status');
  loader.setAttribute('aria-live', 'polite');
  loader.innerHTML = '<div class="cafein-loading-card"><div class="cafein-loading-stage"><div class="cafein-loading-word" role="img" aria-label="HopClic, votre site pro en quelques clics"></div><div class="cafein-cursor-orbit" aria-hidden="true"></div></div><p class="cafein-loading-copy">Votre site se prépare…</p><div class="cafein-loading-track" aria-hidden="true"><div class="cafein-loading-progress"></div></div><div class="cafein-loading-percent" aria-hidden="true">LE SITE ARRIVE</div></div>';
  doc.body.prepend(loader);
  const script = doc.createElement('script');
  script.textContent = `(()=>{
    const titles=[...document.querySelectorAll('.cafein-title-reveal')];
    const reveal=title=>title.classList.add('is-visible');
    if(matchMedia('(prefers-reduced-motion: reduce)').matches||!('IntersectionObserver' in window))titles.forEach(reveal);
    else {const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){reveal(entry.target);observer.unobserve(entry.target)}}),{threshold:.16,rootMargin:'0px 0px -7% 0px'});titles.forEach(title=>observer.observe(title))}
    const screen=document.querySelector('.cafein-loading-screen');
    const hostHref=(()=>{try{return window.frameElement?.ownerDocument?.location?.href||location.href}catch{return location.href}})();
    let siteURL;try{siteURL=new URL(hostHref,location.href)}catch{siteURL=null}
    const localHost=!siteURL||['localhost','127.0.0.1','::1'].includes(siteURL.hostname);
    const draftPreview=Boolean(siteURL?.searchParams.has('draft'));
    const clientBuilder=siteURL?.searchParams.get('mode')==='client';
    const liveOnline=navigator.onLine&&window.top===window&&['http:','https:'].includes(siteURL?.protocol)&&!localHost&&!draftPreview&&!clientBuilder;
    if(!screen||!liveOnline){screen?.remove();return}
    if(document.readyState==='complete'){screen.remove();return}
    let finished=false;
    const finish=()=>{if(finished)return;finished=true;screen.classList.remove('is-loading');screen.classList.add('is-done');setTimeout(()=>screen.remove(),380)};
    screen.classList.add('is-loading');
    window.addEventListener('load',finish,{once:true});
    window.addEventListener('offline',finish,{once:true});
    setTimeout(finish,12000);
  })();`;
  doc.body.append(script);
  return serializeRenderedPage(doc);
};
render();
update();
