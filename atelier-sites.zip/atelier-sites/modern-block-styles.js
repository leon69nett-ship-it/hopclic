const renderBeforeModernBlockStyles = render;
render = function () {
  renderBeforeModernBlockStyles();
  if (tab !== 'design') return;
  const panel = document.createElement('section');
  panel.className = 'modern-block-style-settings';
  const heading = document.createElement('h2');
  heading.textContent = 'Style des blocs';
  panel.append(heading);

  const label = document.createElement('label');
  label.textContent = 'Présentation des blocs';
  const select = document.createElement('select');
  select.setAttribute('aria-label', 'Présentation des blocs');
  for (const [id, title] of [
    ['original', 'Style actuel'],
    ['soft', 'Cartes douces · relief subtil'],
    ['glass', 'Verre dépoli · transparence'],
    ['editorial', 'Cadres éditoriaux · lignes franches']
  ]) {
    const option = document.createElement('option');
    option.value = id;
    option.textContent = title;
    select.append(option);
  }
  select.value = state.blockLook || 'original';
  select.onchange = () => { state.blockLook = select.value; update(); };
  label.append(select);
  panel.append(label);

  const hint = document.createElement('p');
  hint.className = 'hint';
  hint.textContent = 'Habille les sections de votre site sans changer leur contenu. Les couleurs suivent votre palette.';
  panel.append(hint);
  const anchor = document.querySelector('[aria-label="Découpe des séparations"]')?.closest('section');
  if (anchor) anchor.before(panel);
  else document.querySelector('#editor').append(panel);
};

const pageBeforeModernBlockStyles = page;
page = function () {
  const doc = parseRenderedPage(pageBeforeModernBlockStyles());
  const mode = state.blockLook;
  if (!['soft', 'glass', 'editorial'].includes(mode)) return serializeRenderedPage(doc);
  doc.body.classList.add('block-look-' + mode);
  for (const section of doc.querySelectorAll('body>section[id^="rubrique-"],body>section#devis')) {
    section.classList.add('designer-section');
  }
  const style = doc.createElement('style');
  style.id = 'modern-block-styles';
  style.textContent = `
 body>.designer-section{margin:26px 3%!important;width:auto!important;box-sizing:border-box;overflow-wrap:break-word}
 body.block-look-soft>.designer-section{border:1px solid ${state.borderColor}!important;border-radius:28px!important;background:${state.blockBackground}!important;box-shadow:0 16px 40px #0000000d,inset 0 1px 0 #ffffff66!important;padding:clamp(28px,5vw,70px)!important}
 body.block-look-glass{background:radial-gradient(ellipse at 0% 20%,${state.accent}24,transparent 55%),radial-gradient(ellipse at 100% 75%,${state.accent}18,transparent 50%),${state.background}!important}
 body.block-look-glass>.designer-section{border:1px solid color-mix(in srgb,${state.borderColor} 74%,white)!important;border-radius:26px!important;background:color-mix(in srgb,${state.blockBackground} 58%,transparent)!important;-webkit-backdrop-filter:blur(18px) saturate(145%);backdrop-filter:blur(18px) saturate(145%);box-shadow:0 18px 55px #00000016,inset 0 1px 0 #ffffffa8!important;padding:clamp(28px,5vw,70px)!important}
 body.block-look-editorial>.designer-section{border:1px solid ${state.borderColor}!important;border-top:3px solid ${state.accent}!important;border-radius:4px!important;background:${state.blockBackground}!important;box-shadow:8px 8px 0 color-mix(in srgb,${state.accent} 12%,${state.background})!important;padding:clamp(28px,5vw,70px)!important}
 body>.designer-section h2{color:${state.textColor}!important}body>.designer-section>p{color:${state.secondaryColor}!important}
 @media(max-width:760px){body>.designer-section{margin:16px 12px!important;padding:26px 18px!important}body.block-look-soft>.designer-section,body.block-look-glass>.designer-section{border-radius:18px!important}body.block-look-editorial>.designer-section{box-shadow:4px 4px 0 ${state.borderColor}!important}}
 `;
  doc.head.append(style);
  return serializeRenderedPage(doc);
};
render();
update();
