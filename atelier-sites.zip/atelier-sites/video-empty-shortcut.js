const videoMarkupBeforeShortcut=videoBlockMarkup;
videoBlockMarkup=function(block){return videoMarkupBeforeShortcut(block).replace('Ajoutez un lien vidéo dans les réglages.','Ajouter une vidéo depuis la bibliothèque')};
function bindVideoEmptyShortcut(){
  const doc=previewFrame.contentDocument;if(!doc||doc.videoEmptyShortcutBound)return;doc.videoEmptyShortcutBound=true;
  doc.addEventListener('click',event=>{
    const target=event.target.closest('.videos-section .placeholder');if(!target)return;
    const block=state.blocks.find(item=>item.id===target.closest('[data-editor-block]')?.dataset.editorBlock);if(!block)return;
    event.preventDefault();event.stopImmediatePropagation();
    selectEditorBlock(block.id);
    openUnifiedVideoPicker([block.videoLibraryId],false,ids=>{block.videoLibraryId=ids[0]||'';update();render()});
  },true);
}
previewFrame.addEventListener('load',bindVideoEmptyShortcut);bindVideoEmptyShortcut();update();
