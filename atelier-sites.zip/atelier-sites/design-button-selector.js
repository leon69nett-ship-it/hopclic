const designButtonStyleKey = KEY + '-site-button-look';
const designButtonShapeKey = KEY + '-site-button-shape';
const designButtonShapes = [
  { id: 'angular', title: 'Angulaire', radius: '0px' },
  { id: 'rectangle', title: 'Rectangulaire', radius: '4px' },
  { id: 'rounded', title: 'Coins arrondis', radius: '8px' },
  { id: 'pill', title: 'Pilule', radius: '999px' }
];
const designButtonLooks = [
  { id: 'classic', title: 'Classique', sample: 'Découvrir' },
  { id: 'neomorphic', title: 'Néomorphe', sample: 'Découvrir' },
  { id: 'liquid', title: 'Verre liquide', sample: 'Découvrir' },
  { id: 'crystal', title: 'Cristal & or', sample: 'Découvrir' },
  { id: 'onyx', title: 'Onyx & or', sample: 'Découvrir' },
  { id: 'emerald', title: 'Émeraude & or', sample: 'Découvrir' }
];
const siteButtonLookTarget = ':is(.btn,.button,.call,.actions a,.hero a[href],.hero button,.template-hero-actions a,.meta-actions a,.habitat-hero-actions a,.contact form button,.service-info-button,.custom-site-button,.modern-action-button,.project-comparison-button,.video-result-request,.request-project-style,#devis form button[type="submit"],.quote-form button[type="submit"])';
const buttonLookPreviews = {
  classic: ['#8e3d25', '#fff', '8px', '0 3px 8px #44241940', '1px solid transparent'],
  neomorphic: ['linear-gradient(145deg,#fbfcff,#e5e8ee)', '#20242d', '999px', '4px 5px 9px #151b2930,-3px -3px 7px #fff', '1px solid #f8fafc'],
  liquid: ['linear-gradient(145deg,#262833,#080a11 70%,#25202e)', '#33251b', '999px', 'inset 0 1px 1px #ffffff75,0 5px 13px #55517f99', '1px solid #9ca1c2'],
  crystal: ['linear-gradient(145deg,#fff,#f1e8d8)', '#33251b', '13px', 'inset 0 1px 1px #fff,0 4px 8px #593c2026', '1px solid #d2a75f'],
  onyx: ['linear-gradient(145deg,#262832,#0b0c12 68%,#20212a)', '#fff8e9', '12px', 'inset 0 1px 1px #ffffff45,0 4px 0 #07080c,0 7px 10px #08090d55', '1px solid #c79b50'],
  emerald: ['linear-gradient(145deg,#38b98b 0%,#08785c 48%,#073a48 100%)', '#fff9e8', '14px', 'inset 0 2px 2px #ffffffb0,inset 0 -4px 8px #032b3770,0 0 0 2px #d4ae67,0 0 0 4px #286d59,0 5px 0 #092f31,0 8px 12px #041b1d55', '2px solid #f1d28b']
};

function selectedDesignButtonLook() {
  const saved = state.siteButtonLook;
  if (designButtonLooks.some(item => item.id === saved)) return saved;
  try {
    const value = localStorage.getItem(designButtonStyleKey);
    return designButtonLooks.some(item => item.id === value) ? value : 'classic';
  } catch { return 'classic'; }
}

function selectedDesignButtonShape() {
  const saved = state.siteButtonShape;
  if (designButtonShapes.some(item => item.id === saved)) return saved;
  try {
    const value = localStorage.getItem(designButtonShapeKey);
    if (value === 'soft') return 'rounded';
    return designButtonShapes.some(item => item.id === value) ? value : 'rounded';
  } catch { return 'rounded'; }
}

const validateBeforeSiteButtonLook = validate;
validate = function (value) {
  const result = validateBeforeSiteButtonLook(value);
  const look = value?.siteButtonLook;
  result.siteButtonLook = designButtonLooks.some(item => item.id === look) ? look : 'classic';
  const shape = value?.siteButtonShape === 'soft' ? 'rounded' : value?.siteButtonShape;
  result.siteButtonShape = designButtonShapes.some(item => item.id === shape) ? shape : 'rounded';
  result.siteButtonScale = Math.max(60, Math.min(130, Number(value?.siteButtonScale) || 100));
  return result;
};
state.siteButtonLook = selectedDesignButtonLook();
state.siteButtonShape = selectedDesignButtonShape();
state.siteButtonScale = Math.max(60, Math.min(130, Number(state.siteButtonScale) || 100));

const renderBeforeDesignButtonSelector = render;
render = function () {
  renderBeforeDesignButtonSelector();
  window.ensureBlockPresentationPanel?.();
  if (tab !== 'design' || document.querySelector('#editor .site-button-look-panel')) return;
  const panel = document.createElement('section');
  panel.className = 'site-button-look-panel';
  const heading = document.createElement('h2');
  heading.textContent = 'Boutons du site';
  const help = document.createElement('p');
  help.className = 'hint';
  help.textContent = 'Choisissez un style, puis cliquez sur une vignette. Il s’applique aux boutons du site sans changer leurs textes ni leurs liens.';
  const choices = document.createElement('div');
  choices.className = 'site-button-look-choices';
  const active = selectedDesignButtonLook();
  const activeRadius = designButtonShapes.find(item => item.id === selectedDesignButtonShape())?.radius || '8px';
  for (const look of designButtonLooks) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'site-button-look-choice look-' + look.id;
    button.setAttribute('aria-pressed', String(look.id === active));
    button.setAttribute('aria-label', 'Choisir le style ' + look.title);
    const sample = document.createElement('span');
    sample.className = 'site-button-look-sample';
    sample.innerHTML = '<span></span>';
    sample.firstElementChild.textContent = look.sample;
    const preview = look.id === 'classic'
      ? [state.accent, paletteButtonText(state.accent), '8px', '0 3px 8px #44241940', '1px solid transparent']
      : buttonLookPreviews[look.id];
    sample.style.cssText = 'display:flex;align-items:center;gap:10px;padding:9px 14px;font:bold 12px Arial;';
    sample.style.setProperty('background', preview[0], 'important');
    sample.style.setProperty('color', preview[1], 'important');
    sample.style.setProperty('-webkit-text-fill-color', preview[1], 'important');
    sample.style.setProperty('border-radius', look.id === 'classic' ? activeRadius : preview[2], 'important');
    sample.style.setProperty('box-shadow', preview[3], 'important');
    sample.style.setProperty('border', preview[4], 'important');
    for (const part of sample.children) {
      part.style.setProperty('color', preview[1], 'important');
      part.style.setProperty('-webkit-text-fill-color', preview[1], 'important');
    }
    const name = document.createElement('strong');
    name.textContent = look.title;
    button.append(sample, name);
    button.onclick = () => {
      state.siteButtonLook = look.id;
      shapeControl.hidden = look.id !== 'classic';
      try { localStorage.setItem(designButtonStyleKey, look.id); } catch {}
      update();
      render();
    };
    choices.append(button);
  }
  const shapeControl = document.createElement('div');
  shapeControl.className = 'site-button-shape-control';
  const shapeHeading = document.createElement('h3');
  shapeHeading.textContent = 'Forme du bouton classique';
  const shapeHelp = document.createElement('p');
  shapeHelp.className = 'hint';
  shapeHelp.textContent = 'La couleur reste celle du site. Ce réglage concerne uniquement le style Classique.';
  const shapeChoices = document.createElement('div');
  shapeChoices.className = 'site-button-shape-choices';
  const activeShape = selectedDesignButtonShape();
  shapeControl.hidden = active !== 'classic';
  for (const shape of designButtonShapes) {
    const choice = document.createElement('button');
    choice.type = 'button';
    choice.className = 'site-button-shape-choice';
    choice.setAttribute('aria-pressed', String(shape.id === activeShape));
    choice.setAttribute('aria-label', 'Choisir la forme ' + shape.title);
    const sample = document.createElement('span');
    sample.className = 'site-button-shape-sample';
    sample.textContent = 'Découvrir';
    sample.style.borderRadius = shape.radius;
    sample.style.background = state.accent;
    sample.style.color = paletteButtonText(state.accent);
    sample.style.border = `1px solid ${state.accent}`;
    const label = document.createElement('span');
    label.textContent = shape.title;
    choice.append(sample, label);
    choice.onclick = () => {
      state.siteButtonShape = shape.id;
      try { localStorage.setItem(designButtonShapeKey, shape.id); } catch {}
      for (const sibling of shapeChoices.querySelectorAll('button')) {
        sibling.setAttribute('aria-pressed', String(sibling === choice));
      }
      panel.querySelector('.site-button-look-choice.look-classic .site-button-look-sample')
        ?.style.setProperty('border-radius', shape.radius, 'important');
      update();
    };
    shapeChoices.append(choice);
  }
  shapeControl.append(shapeHeading, shapeHelp, shapeChoices);
  panel.append(heading, help);
  const sizeControl = document.createElement('div');
  sizeControl.className = 'site-button-size-control';
  const sizeLabel = document.createElement('label');
  sizeLabel.htmlFor = 'site-button-size';
  sizeLabel.textContent = 'Taille de tous les boutons';
  const sizeValue = document.createElement('output');
  sizeValue.htmlFor = 'site-button-size';
  sizeValue.textContent = state.siteButtonScale + ' %';
  const sizeSlider = document.createElement('input');
  sizeSlider.id = 'site-button-size';
  sizeSlider.type = 'range';
  sizeSlider.min = '60';
  sizeSlider.max = '130';
  sizeSlider.step = '5';
  sizeSlider.value = String(state.siteButtonScale);
  sizeSlider.setAttribute('aria-label', 'Taille de tous les boutons du site');
  sizeSlider.oninput = () => {
    state.siteButtonScale = Math.max(60, Math.min(130, Number(sizeSlider.value) || 100));
    sizeValue.textContent = state.siteButtonScale + ' %';
    update();
  };
  const sizeHelp = document.createElement('small');
  sizeHelp.textContent = 'Le réglage s’applique à tous les boutons du rendu.';
  sizeControl.append(sizeLabel, sizeSlider, sizeValue, sizeHelp);
  panel.append(sizeControl, choices, shapeControl);
  const editor = document.querySelector('#editor');
  const layoutPanel = editor?.querySelector('.block-presentation-panel');
  if (editor && layoutPanel) layoutPanel.after(panel);
  else editor?.prepend(panel);
};

const pageBeforeDesignButtonSelector = page;
page = function () {
  const doc = parseRenderedPage(pageBeforeDesignButtonSelector());
  const look = state.siteButtonLook || selectedDesignButtonLook();
  const shape = selectedDesignButtonShape();
  const radius = designButtonShapes.find(item => item.id === shape)?.radius || '16px';
  doc.body.dataset.siteButtonLook = look;
  doc.body.dataset.siteButtonShape = shape;
  const siteButtonScale = Math.max(60, Math.min(130, Number(state.siteButtonScale) || 100)) / 100;
  for (const button of doc.querySelectorAll(siteButtonLookTarget)) {
    button.dataset.siteButtonStyleTarget = 'true';
    if (look === 'classic') button.style.setProperty('border-radius', radius, 'important');
    let individualScale = Number(button.dataset.homeCtaScale) || Number(button.dataset.customScale) || 1;
    if (button.dataset.customSiteButton) {
      const custom = state.customSiteButtons?.find(item => item.id === button.dataset.customSiteButton);
      individualScale = Number(custom?.scale) || individualScale;
    }
    button.style.setProperty('scale', String(siteButtonScale * individualScale), 'important');
  }
  const classicStyle = doc.createElement('style');
  classicStyle.textContent = `body[data-site-button-look="classic"] ${siteButtonLookTarget}{display:inline-flex!important;align-items:center!important;justify-content:center!important;min-height:44px!important;padding:10px 16px!important;border:1px solid ${state.accent}!important;border-radius:8px!important;background:${state.accent}!important;color:${paletteButtonText(state.accent)}!important;box-shadow:0 3px 8px #44241940!important;font-weight:700!important;text-decoration:none!important}`;
  doc.head.append(classicStyle);
  if (look !== 'classic') {
    const style = doc.createElement('style');
    style.id = 'design-site-button-look';
    style.textContent = `
      body[data-site-button-look="neomorphic"] ${siteButtonLookTarget} {
        display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:18px!important;min-height:48px!important;padding:12px 20px!important;border:1px solid #f8fafc!important;border-radius:999px!important;background:linear-gradient(145deg,#fbfcff,#e5e8ee)!important;color:#20242d!important;box-shadow:7px 8px 15px #151b292b,-5px -5px 13px #ffffffd9,inset 1px 1px 2px #fff!important;font-weight:700!important
      }
      body[data-site-button-look="neomorphic"] :is(.custom-site-button-copy small){color:#565d69!important}
      body[data-site-button-look="neomorphic"] .custom-site-button-indicator{color:#20242d!important;background:linear-gradient(145deg,#f9fbff,#e1e4ea)!important;box-shadow:2px 3px 6px #151b2930,-2px -2px 5px #fff!important}
      body[data-site-button-look="liquid"] ${siteButtonLookTarget} {
        display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:18px!important;min-height:48px!important;padding:12px 20px!important;border:1px solid color-mix(in srgb,${state.accent} 68%,white)!important;border-radius:999px!important;background:linear-gradient(145deg,#171923ed,#080a11f7)!important;color:#fff!important;box-shadow:inset 0 1px 1px #ffffff55,0 0 0 1px #070912,0 7px 18px color-mix(in srgb,${state.accent} 48%,transparent)!important;backdrop-filter:blur(12px) saturate(150%)!important;-webkit-backdrop-filter:blur(12px) saturate(150%)!important;font-weight:700!important
      }
      body[data-site-button-look="liquid"] :is(.custom-site-button-copy small){color:#ebeaf2!important}
      body[data-site-button-look="crystal"] ${siteButtonLookTarget} {
        display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:18px!important;min-height:48px!important;padding:12px 20px!important;border:1px solid #d2a75f!important;border-radius:16px!important;background:linear-gradient(145deg,#ffffffdc,#f5eee2cc)!important;color:#33251b!important;box-shadow:inset 0 1px 1px #fff,0 5px 14px #593c2026,0 0 0 1px #fff8!important;backdrop-filter:blur(10px) saturate(135%)!important;-webkit-backdrop-filter:blur(10px) saturate(135%)!important;font-weight:700!important
      }
      body[data-site-button-look="crystal"] :is(.custom-site-button-copy small){color:#594a3b!important}
      body[data-site-button-look="onyx"] ${siteButtonLookTarget} {
        display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:18px!important;min-height:48px!important;padding:12px 20px!important;border:1px solid #c79b50!important;border-radius:14px!important;background:linear-gradient(145deg,#262832,#0b0c12 68%,#20212a)!important;color:#fff8e9!important;box-shadow:inset 0 1px 1px #ffffff40,0 5px 0 #07080c,0 9px 18px #08090d55,0 0 14px #c9963a40!important;font-weight:700!important
      }
      body[data-site-button-look="onyx"] :is(.custom-site-button-copy small){color:#e9d8b8!important}
      body[data-site-button-look="emerald"] ${siteButtonLookTarget} {
        display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:12px!important;min-height:48px!important;padding:12px 21px!important;border:2px solid #f1d28b!important;border-radius:14px!important;background:linear-gradient(145deg,#38b98b 0%,#08785c 48%,#073a48 100%)!important;color:#fff9e8!important;text-shadow:0 1px 2px #062f2d!important;box-shadow:inset 0 2px 2px #ffffffb0,inset 0 -4px 8px #032b3770,0 0 0 2px #d4ae67,0 0 0 4px #286d59,0 5px 0 #092f31,0 9px 16px #041b1d55!important;font-weight:700!important
      }
      body[data-site-button-look="emerald"] :is(.custom-site-button-copy small){color:#e3f7ed!important}
      body[data-site-button-look="neomorphic"] ${siteButtonLookTarget}:hover,
      body[data-site-button-look="liquid"] ${siteButtonLookTarget}:hover,
      body[data-site-button-look="crystal"] ${siteButtonLookTarget}:hover,
      body[data-site-button-look="onyx"] ${siteButtonLookTarget}:hover,
      body[data-site-button-look="emerald"] ${siteButtonLookTarget}:hover {transform:translateY(-1px);filter:brightness(1.08)}
      body[data-site-button-look="liquid"] :is(.custom-site-button-indicator),body[data-site-button-look="onyx"] :is(.custom-site-button-indicator){color:#ffe0a0!important;text-shadow:0 0 10px #ffd37c!important}
      body[data-site-button-look="crystal"] :is(.custom-site-button-indicator){color:#865822!important}
      body[data-site-button-look] ${siteButtonLookTarget}::before,body[data-site-button-look] ${siteButtonLookTarget}::after{content:none!important;display:none!important}
      @media(prefers-reduced-motion:reduce){body[data-site-button-look] ${siteButtonLookTarget}{transition:none!important;transform:none!important}}
    `;
    doc.head.append(style);
  }
  return serializeRenderedPage(doc);
};

const designButtonSelectorStyle = document.createElement('style');
designButtonSelectorStyle.textContent = `
  #editor .site-button-look-panel{margin:22px 0 30px;padding:18px 18px 30px;border:1px solid #9a7458;border-radius:14px;background:#fffaf5;color:#38281f}
  #editor .site-button-look-panel h2{margin:0 0 6px;color:#38281f;font-size:20px}
  #editor .site-button-look-panel .hint{margin:0 0 14px;color:#604b3f}
  #editor .site-button-look-choices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}
  #editor .site-button-look-choice{display:grid;justify-items:center;gap:10px;min-height:90px;padding:12px;background:#fff!important;color:#38281f!important;border:1px solid #9a7458!important;border-radius:11px!important}
  #editor .site-button-look-choice[aria-pressed="true"]{outline:3px solid #8e3d25!important;outline-offset:1px;background:#f7e8d9!important}
  #editor .site-button-look-choice strong{display:none!important;color:#38281f!important;font-size:12px}
  #editor .site-button-size-control{display:grid;grid-template-columns:1fr auto;align-items:center;gap:7px 12px;margin:16px 0 22px;padding:14px 0 16px;border-top:1px solid #e5caba;border-bottom:1px solid #e5caba;color:#38281f}
  #editor .site-button-size-control label{font-size:13px;font-weight:700}
  #editor .site-button-size-control input{grid-column:1/-1;width:100%;margin:0;accent-color:#8e3d25}
  #editor .site-button-size-control output{font-size:13px;font-weight:700;color:#71391f}
  #editor .site-button-size-control small{grid-column:1/-1;color:#604b3f;font-size:11px;line-height:1.45}
  #editor .site-button-shape-control{margin-top:20px;padding:15px 12px 12px;border-top:1px solid #e5caba;border-radius:10px;background:#fff}
  #editor .site-button-shape-control h3{margin:0 0 5px;color:#38281f;font-size:15px}
  #editor .site-button-shape-control .hint{margin:0 0 10px;color:#604b3f;font-size:12px}
  #editor .site-button-shape-choices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}
  #editor .site-button-shape-choice{display:grid;justify-items:center;gap:8px;padding:9px 5px;background:#fff!important;color:#38281f!important;border:1px solid #9a7458!important;border-radius:9px!important;font-size:11px}
  #editor .site-button-shape-choice[aria-pressed="true"]{outline:3px solid #8e3d25!important;outline-offset:1px;background:#f7e8d9!important}
  #editor .site-button-shape-sample{display:inline-flex;align-items:center;justify-content:center;min-height:28px;padding:5px 9px;background:#8e3d25;color:#fff;font:bold 10px Arial}
  #editor .site-button-look-sample{display:flex;align-items:center;gap:10px;padding:9px 14px;border-radius:9px;background:#8e3d25;color:#fff;font:bold 12px Arial;box-shadow:0 3px 8px #44241940}
  #editor .site-button-look-sample i{font-style:normal;font-size:17px;line-height:12px}
  #editor .site-button-look-choice.look-neomorphic .site-button-look-sample{border:1px solid #f8fafc!important;background:linear-gradient(145deg,#fbfcff,#e5e8ee)!important;color:#20242d!important;box-shadow:4px 5px 9px #151b2930,-3px -3px 7px #fff!important}
  #editor .site-button-look-choice.look-liquid .site-button-look-sample{border:1px solid #9298b9!important;background:linear-gradient(145deg,#171923,#080a11)!important;color:#fff!important;box-shadow:inset 0 1px 1px #ffffff70,0 4px 11px #57508b85!important}
  #editor .site-button-look-choice.look-crystal .site-button-look-sample{border:1px solid #d2a75f!important;border-radius:13px!important;background:linear-gradient(145deg,#fff,#f1e8d8)!important;color:#33251b!important;box-shadow:inset 0 1px 1px #fff,0 4px 8px #593c2026!important}
  #editor .site-button-look-choice.look-onyx .site-button-look-sample{border:1px solid #c79b50!important;border-radius:12px!important;background:linear-gradient(145deg,#262832,#0b0c12 68%,#20212a)!important;color:#fff8e9!important;box-shadow:inset 0 1px 1px #ffffff45,0 4px 0 #07080c,0 7px 10px #08090d55!important}
  #editor .site-button-look-choice.look-emerald .site-button-look-sample{border:2px solid #f1d28b!important;border-radius:14px!important;background:linear-gradient(145deg,#38b98b 0%,#08785c 48%,#073a48 100%)!important;color:#fff9e8!important;box-shadow:inset 0 2px 2px #ffffffb0,inset 0 -4px 8px #032b3770,0 0 0 2px #d4ae67,0 0 0 4px #286d59,0 5px 0 #092f31,0 8px 12px #041b1d55!important}
  #editor .site-button-look-choice.look-neomorphic .site-button-look-sample,#editor .site-button-look-choice.look-neomorphic .site-button-look-sample *{color:#20242d!important;-webkit-text-fill-color:#20242d!important}
  #editor .site-button-look-choice.look-liquid .site-button-look-sample,#editor .site-button-look-choice.look-liquid .site-button-look-sample *{color:#fff!important;-webkit-text-fill-color:#fff!important}
  #editor .site-button-look-choice.look-crystal .site-button-look-sample,#editor .site-button-look-choice.look-crystal .site-button-look-sample *{color:#33251b!important;-webkit-text-fill-color:#33251b!important}
  #editor .site-button-look-choice.look-onyx .site-button-look-sample,#editor .site-button-look-choice.look-onyx .site-button-look-sample *{color:#fff8e9!important;-webkit-text-fill-color:#fff8e9!important}
  #editor .site-button-look-choice.look-emerald .site-button-look-sample,#editor .site-button-look-choice.look-emerald .site-button-look-sample *{color:#fff9e8!important;-webkit-text-fill-color:#fff9e8!important}
  #editor button.site-button-look-choice.look-liquid > .site-button-look-sample{background:#10121a!important;color:#fff!important;-webkit-text-fill-color:#fff!important;border:1px solid #9ca1c2!important;box-shadow:inset 0 1px 1px #ffffff75,0 5px 13px #55517f99!important}
  #editor button.site-button-look-choice.look-liquid > .site-button-look-sample > span{color:#fff!important;-webkit-text-fill-color:#fff!important}
  @media(max-width:420px){#editor .site-button-look-choices{grid-template-columns:1fr 1fr}}
`;
document.head.append(designButtonSelectorStyle);
render();
update();
