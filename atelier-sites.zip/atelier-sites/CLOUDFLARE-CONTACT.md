# Activation des formulaires Cloudflare

Préparation locale uniquement : aucun déploiement et aucun e-mail réel envoyé.

Configurer le domaine dans Cloudflare Email Sending, autoriser l’envoi pour le compte et vérifier l’adresse de réception. Créer un widget Turnstile autorisé pour le domaine public.

Variables secrètes à définir dans l’environnement du serveur, jamais dans le navigateur ou un export HTML :

```
CONTACT_PROVIDER=cloudflare
CLOUDFLARE_ACCOUNT_ID=identifiant-du-compte
CLOUDFLARE_EMAIL_API_TOKEN=jeton-avec-droit-envoi-email
CONTACT_FROM=contact@votre-domaine.fr
CONTACT_TO=votre-adresse-de-reception
TURNSTILE_SITE_KEY=cle-publique
TURNSTILE_SECRET_KEY=cle-secrete
CONTACT_PUBLIC_HOSTNAME=www.votre-domaine.fr
```

Redémarrer le serveur puis sélectionner « Cloudflare — envoi protégé » dans les réglages du Formulaire de contact. Le choix existant reste conservé. Sans configuration complète, l’envoi Cloudflare reste désactivé ; la messagerie du visiteur reste disponible.

Le serveur valide le jeton Turnstile, le nom de domaine et l’action `contact` avant tout envoi. Le destinataire est imposé côté serveur. Les limites existantes sont de 5 requêtes par heure et par IP, et 20 Ko par requête. La limite est locale au processus et se réinitialise au redémarrage : pour plusieurs serveurs, prévoir une limite partagée. Derrière un proxy, l’adresse du socket peut désigner le proxy ; configurer une extraction d’IP de confiance et une limite Cloudflare au déploiement.

Un export HTML seul ne fournit pas le serveur `/api/contact` : héberger cette route avec le site. La version actuelle utilise une adresse destinataire fixe par serveur ; un service multi-clients doit résoudre le destinataire depuis un identifiant de site validé côté serveur, jamais depuis une adresse fournie par le navigateur.

Documentation : https://developers.cloudflare.com/email-service/get-started/send-emails/ et https://developers.cloudflare.com/turnstile/get-started/server-side-validation/
