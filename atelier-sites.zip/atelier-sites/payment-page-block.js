// Editable checkout-style content block with a secure-provider handoff.
contentNames.payment = 'Page de paiement';
editorSectionIcons.payment = '💳';

const renderBeforePaymentPageBlock = render;
render = function () {
  renderBeforePaymentPageBlock();
  if (tab !== 'blocks') return;

  const editor = document.getElementById('editor');
  if (!editor) return;

  for (const card of editor.querySelectorAll('.block')) {
    const block = state.blocks.find(item => item.id === card.dataset.blockId);
    if (block?.type !== 'payment') continue;
    const details = card.querySelector('details');
    if (!details || details.querySelector('.payment-page-settings')) continue;

    block.products ??= [{name: 'Votre prestation', description: '', price: '0', oldPrice: '', photo: '', url: '', mode: 'online', featured: true}];
    block.products[0] ??= {name: 'Votre prestation', description: '', price: '0', oldPrice: '', photo: '', url: '', mode: 'online', featured: true};
    const product = block.products[0];
    const settings = document.createElement('section');
    settings.className = 'payment-page-settings library-details';
    const heading = document.createElement('h3');
    heading.textContent = 'Paiement de la boutique';
    const hint = document.createElement('p');
    hint.className = 'hint';
    hint.textContent = 'Cette page reste masquée sur le site. Elle s’ouvre après le clic sur « Voir le paiement » depuis un produit de la boutique.';
    settings.append(heading, hint);
    field(settings, 'Nom de la prestation', 'name', product);
    field(settings, 'Prix affiché', 'price', product);
    const currencyLabel = document.createElement('label');
    currencyLabel.textContent = 'Devise';
    const currency = document.createElement('select');
    for (const [value, label] of [['EUR', 'Euro (€)'], ['USD', 'Dollar américain ($)'], ['GBP', 'Livre sterling (£)']]) {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = label;
      currency.append(option);
    }
    currency.value = ['EUR', 'USD', 'GBP'].includes(block.paymentCurrency) ? block.paymentCurrency : 'EUR';
    currency.addEventListener('change', () => { block.paymentCurrency = currency.value; update(); });
    currencyLabel.append(currency);
    settings.append(currencyLabel);
    const paymentLink = field(settings, 'Lien de paiement de secours (HTTPS)', 'paymentUrl', block);
    paymentLink.type = 'url';
    paymentLink.placeholder = 'https://…';
    paymentLink.addEventListener('blur', () => {
      if (!paymentLink.value.trim()) return;
      try {
        const url = new URL(paymentLink.value.trim());
        if (url.protocol !== 'https:' || url.username || url.password) throw new Error();
        block.paymentUrl = url.href;
        paymentLink.value = url.href;
        update();
      } catch {
        block.paymentUrl = '';
        paymentLink.setCustomValidity('Utilisez un lien HTTPS valide fourni par votre prestataire de paiement.');
        paymentLink.reportValidity();
      }
    });
    paymentLink.addEventListener('input', () => paymentLink.setCustomValidity(''));
    const linkHint = document.createElement('p');
    linkHint.className = 'hint';
    linkHint.textContent = 'Le bouton « Voir le paiement » utilise le lien configuré sur chaque produit de la boutique. HopClic ne traite aucun paiement.';
    settings.append(linkHint);
    details.prepend(settings);
  }
};

const pageBeforePaymentPageBlock = page;
page = function () {
  const doc = parseRenderedPage(pageBeforePaymentPageBlock());
  const blocks = state.blocks.filter(block => block.visible && block.type === 'payment');
  if (!blocks.length) return serializeRenderedPage(doc);
  for (const duplicate of blocks.slice(1)) doc.getElementById('rubrique-' + duplicate.id)?.remove();

  const symbols = {EUR: '€', USD: '$', GBP: '£'};
  for (const block of blocks.slice(0, 1)) {
    const section = doc.getElementById('rubrique-' + block.id);
    if (!section) continue;
    const item = block.products?.[0] || {};
    const amount = String(item.price || '').trim();
    const currency = symbols[block.paymentCurrency] ? block.paymentCurrency : 'EUR';
    const total = amount && Number.isFinite(Number(amount.replace(',', '.')))
      ? new Intl.NumberFormat('fr-FR', {style: 'currency', currency}).format(Number(amount.replace(',', '.')))
      : 'À définir';
    let paymentHref = '';
    try {
      const url = new URL(block.paymentUrl || '');
      if (url.protocol === 'https:' && !url.username && !url.password) paymentHref = url.href;
    } catch {}
    const title = esc(block.title || 'Finaliser votre commande');
    const text = esc(block.text || 'Vos coordonnées et le règlement seront finalisés auprès du prestataire sécurisé.');
    const productName = esc(item.name || 'Votre prestation');
    const action = paymentHref
      ? `<a class="checkout-action" href="${esc(paymentHref)}" target="_blank" rel="noopener noreferrer">Continuer vers le paiement sécurisé <span aria-hidden="true">↗</span></a>`
      : `<button class="checkout-action" type="button" disabled>Ajoutez votre lien de paiement sécurisé</button>`;
    section.className = 'payment-checkout-section';
    section.setAttribute('aria-label', 'Page de paiement');
    section.setAttribute('data-site-checkout', '');
    section.hidden = true;
    section.innerHTML = `<div class="checkout-layout"><main class="checkout-account"><div class="checkout-account-head"><div><p class="checkout-kicker">CRÉER UN COMPTE</p><h2>${title}</h2></div></div><p class="checkout-intro">${text}</p><div class="checkout-auth-options" role="group" aria-label="Choisir une méthode de connexion"><button type="button" class="checkout-auth-button" data-auth-provider="google"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M21.35 12.23c0-.71-.06-1.39-.18-2.05H12v3.88h5.24a4.48 4.48 0 0 1-1.94 2.94v2.45h3.14c1.84-1.7 2.91-4.21 2.91-7.22Z"/><path fill="#34A853" d="M12 21.5c2.63 0 4.84-.87 6.45-2.36l-3.14-2.45c-.87.58-1.98.92-3.31.92-2.54 0-4.69-1.71-5.46-4.01H3.29v2.52A9.75 9.75 0 0 0 12 21.5Z"/><path fill="#FBBC05" d="M6.54 13.6a5.86 5.86 0 0 1 0-3.2V7.88H3.29a9.75 9.75 0 0 0 0 8.24l3.25-2.52Z"/><path fill="#EA4335" d="M12 6.39c1.43 0 2.71.49 3.72 1.47l2.79-2.79A9.34 9.34 0 0 0 12 1.5a9.75 9.75 0 0 0-8.71 5.38l3.25 2.52c.77-2.3 2.92-4.01 5.46-4.01Z"/></svg>Continuer avec Google</button><button type="button" class="checkout-auth-button" data-auth-provider="apple"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M16.37 12.63c.02 2.2 1.93 2.93 1.95 2.94-.02.05-.3 1.04-.98 2.05-.59.88-1.2 1.76-2.16 1.78-.94.02-1.25-.57-2.33-.57-1.08 0-1.43.55-2.32.59-.93.03-1.64-.95-2.23-1.83-1.22-1.77-2.15-5.01-.9-7.2.62-1.09 1.72-1.78 2.9-1.8.91-.02 1.77.62 2.33.62.55 0 1.6-.77 2.7-.66.46.02 1.76.18 2.6 1.4-.07.04-1.56.91-1.55 2.68ZM14.6 6.99c.49-.59.82-1.41.73-2.23-.71.03-1.58.48-2.09 1.07-.46.53-.86 1.36-.75 2.16.8.06 1.62-.41 2.11-1Z"/></svg>Continuer avec Apple</button><button type="button" class="checkout-auth-button" data-auth-provider="facebook"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="#1877F2"/><path fill="#fff" d="M13.4 20v-7h2.35l.35-2.73H13.4V8.53c0-.79.22-1.33 1.36-1.33h1.45V4.76c-.25-.03-1.12-.11-2.13-.11-2.1 0-3.54 1.28-3.54 3.64v1.98H8.16V13h2.38v7h2.86Z"/></svg>Continuer avec Facebook</button><button type="button" class="checkout-auth-button" data-auth-provider="email"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="1.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="m4 7 8 6 8-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>Continuer avec un e-mail</button></div><p class="checkout-auth-feedback" role="status" aria-live="polite">Les connexions Google, Apple et Facebook doivent être activées par un service d’identification.</p><div class="checkout-step"><h3>Vos informations</h3><p>La création du compte et les coordonnées de facturation s’effectuent sur la page sécurisée de votre prestataire.</p><details><summary>Coordonnées de facturation</summary><p>Ces informations seront demandées au moment du règlement par votre prestataire de paiement.</p></details></div><p class="checkout-terms">En continuant, vous serez redirigé vers votre prestataire de paiement pour finaliser la commande.</p>${action}<p class="checkout-secure-note"><span aria-hidden="true">▣</span> Le règlement est traité par votre prestataire sécurisé.</p></main><aside class="checkout-summary" aria-label="Résumé de commande"><h3>Résumé de commande</h3><div class="checkout-line"><span>${productName}</span><strong>${total}</strong></div><div class="checkout-line checkout-fees"><span>Frais de traitement</span><strong>0,00 €</strong></div><div class="checkout-total"><strong>Total</strong><strong>${total}</strong></div></aside></div><style>.payment-checkout-section{padding:clamp(28px,6vw,72px) 6%;background:#fff;color:#29343d}.checkout-layout{max-width:1040px;margin:auto;display:grid;grid-template-columns:minmax(0,1.7fr) minmax(245px,.8fr);gap:22px;align-items:start}.checkout-account,.checkout-summary{border:1px solid #d6dfe6;border-radius:5px;background:#fff;box-shadow:0 2px 8px #20384b0a}.checkout-account{padding:clamp(22px,4vw,36px)}.checkout-account-head{display:flex;align-items:center;justify-content:space-between;gap:15px}.checkout-kicker{font-size:11px;letter-spacing:1.6px;color:#778391;margin:0 0 8px}.checkout-account h2{font:600 26px Arial,sans-serif;margin:0 0 12px;color:#29343d}.checkout-intro,.checkout-step p{font:14px/1.55 Arial,sans-serif;color:#5d6872;max-width:unset}.checkout-auth-options{display:grid;gap:10px;margin:18px 0 9px}.checkout-auth-button{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:44px;border:1px solid #c9cdd1;border-radius:4px;background:#fff;color:#4d5964;font:600 14px Arial,sans-serif;cursor:pointer;transition:background .16s,border-color .16s}.checkout-auth-button:hover{background:#f7f9fb;border-color:#9ba6ae}.checkout-auth-button svg{width:22px;height:22px;flex:none}.checkout-auth-feedback{min-height:16px;margin:8px 0 0;color:#78838d;font:12px/1.45 Arial,sans-serif}.checkout-step{margin-top:18px;padding:22px 0;border-top:1px solid #e0e6eb;border-bottom:1px solid #e0e6eb}.checkout-step h3,.checkout-summary h3{font:600 18px Arial,sans-serif;margin:0 0 16px;color:#29343d}.checkout-step details{margin-top:20px;padding:15px;border:1px solid #e0e6eb;border-radius:4px}.checkout-step summary{font-weight:600;cursor:pointer}.checkout-terms,.checkout-secure-note{font:12px/1.5 Arial,sans-serif;color:#78838d}.checkout-action{display:flex;justify-content:center;align-items:center;gap:12px;width:100%;min-height:48px;margin-top:20px;padding:13px 18px;border-radius:4px;background:#6b9d37;color:#fff;font:600 14px Arial,sans-serif;text-align:center;text-decoration:none}.checkout-action span{font-size:18px}.checkout-action:disabled{opacity:.6;cursor:not-allowed}.checkout-secure-note{text-align:center;margin:16px 0 0}.checkout-summary{padding:20px 16px}.checkout-summary h3{padding-bottom:14px;border-bottom:1px solid #e0e6eb}.checkout-line,.checkout-total{display:flex;justify-content:space-between;gap:12px;padding:13px 0;border-bottom:1px solid #e0e6eb;font:14px Arial,sans-serif}.checkout-line span{color:#5f6b74}.checkout-line strong,.checkout-total strong{color:#29343d}.checkout-total{font-size:17px;border-bottom:0;padding-bottom:2px}.checkout-fees{font-size:13px}.checkout-fees strong{font-weight:400}@media(max-width:700px){.checkout-layout{grid-template-columns:1fr}.checkout-summary{grid-row:1}.checkout-account-head{align-items:flex-start;flex-direction:column}.checkout-account h2{font-size:23px}}@media(prefers-reduced-motion:reduce){.payment-checkout-section *{scroll-behavior:auto!important}}</style>`;
    section.innerHTML = `<div class="checkout-layout"><main class="checkout-account"><div class="checkout-account-head"><div><p class="checkout-kicker">CRÉER UN COMPTE</p><h2>${title}</h2></div></div><p class="checkout-intro">${text}</p><div class="checkout-auth-options" role="group" aria-label="Choisir une méthode de connexion"><button type="button" class="checkout-auth-button" data-auth-provider="google" onclick="this.closest('.checkout-account').querySelector('.checkout-auth-feedback').textContent='La connexion Google doit être activée par un service d’identification.'"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M21.35 12.23c0-.71-.06-1.39-.18-2.05H12v3.88h5.24a4.48 4.48 0 0 1-1.94 2.94v2.45h3.14c1.84-1.7 2.91-4.21 2.91-7.22Z"/><path fill="#34A853" d="M12 21.5c2.63 0 4.84-.87 6.45-2.36l-3.14-2.45c-.87.58-1.98.92-3.31.92-2.54 0-4.69-1.71-5.46-4.01H3.29v2.52A9.75 9.75 0 0 0 12 21.5Z"/><path fill="#FBBC05" d="M6.54 13.6a5.86 5.86 0 0 1 0-3.2V7.88H3.29a9.75 9.75 0 0 0 0 8.24l3.25-2.52Z"/><path fill="#EA4335" d="M12 6.39c1.43 0 2.71.49 3.72 1.47l2.79-2.79A9.34 9.34 0 0 0 12 1.5a9.75 9.75 0 0 0-8.71 5.38l3.25 2.52c.77-2.3 2.92-4.01 5.46-4.01Z"/></svg>Continuer avec Google</button><button type="button" class="checkout-auth-button" data-auth-provider="apple" onclick="this.closest('.checkout-account').querySelector('.checkout-auth-feedback').textContent='La connexion Apple doit être activée par un service d’identification.'"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M16.37 12.63c.02 2.2 1.93 2.93 1.95 2.94-.02.05-.3 1.04-.98 2.05-.59.88-1.2 1.76-2.16 1.78-.94.02-1.25-.57-2.33-.57-1.08 0-1.43.55-2.32.59-.93.03-1.64-.95-2.23-1.83-1.22-1.77-2.15-5.01-.9-7.2.62-1.09 1.72-1.78 2.9-1.8.91-.02 1.77.62 2.33.62.55 0 1.6-.77 2.7-.66.46.02 1.76.18 2.6 1.4-.07.04-1.56.91-1.55 2.68ZM14.6 6.99c.49-.59.82-1.41.73-2.23-.71.03-1.58.48-2.09 1.07-.46.53-.86 1.36-.75 2.16.8.06 1.62-.41 2.11-1Z"/></svg>Continuer avec Apple</button><button type="button" class="checkout-auth-button" data-auth-provider="facebook" onclick="this.closest('.checkout-account').querySelector('.checkout-auth-feedback').textContent='La connexion Facebook doit être activée par un service d’identification.'"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="#1877F2"/><path fill="#fff" d="M13.4 20v-7h2.35l.35-2.73H13.4V8.53c0-.79.22-1.33 1.36-1.33h1.45V4.76c-.25-.03-1.12-.11-2.13-.11-2.1 0-3.54 1.28-3.54 3.64v1.98H8.16V13h2.38v7h2.86Z"/></svg>Continuer avec Facebook</button><button type="button" class="checkout-auth-button" data-auth-provider="email" onclick="this.closest('.checkout-account').querySelector('.checkout-auth-feedback').textContent='La connexion par e-mail doit être activée pour ce site.'"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="1.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="m4 7 8 6 8-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>Continuer avec un e-mail</button></div><p class="checkout-auth-feedback" role="status" aria-live="polite">Les connexions Google, Apple et Facebook doivent être activées par un service d’identification.</p><div class="checkout-step"><h3>Vos informations</h3><p>La création du compte et les coordonnées de facturation s’effectuent sur la page sécurisée de votre prestataire.</p><details><summary>Coordonnées de facturation</summary><p>Ces informations seront demandées au moment du règlement par votre prestataire de paiement.</p></details></div><p class="checkout-terms">En continuant, vous serez redirigé vers votre prestataire de paiement pour finaliser la commande.</p>${action}<p class="checkout-secure-note"><span aria-hidden="true">▣</span> Le règlement est traité par votre prestataire sécurisé.</p></main><aside class="checkout-summary" aria-label="Résumé de commande"><h3>Résumé de commande</h3><div class="checkout-line"><span>${productName}</span><strong>${total}</strong></div><div class="checkout-line checkout-fees"><span>Frais de traitement</span><strong>0,00 €</strong></div><div class="checkout-total"><strong>Total</strong><strong>${total}</strong></div></aside></div><style>.payment-checkout-section{padding:clamp(28px,6vw,72px) 6%;background:#fff;color:#29343d}.checkout-layout{max-width:1040px;margin:auto;display:grid;grid-template-columns:minmax(0,1.7fr) minmax(245px,.8fr);gap:22px;align-items:start}.checkout-account,.checkout-summary{border:1px solid #d6dfe6;border-radius:5px;background:#fff;box-shadow:0 2px 8px #20384b0a}.checkout-account{padding:clamp(22px,4vw,36px)}.checkout-account-head{display:flex;align-items:center;justify-content:space-between;gap:15px}.checkout-kicker{font-size:11px;letter-spacing:1.6px;color:#778391;margin:0 0 8px}.checkout-account h2{font:600 26px Arial,sans-serif;margin:0 0 12px;color:#29343d}.checkout-intro,.checkout-step p{font:14px/1.55 Arial,sans-serif;color:#5d6872;max-width:unset}.checkout-auth-options{display:grid;gap:10px;margin:18px 0 9px}.checkout-auth-button{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:44px;border:1px solid #c9cdd1;border-radius:4px;background:#fff;color:#4d5964;font:600 14px Arial,sans-serif;cursor:pointer;transition:background .16s,border-color .16s}.checkout-auth-button:hover{background:#f7f9fb;border-color:#9ba6ae}.checkout-auth-button svg{width:22px;height:22px;flex:none}.checkout-auth-feedback{min-height:16px;margin:8px 0 0;color:#78838d;font:12px/1.45 Arial,sans-serif}.checkout-step{margin-top:18px;padding:22px 0;border-top:1px solid #e0e6eb;border-bottom:1px solid #e0e6eb}.checkout-step h3,.checkout-summary h3{font:600 18px Arial,sans-serif;margin:0 0 16px;color:#29343d}.checkout-step details{margin-top:20px;padding:15px;border:1px solid #e0e6eb;border-radius:4px}.checkout-step summary{font-weight:600;cursor:pointer}.checkout-terms,.checkout-secure-note{font:12px/1.5 Arial,sans-serif;color:#78838d}.checkout-action{display:flex;justify-content:center;align-items:center;gap:12px;width:100%;min-height:48px;margin-top:20px;padding:13px 18px;border-radius:4px;background:#6b9d37;color:#fff;font:600 14px Arial,sans-serif;text-align:center;text-decoration:none}.checkout-action span{font-size:18px}.checkout-action:disabled{opacity:.6;cursor:not-allowed}.checkout-secure-note{text-align:center;margin:16px 0 0}.checkout-summary{padding:20px 16px}.checkout-summary h3{padding-bottom:14px;border-bottom:1px solid #e0e6eb}.checkout-line,.checkout-total{display:flex;justify-content:space-between;gap:12px;padding:13px 0;border-bottom:1px solid #e0e6eb;font:14px Arial,sans-serif}.checkout-line span{color:#5f6b74}.checkout-line strong,.checkout-total strong{color:#29343d}.checkout-total{font-size:17px;border-bottom:0;padding-bottom:2px}.checkout-fees{font-size:13px}.checkout-fees strong{font-weight:400}@media(max-width:700px){.checkout-layout{grid-template-columns:1fr}.checkout-summary{grid-row:1}.checkout-account-head{align-items:flex-start;flex-direction:column}.checkout-account h2{font-size:23px}}@media(prefers-reduced-motion:reduce){.payment-checkout-section *{scroll-behavior:auto!important}}</style>`;
  }
  const checkoutScript = doc.createElement('script');
  checkoutScript.textContent = `document.addEventListener('click', event => {
    const trigger = event.target.closest('[data-shop-payment]');
    if (!trigger) return;
    const section = document.querySelector('[data-site-checkout]');
    if (!section) return;
    const secureUrl = trigger.dataset.paymentUrl || '';
    try {
      const url = new URL(secureUrl, location.href);
      if (url.protocol !== 'https:' || url.username || url.password) return;
      const summaryName = section.querySelector('.checkout-line span');
      const summaryPrice = section.querySelector('.checkout-line strong');
      const total = section.querySelectorAll('.checkout-total strong')[1];
      if (summaryName) summaryName.textContent = trigger.dataset.productName || 'Votre produit';
      if (summaryPrice) summaryPrice.textContent = trigger.dataset.productPrice || '';
      if (total) total.textContent = trigger.dataset.productPrice || '';
      let action = section.querySelector('.checkout-action');
      if (action && action.tagName !== 'A') {
        const link = document.createElement('a');
        link.className = action.className;
        link.innerHTML = 'Continuer vers le paiement sécurisé <span aria-hidden="true">↗</span>';
        action.replaceWith(link);
        action = link;
      }
      if (action) {
        action.href = url.href;
        action.target = '_blank';
        action.rel = 'noopener noreferrer';
      }
      section.hidden = false;
      section.removeAttribute('aria-hidden');
      section.scrollIntoView({behavior:'smooth', block:'start'});
    } catch {}
  });`;
  doc.body.append(checkoutScript);
  return serializeRenderedPage(doc);
};

render();
update();
