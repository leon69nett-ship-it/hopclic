const modernTypeStyles=[
 ['Arial Extra Bold','Arial Extra Bold','Arial,sans-serif',800,'-.035em'],
 ['Segoe UI','Segoe UI · studio moderne','Segoe UI,Arial,sans-serif',650,'-.035em'],
 ['Bahnschrift','Bahnschrift · géométrique','Bahnschrift,Segoe UI,Arial,sans-serif',650,'-.025em'],
 ['Aptos','Aptos · contemporain','Aptos,Segoe UI,Arial,sans-serif',700,'-.035em'],
 ['Arial Black','Arial Black · affiche XXL','Arial Black,Arial,sans-serif',900,'-.055em'],
 ['Palatino Linotype','Palatino · luxe éditorial','Palatino Linotype,Georgia,serif',500,'-.035em'],
 ['Consolas','Consolas · digital','Consolas,Courier New,monospace',600,'-.035em']
];
const renderBeforeModernTypography=render;
render=function(){renderBeforeModernTypography();if(tab!=='design')return;
 const label=[...document.querySelectorAll('#editor label')].find(e=>e.firstChild?.textContent==='Typographie');const select=label?.querySelector('select');if(!select)return;
 for(const [id,name]of modernTypeStyles){const o=document.createElement('option');o.value=id;o.textContent=name;select.append(o)}select.value=state.font;select.setAttribute('aria-label','Typographie');
 const preview=document.createElement('div');preview.className='modern-type-preview';preview.innerHTML='<strong>Votre univers.<br>Votre signature.</strong><p>Une présentation claire, des idées qui prennent vie.</p>';
 const paint=()=>{const p=modernTypeStyles.find(t=>t[0]===select.value);preview.style.fontFamily=p?.[2]||select.value;preview.querySelector('strong').style.fontWeight=p?.[3]||700;preview.querySelector('strong').style.letterSpacing=p?.[4]||'-.02em'};paint();label.after(preview);
 const old=select.onchange;select.onchange=event=>{old?.call(select,event);paint()};
};
const pageBeforeModernTypography=page;
page=function(){const doc=parseRenderedPage(pageBeforeModernTypography());const p=modernTypeStyles.find(t=>t[0]===state.font);if(!p)return serializeRenderedPage(doc);const style=doc.createElement('style');style.id='modern-typography';style.textContent=`body{font-family:Segoe UI,Arial,sans-serif!important;line-height:1.65}body h1,body h2,body h3,body .hero h1,body .services-section>h2,body .project-comparison-launch h3{font-family:${p[2]}!important;font-weight:${p[3]}!important;letter-spacing:${p[4]}!important;line-height:1.12}body p{line-height:1.7}body button,body input,body textarea,body select{font-family:Segoe UI,Arial,sans-serif}body h1,body h2,body h3{overflow-wrap:break-word}`;doc.head.append(style);return serializeRenderedPage(doc)};
const modernTypePreviewStyle=document.createElement('style');modernTypePreviewStyle.textContent='.modern-type-preview{padding:22px 18px;margin:12px 0 24px;background:var(--ui-tint);border:1px solid var(--ui-border);border-radius:16px;color:var(--ui-text)}.modern-type-preview strong{display:block;font-size:29px;line-height:1.12}.modern-type-preview p{font:13px/1.6 Segoe UI,Arial,sans-serif;margin-bottom:0}';document.head.append(modernTypePreviewStyle);render();update();
