const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const {handlePhotoAI}=require('./photo-ai.cjs');const root=__dirname;
const {handleContact}=require('./contact.cjs');
const {handleTextAI}=require('./text-ai.cjs');
const {handleGoogleSearch}=require('./google-search.cjs');
http.createServer(async(req,res)=>{
 let pathname;try{pathname=new URL(req.url,'http://localhost').pathname}catch{res.writeHead(400).end();return}
 if(await handleGoogleSearch(req,res,pathname))return;
 if(await handlePhotoAI(req,res,pathname))return;
 if(await handleContact(req,res,pathname))return;
 if(await handleTextAI(req,res,pathname))return;
 if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405).end();return}
 let file;try{file=path.resolve(root,'.'+decodeURIComponent(pathname==='/'?'/index.html':pathname))}catch{res.writeHead(400).end();return}
 if(!file.startsWith(root+path.sep)||!['.html','.css','.js','.png','.jpg','.jpeg','.webp','.svg','.ico'].includes(path.extname(file))){res.writeHead(403).end();return}
 fs.readFile(file,(err,data)=>{if(err){res.writeHead(404).end('Introuvable');return}res.setHeader('Content-Type',({'html':'text/html; charset=utf-8','css':'text/css','js':'text/javascript','svg':'image/svg+xml','png':'image/png','jpg':'image/jpeg','jpeg':'image/jpeg','webp':'image/webp'})[path.extname(file).slice(1)]||'application/octet-stream');res.setHeader('Cache-Control','no-cache');res.end(req.method==='HEAD'?undefined:data)})
}).listen(Number(process.env.HOPCLIC_PORT)||8786,'127.0.0.1',()=>console.log('HopClic : http://127.0.0.1:'+(process.env.HOPCLIC_PORT||8786)));
