// Installe les correctifs « novice » dans index.html (une seule ligne ajoutée, sauvegarde automatique).
// À lancer depuis le dossier HopClic (celui qui contient server.cjs) : node install-novice.cjs
const fs = require('node:fs');
const path = require('node:path');

const dir = __dirname;
const indexPath = path.join(dir, 'index.html');

if (!fs.existsSync(indexPath) || !fs.existsSync(path.join(dir, 'server.cjs')) || !fs.existsSync(path.join(dir, 'novice-simplify.js'))) {
  console.error('Ce programme doit se trouver dans le dossier HopClic (celui qui contient server.cjs et index.html),');
  console.error('avec le fichier novice-simplify.js.');
  process.exit(1);
}

let html = fs.readFileSync(indexPath, 'utf8');
if (html.includes('novice-simplify.js')) {
  console.log('Les correctifs sont déjà installés. Rien à faire.');
  process.exit(0);
}

const marker = '<script>previewFrame.addEventListener("load"';
const at = html.lastIndexOf(marker);
if (at < 0) {
  console.error("Point d'insertion introuvable : votre index.html est différent de celui attendu.");
  console.error('Rien n’a été modifié. Envoyez-moi ce fichier index.html pour que j’adapte l’installation.');
  process.exit(1);
}

fs.copyFileSync(indexPath, indexPath + '.avant-correctifs.bak');
html = html.slice(0, at) + '<script src="novice-simplify.js?v=1"></script>\n' + html.slice(at);
fs.writeFileSync(indexPath, html);
console.log('Correctifs installés. Une copie de l’ancien fichier a été gardée : index.html.avant-correctifs.bak');
console.log('Rechargez la page du constructeur avec Ctrl+F5.');
