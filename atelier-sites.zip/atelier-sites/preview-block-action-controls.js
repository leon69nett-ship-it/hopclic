// Keep the discreet move and hide controls attached to each preview block.
(() => {
  const frame = document.getElementById('preview');
  if (!frame) return;

  function bind() {
    const doc = frame.contentDocument;
    if (!doc?.body) return;
    let style = doc.getElementById('preview-editor-tools-style');
    if (!style) {
      style = doc.createElement('style');
      style.id = 'preview-editor-tools-style';
      style.textContent = `.preview-block-tools{position:absolute!important;top:5px!important;right:5px!important;z-index:2147483001!important;display:flex!important;gap:2px!important;pointer-events:auto!important}.preview-block-tools button{display:grid!important;place-items:center!important;width:26px!important;min-width:26px!important;height:26px!important;min-height:26px!important;padding:0!important;border:1px solid #94502a55!important;border-radius:50%!important;background:#fffaf4e8!important;color:#813d24!important;box-shadow:0 1px 3px #4b291a20!important;font:14px/1 Arial!important;opacity:.78;cursor:pointer!important}.preview-block-tools button:hover,.preview-block-tools button:focus-visible{opacity:1!important;background:#fff!important;outline:1px solid #94502a!important;outline-offset:1px}.preview-block-tools button:disabled{opacity:.32!important;cursor:default!important}[data-editor-block]{position:relative}`;
      doc.head.append(style);
    }

    for (const section of doc.querySelectorAll('body>section[data-editor-block]')) {
      const block = state.blocks.find(item => String(item.id) === section.dataset.editorBlock);
      if (!block || section.querySelector(':scope>.preview-block-tools')) continue;
      const tools = doc.createElement('div');
      tools.className = 'preview-block-tools';
      tools.setAttribute('aria-label', `Actions du bloc ${block.title}`);
      for (const [label, title, delta] of [['↑', 'Monter le bloc', -1], ['↓', 'Descendre le bloc', 1], ['×', 'Masquer le bloc', 0]]) {
        const button = doc.createElement('button');
        button.type = 'button';
        button.textContent = label;
        button.title = title;
        button.setAttribute('aria-label', `${title} : ${block.title}`);
        const index = state.blocks.findIndex(item => item.id === block.id);
        button.disabled = delta !== 0 && (index + delta < 0 || index + delta >= state.blocks.length);
        button.addEventListener('click', event => {
          event.preventDefault();
          event.stopPropagation();
          selectedBlockId = block.id;
          if (delta === 0) {
            const current = state.blocks.findIndex(item => item.id === block.id);
            block.visible = false;
            const next = state.blocks.slice(current + 1).find(item => item.visible)
              || state.blocks.slice(0, current).reverse().find(item => item.visible);
            selectedBlockId = next?.id || null;
            tab = 'blocks';
            document.querySelectorAll('#tabs button').forEach(tabButton => tabButton.classList.toggle('active', tabButton.dataset.tab === 'blocks'));
            render();
            update();
            if (next) selectEditorBlock(next.id, true);
            return;
          }
          const current = state.blocks.findIndex(item => item.id === block.id);
          const target = current + delta;
          if (target < 0 || target >= state.blocks.length) return;
          [state.blocks[current], state.blocks[target]] = [state.blocks[target], state.blocks[current]];
          render();
          update();
        });
        tools.append(button);
      }
      section.prepend(tools);
      section.tabIndex = 0;
    }
  }

  frame.addEventListener('load', bind);
  const refreshBeforeActionControls = refreshPreviewWithoutBlink;
  refreshPreviewWithoutBlink = function () {
    refreshBeforeActionControls();
    bind();
  };
  bind();
})();
