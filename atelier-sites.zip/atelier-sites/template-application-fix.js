const renderBeforeTemplateApplicationFix=render;
render=function(){renderBeforeTemplateApplicationFix();if(tab!=='design')return;
 const buttons=document.querySelectorAll('.company-style-choices button[aria-label^="Appliquer le style"]');
 buttons.forEach(button=>{
  const previous=button.onclick;
  button.onclick=event=>{
   const hero=state.blocks.find(b=>b.type==='intro');if(hero)hero.visible=true;
   previous?.call(button,event);
   previewScrollY=0;previewFrame.contentWindow?.scrollTo(0,0);
  };
 });
 const note=document.querySelector('.company-style-choices .hint');if(note)note.textContent='Appliquer un modèle affiche aussi sa section d’accueil. Vos textes, images et autres rubriques sont conservés. « Voir le modèle complet » montre un exemple sans modifier votre site.';
};
const pageBeforeTemplateApplicationFix=page;
page=function(){const doc=parseRenderedPage(pageBeforeTemplateApplicationFix());
 if(!doc.body.classList.contains('building-premium'))return serializeRenderedPage(doc);
 const hero=doc.querySelector('.hero');
 if(hero&&!hero.querySelector('.premium-hero-visual')){
  const artwork=doc.createElement('div');artwork.className='template-empty-visual';artwork.setAttribute('aria-hidden','true');artwork.innerHTML='<span></span><i></i><b></b>';hero.append(artwork);hero.classList.add('template-awaiting-image');
 }
 const style=doc.createElement('style');style.id='template-final-composition';style.textContent=`
 /* Final layout rules deliberately follow the shared editor styles. */
 body.building-0>header{background:#202624!important;color:white!important;border-bottom:6px solid var(--template-accent)!important;min-height:110px}
 body.building-0 .hero{min-height:540px!important;padding:85px 7%!important}
 body.building-0 .hero h1{font-family:Arial,sans-serif!important;font-weight:900!important;text-transform:uppercase;max-width:760px;font-size:clamp(42px,7vw,92px)!important}
 body.building-0 .services-grid{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:0!important}
 body.building-0 .service-card{border-radius:0!important;box-shadow:none!important;border:1px solid var(--template-border)!important}
 body.building-1>header{flex-direction:column!important;justify-content:center!important;text-align:center;gap:12px!important;padding:32px 7%!important}
 body.building-1>header .header-business-card{width:auto!important;max-width:220px}
 body.building-1 .hero{padding:65px 9% 85px!important;gap:60px!important}
 body.building-1 .hero h1{font-family:Georgia,serif!important;font-style:italic!important;font-weight:400!important;font-size:clamp(42px,6vw,78px)!important}
 body.building-1 .services-section>h2,body.building-1 .services-section>.eyebrow,body.building-1 .services-section>.template-section-marker{display:block;text-align:center}
 body.building-1 .services-grid{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:32px!important;max-width:1000px;margin:auto}
 body.building-1 .service-card{border-radius:80px 80px 12px 12px!important;padding:35px!important;text-align:center}
 body.building-1 .service-card:last-child:nth-child(odd){grid-column:1/-1;max-width:calc(50% - 16px);width:100%;justify-self:center}
 body.building-2>header{border-bottom:1px solid var(--template-text)!important;padding:20px 7%!important}
 body.building-2 .hero{display:flex!important;flex-direction:column!important;align-items:stretch!important;padding:65px 7%!important;gap:0!important}
 body.building-2 .hero h1{font-family:Arial,sans-serif!important;font-weight:400!important;font-size:clamp(48px,8vw,108px)!important;letter-spacing:-4px!important;max-width:none}
 body.building-2 .services-grid{display:flex!important;flex-direction:column!important;gap:0!important}
 body.building-2 .services-grid>.service-card{display:grid!important;grid-template-columns:50px minmax(120px,1fr) minmax(160px,1.3fr)!important;align-items:start!important;gap:28px!important;padding:35px 0!important;border:0!important;border-top:1px solid var(--template-text)!important;border-radius:0!important;box-shadow:none!important;background:transparent!important}
 body.building-2 .service-card>.service-copy{grid-column:3!important;text-align:left}
 body.building-2 .service-card.service-without-media>.service-copy{grid-column:2/4!important}
 body.building-2 .service-card>.premium-service-number{grid-column:1!important;grid-row:1;font:14px Arial!important}
 body.building-2 .service-card>.service-photo-frame,body.building-2 .service-card>.service-empty-photo{grid-column:2!important;grid-row:1}
 @media(max-width:760px){body.building-0 .services-grid,body.building-1 .services-grid{grid-template-columns:1fr!important}body.building-1 .service-card:last-child:nth-child(odd){max-width:none}body.building-0 .hero{min-height:0!important;padding:40px 6%!important}body.building-2 .services-grid>.service-card{grid-template-columns:25px 1fr!important;gap:16px!important}body.building-2 .service-card>.service-copy,body.building-2 .service-card.service-without-media>.service-copy{grid-column:2!important}body.building-2 .hero h1{letter-spacing:-2px!important}}
 body.building-0 section.realisations-section{background:#202624!important;color:#fff!important}body.building-0 section.services-section{background:#f3f1eb!important}body.building-1 section.services-section{background:var(--template-block)!important}body.building-1 section.realisations-section{background:var(--template-bg)!important}body.building-2 section.realisations-section{background:var(--template-block)!important}
 .template-awaiting-image{display:grid!important;grid-template-columns:1.1fr 1fr;gap:40px;align-items:center;min-height:400px}
 .template-empty-visual{position:relative;aspect-ratio:4/3;overflow:hidden;background:var(--template-border);border:1px solid var(--template-border)}
 .template-empty-visual span{position:absolute;inset:16% 15% 18%;background:var(--template-block);box-shadow:16px 16px 0 #0001}
 .template-empty-visual i{position:absolute;inset:35% 25% 25%;background:var(--template-accent);opacity:.5;border:12px solid var(--template-bg)}
 .template-empty-visual b{position:absolute;inset:0;background:linear-gradient(135deg,transparent 49.7%,#ffffff70 50%,transparent 50.3%),linear-gradient(25deg,transparent 55%,#0001 55.2%,transparent 55.4%)}
 .building-0 .template-empty-visual{clip-path:polygon(15% 0,100% 0,100% 100%,0 100%)}.building-1 .template-empty-visual{border-radius:150px 150px 8px 8px;aspect-ratio:3/4}.building-2 .template-awaiting-image{grid-template-columns:1fr}.building-2 .template-empty-visual{aspect-ratio:21/7}
 body.building-0 .template-awaiting-image{grid-template-columns:1fr!important}
 body.building-0 .template-awaiting-image .template-empty-visual{display:none}
 body.building-0 .hero h1{font-size:clamp(32px,5vw,80px)!important;overflow-wrap:normal!important;hyphens:none}
 @media(max-width:760px){.template-awaiting-image{grid-template-columns:1fr!important;gap:24px;min-height:0}.template-empty-visual,.building-1 .template-empty-visual,.building-2 .template-empty-visual{aspect-ratio:4/3;max-height:280px}}
 `;doc.head.append(style);return serializeRenderedPage(doc);
};
// A model changes the document composition, not just the shared color stylesheet.
// Rebuild the frame once on model changes instead of matching styles by position.
const refreshBeforeTemplateComposition=refreshPreviewWithoutBlink;
let lastAppliedTemplateComposition;
refreshPreviewWithoutBlink=function(){
 const model=state.companyStyle;const compositionKey=JSON.stringify([model,state.modernSignature||'',state.compositionSignature||'']);
 if(compositionKey!==lastAppliedTemplateComposition){
  lastAppliedTemplateComposition=compositionKey;
  previewScrollY=0;
  previewFrame.srcdoc=page();
  return;
 }
 refreshBeforeTemplateComposition();
 if(Number.isInteger(model)){
  const current=previewFrame.contentDocument;
  const desired=new DOMParser().parseFromString(page(),'text/html');
  if(current?.head){
   // Keep editor affordances, but replace generated styles as a complete ordered set.
   current.head.querySelectorAll('style:not(#service-selection-style):not(#preview-editor-tools-style)').forEach(node=>node.remove());
   desired.head.querySelectorAll('style').forEach(node=>current.head.append(current.importNode(node,true)));
  }
 }
};
render();update();
