function bindPreviewMediaZoom(){
  const doc=previewFrame.contentDocument;if(!doc)return;
  for(const frame of doc.querySelectorAll('.realisations-section iframe,.videos-section iframe,.service-info-dialog iframe')){
    if(frame.closest('.service-card-video-thumb,.preview-video-zoom-wrap'))continue;
    const holder=doc.createElement('div');holder.className='preview-video-zoom-wrap';holder.style.cssText='position:relative;display:inline-block;max-width:100%';frame.before(holder);holder.append(frame);
    const button=doc.createElement('button');button.type='button';button.className='preview-video-zoom-button';button.setAttribute('aria-label','Agrandir et lire la vidéo');button.style.cssText='position:absolute;inset:0;width:100%;height:100%;background:transparent;border:0;cursor:zoom-in';holder.append(button);
  }
  if(doc.previewMediaZoomBound)return;doc.previewMediaZoomBound=true;
  doc.addEventListener('click',event=>{
    const image=event.target.closest('.realisations-section img,.service-photo,.promotions-section img');
    if(image&&!image.closest('.photo-viewer')){event.preventDefault();event.stopImmediatePropagation();doc.defaultView.atelierOpenPhoto?.(image);return;}
    const media=event.target.closest('video,.preview-video-zoom-button');if(!media||media.closest('.preview-media-dialog'))return;
    const source=media.tagName==='VIDEO'?media:media.parentElement.querySelector('iframe');if(!source)return;
    event.preventDefault();event.stopImmediatePropagation();
    const dialog=doc.createElement('dialog');dialog.className='preview-media-dialog';dialog.setAttribute('aria-label','Vidéo agrandie');dialog.style.cssText='width:min(1000px,94vw);max-width:94vw;max-height:94dvh;padding:14px;border:0;border-radius:12px;background:#171717';
    const close=doc.createElement('button');close.textContent='×';close.setAttribute('aria-label','Fermer la vidéo');close.style.cssText='display:block;margin:0 0 10px auto;padding:6px 14px;font-size:24px';close.onclick=()=>dialog.close();
    const player=source.cloneNode(true);player.style.cssText='display:block;width:100%;height:auto;max-height:78dvh;aspect-ratio:16/9;object-fit:contain;border:0';
    if(player.tagName==='VIDEO'){source.pause();player.controls=true;player.currentTime=source.currentTime;}
    dialog.append(close,player);dialog.addEventListener('close',()=>{if(player.tagName==='VIDEO')player.pause();dialog.remove()});dialog.onclick=e=>{if(e.target===dialog)dialog.close()};doc.body.append(dialog);dialog.showModal();if(player.tagName==='VIDEO')player.play().catch(()=>{});
  },true);
}
previewFrame.addEventListener('load',bindPreviewMediaZoom);
const refreshBeforeMediaZoom=refreshPreviewWithoutBlink;
refreshPreviewWithoutBlink=function(){refreshBeforeMediaZoom();bindPreviewMediaZoom()};
bindPreviewMediaZoom();
