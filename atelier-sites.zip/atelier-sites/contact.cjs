const {contactConfig,sendCloudflareContact}=require('./cloudflare-contact.cjs');
const attempts=new Map();
async function handleContact(req,res,pathname){
 if(pathname==='/api/contact/config'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(contactConfig()));return true}if(pathname!=='/api/contact')return false;
 const reply=(status,message)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(message))};
 if(req.method!=='POST'){reply(405,{error:'Méthode non autorisée.'});return true}
 const origin=req.headers.origin;
 if(!origin||!['http://'+req.headers.host,'https://'+req.headers.host].includes(origin)){reply(403,{error:'Origine non autorisée.'});return true}
 if(process.env.CONTACT_PROVIDER!=='cloudflare'&&(!process.env.RESEND_API_KEY||!process.env.CONTACT_FROM||!process.env.CONTACT_TO)){reply(503,{error:'Resend non configuré sur le serveur : renseignez RESEND_API_KEY, CONTACT_FROM et CONTACT_TO.'});return true}
 const ip=req.socket.remoteAddress,now=Date.now();for(const [key,value]of attempts)if(now-value.time>3600000)attempts.delete(key);const limit=attempts.get(ip)||{time:now,count:0};if(limit.count>=5){reply(429,{error:'Trop de demandes. Réessayez dans une heure.'});return true}limit.count++;attempts.set(ip,limit);
 try{let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>20000){reply(413,{error:'Message trop volumineux.'});return true}}const data=JSON.parse(raw);if(data.website){reply(200,{ok:true});return true}if(typeof data.name!=='string'||!data.name.trim()||data.name.length>120||typeof data.email!=='string'||data.email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)||typeof data.message!=='string'||!data.message.trim()||data.message.length>10000){reply(400,{error:'Vérifiez votre nom, votre e-mail et votre message.'});return true}if(process.env.CONTACT_PROVIDER==='cloudflare'){await sendCloudflareContact(data);reply(200,{ok:true});return true}const response=await fetch('https://api.resend.com/emails',{method:'POST',signal:AbortSignal.timeout(15000),headers:{Authorization:'Bearer '+process.env.RESEND_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.CONTACT_FROM,to:[process.env.CONTACT_TO],reply_to:data.email,subject:'Formulaire de contact — '+data.name.replace(/[\r\n]/g,' '),text:data.message})});reply(response.ok?200:502,response.ok?{ok:true}:{error:'Le service d’envoi a refusé le message. Vérifiez la configuration Resend.'})}catch{reply(502,{error:'Envoi impossible pour le moment. Réessayez ou utilisez votre messagerie.'})}return true;
}
module.exports={handleContact};


