// Independent scroll reveal for each content section in the generated artisan site.
const imageRevealRenderBefore = render;
render = function () {
  imageRevealRenderBefore();
  if (tab !== 'blocks') return;

  for (const card of document.querySelectorAll('#editor .block')) {
    const block = state.blocks.find(item => item.id === card.dataset.blockId);
    const panel = card.querySelector('details');
    if (!block || !panel) continue;
    panel.querySelector('.image-reveal-setting')?.remove();

    const setting = document.createElement('section');
    setting.className = 'image-reveal-setting library-details';
    const heading = document.createElement('h3');
    heading.textContent = 'Animation des photos';
    const label = document.createElement('label');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = block.imageReveal !== false;
    checkbox.setAttribute('aria-label', 'Révéler les images au défilement dans cette rubrique');
    checkbox.addEventListener('change', () => {
      block.imageReveal = checkbox.checked;
      update();
    });
    label.append(checkbox, 'Révéler les photos quand on fait défiler la page');
    const hint = document.createElement('p');
    hint.className = 'hint';
    hint.textContent = 'Ce choix concerne seulement cette rubrique. Les autres gardent leur propre réglage.';
    setting.append(heading, label, hint);
    panel.prepend(setting);
  }

  const empty = document.querySelector('#editor .content-empty');
  if (empty) empty.textContent = 'Cliquez sur une rubrique dans la liste pour afficher ses réglages, dont l’animation de ses photos.';
};

const imageRevealPageBefore = page;
page = function () {
  const doc = parseRenderedPage(imageRevealPageBefore());
  let imageCount = 0;
  for (const block of state.blocks) {
    if (block.imageReveal === false) continue;
    const section = doc.getElementById('rubrique-' + block.id);
    if (!section) continue;
    section.querySelectorAll('img').forEach((image, index) => {
      image.classList.add('hopclic-scroll-image-reveal');
      image.style.setProperty('--image-reveal-delay', Math.min(index * 100, 400) + 'ms');
      imageCount++;
    });
  }

  if (!imageCount) return serializeRenderedPage(doc);
  const style = doc.createElement('style');
  style.textContent = `
    /* Images are visible by default; only hide them after the reveal observer is ready. */
    .hopclic-scroll-image-reveal.reveal-observer-ready:not(.is-revealed){clip-path:inset(0 0 100% 0);opacity:.82;transform:scale(1.035);transition:clip-path .9s cubic-bezier(.22,.75,.2,1) var(--image-reveal-delay,0ms),opacity .55s ease var(--image-reveal-delay,0ms),transform 1.1s cubic-bezier(.22,.75,.2,1) var(--image-reveal-delay,0ms);will-change:clip-path,transform}
    .hopclic-scroll-image-reveal.is-revealed{clip-path:inset(0);opacity:1;transform:scale(1)}
    @media(prefers-reduced-motion:reduce){.hopclic-scroll-image-reveal,.hopclic-scroll-image-reveal.is-revealed{clip-path:none;opacity:1;transform:none;transition:none;will-change:auto}}
  `;
  doc.head.append(style);
  const script = doc.createElement('script');
  script.textContent = `(()=>{const images=[...document.querySelectorAll('.hopclic-scroll-image-reveal')];if(matchMedia('(prefers-reduced-motion: reduce)').matches||!('IntersectionObserver' in window))return;let observer;try{observer=new IntersectionObserver(entries=>{for(const entry of entries){if(entry.isIntersecting){entry.target.classList.add('is-revealed');observer.unobserve(entry.target)}}},{threshold:.12,rootMargin:'0px 0px -7% 0px'});images.forEach(image=>{image.classList.add('reveal-observer-ready');observer.observe(image)})}catch(error){images.forEach(image=>image.classList.add('is-revealed'))}})();`;
  doc.body.append(script);
  return serializeRenderedPage(doc);
};

render();
update();

