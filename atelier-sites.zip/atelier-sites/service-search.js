const pageBeforeServiceSearch=page;
page=function(){
 const doc=parseRenderedPage(pageBeforeServiceSearch());
 for(const section of doc.querySelectorAll('.services-section')){
  const grid=section.querySelector('.services-grid');if(!grid)continue;
  const box=doc.createElement('div');box.className='service-search';
  box.innerHTML='<label>Rechercher une prestation<input type="search" placeholder="Ex. : salle de bain, carrelage…" aria-label="Rechercher une prestation" autocomplete="off"></label><p role="status" aria-live="polite" hidden></p>';
  grid.before(box);
  const script=doc.createElement('script');script.textContent=`(()=>{
   const root=document.currentScript.parentElement,box=root.querySelector('.service-search'),input=box.querySelector('input'),status=box.querySelector('[role=status]'),cards=[...root.querySelectorAll('.services-grid>.service-card')];
   const normalize=s=>String(s).normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
   const groups=[['sdb','bain','bains','douche','sanitaire'],['carrelage','carreleur','faience','faiencier'],['peinture','peintre'],['renovation','renover','renovations'],['plomberie','plombier'],['electricite','electricien']];
   input.addEventListener('input',()=>{
    const words=normalize(input.value).split(' ').filter(Boolean);let count=0;
    for(const card of cards){const content=normalize([card.querySelector('.service-copy')?.textContent||'',...[...card.querySelectorAll('img')].map(i=>i.alt)].join(' '));const tokens=content.split(' ');
     const match=words.every(word=>{const group=groups.find(g=>g.includes(word));return tokens.some(t=>t.includes(word))||(group&&group.some(term=>tokens.includes(term)))});
     card.hidden=!match;if(match)count++;
    }
    status.hidden=!words.length;status.textContent=count?count+' prestation'+(count>1?'s':'')+' trouvée'+(count>1?'s':''):'Aucune prestation trouvée. Essayez un autre mot.';
   });
  })();`;
  section.append(script);
 }
 const style=doc.createElement('style');style.textContent='.service-search{margin:20px 0}.service-search label{display:block;font:600 13px Arial}.service-search input{display:block;box-sizing:border-box;width:100%;max-width:520px;min-height:44px;margin-top:8px;padding:12px 16px;border:1px solid '+state.borderColor+';border-radius:10px;background:'+state.blockBackground+';color:'+state.textColor+';font:16px Arial}.service-search input:focus{outline:2px solid '+state.accent+';outline-offset:2px}.service-search p{font:13px Arial}.services-grid>.service-card[hidden]{display:none!important}';doc.head.append(style);
 return serializeRenderedPage(doc);
};
update();
