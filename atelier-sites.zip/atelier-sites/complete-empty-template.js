// Restore the complete layout without restoring example content or imported media.
function completeEmptyTemplate(){
  for(const source of defaults.blocks){
    let block=state.blocks.find(item=>item.type===source.type);
    if(!block){block={...structuredClone(source),id:crypto.randomUUID(),title:'',text:'',photos:[],visible:false};state.blocks.push(block);}
    if(block.visible===undefined)block.visible=false;
    if(block.type==='services'&&!block.text.trim())block.text='|\n|\n|';
  }
}
if(CLIENT&&!localStorage.getItem(KEY+'-complete-empty-v1')){
  completeEmptyTemplate();
  localStorage.setItem(KEY+'-complete-empty-v1','1');
  render();update();
}
const startEmptyBeforeCompleteTemplate=startEmptySite;
startEmptySite=async function(){await startEmptyBeforeCompleteTemplate();completeEmptyTemplate();render();update()};
function showTemplateGuidance(){
  const doc=previewFrame.contentDocument;if(!doc?.body)return;
  doc.querySelector('#template-guidance-style')?.remove();if(doc.querySelector('#creation-welcome'))return;
  const style=doc.createElement('style');style.id='template-guidance-style';
  style.textContent=`body>header:has(strong:empty):not(:has(.header-business-card)){display:flex!important}body>header strong:empty:before{content:'Votre entreprise';opacity:.45}body>header small:empty:before{content:'Votre métier';opacity:.5}.hero h1:empty:before{content:'Votre titre de présentation';opacity:.4}.hero>p:empty:before{content:'Cliquez ici pour présenter votre activité.';opacity:.65}.services-section>h2:empty:before{content:'Nos prestations'}.realisations-section>h2:empty:before{content:'Nos réalisations'}.zone>h2:empty:before{content:'Zone d’intervention et horaires'}.contact>h2:empty:before{content:'Contactez-nous'}.service-copy h3:empty{display:block!important}.service-copy h3:empty:before{content:'Titre de la prestation';opacity:.4}body>section:not([class])>h2:empty:before{content:'Votre entreprise, votre savoir-faire';opacity:.4}`;
  doc.head.append(style);
}
previewFrame.addEventListener('load',showTemplateGuidance);
const refreshBeforeTemplateGuidance=refreshPreviewWithoutBlink;
refreshPreviewWithoutBlink=function(){refreshBeforeTemplateGuidance();showTemplateGuidance()};
refreshPreviewWithoutBlink();
