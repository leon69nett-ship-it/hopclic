function prepareSiteSEO(site){
 const clean=value=>String(value||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
 const shorten=(value,max)=>{if(value.length<=max)return value;const cut=value.slice(0,max-1);return cut.slice(0,Math.max(cut.lastIndexOf(' '),Math.floor(max*.7)))+'…'};
 const name=clean(site.name),trade=clean(site.trade),city=clean(site.city);
 const activity=[trade,city].filter(Boolean).join(' · ');
 const title=shorten([activity,name].filter(Boolean).join(' — '),150);
 const intro=(site.blocks||[]).find(b=>b.visible&&b.type==='intro'&&clean(b.text));
 const services=[...new Set((site.blocks||[]).filter(b=>b.visible&&b.type==='services').flatMap(b=>String(b.text||'').split('\n').map(line=>clean(line.split('|')[0]))).filter(Boolean))].slice(0,3);
 const detail=intro?clean(intro.text):services.length?'Prestations : '+services.join(', ')+'.':'';
 const description=shorten([ [name,activity].filter(Boolean).join(' — '),detail].filter(Boolean).join('. ').replace(/\.\./g,'.'),300);
 return {title,description,shareTitle:title,shareDescription:description};
}
const validateBeforeAutoSEO=validate;validate=function(value){const result=validateBeforeAutoSEO(value);result.seo.auto=value.seo?.auto===true||(value.seo?.auto!==false&&!['title','description','shareTitle','shareDescription'].some(k=>String(value.seo?.[k]||'').trim()));return result};
function refreshAutoSEO(){state.seo??={};if(state.seo.auto===undefined)state.seo.auto=!['title','description','shareTitle','shareDescription'].some(k=>String(state.seo[k]||'').trim());if(state.seo.auto)Object.assign(state.seo,prepareSiteSEO(state));}
const updateBeforeAutoSEO=update;update=function(){refreshAutoSEO();updateBeforeAutoSEO()};
const pageBeforeAutoSEO=page;page=function(){refreshAutoSEO();return pageBeforeAutoSEO()};
const renderBeforeAutoSEO=render;render=function(){refreshAutoSEO();renderBeforeAutoSEO();if(tab!=='buttons')return;const panel=document.querySelector('.seo-settings');if(!panel)return;
 const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.checked=state.seo.auto===true;label.append(check,'Préparer automatiquement le SEO à partir de mon site');
 check.onchange=()=>{state.seo.auto=check.checked;update();render()};
 const note=document.createElement('p');note.className='hint';note.textContent='Le titre, la description et les textes de partage suivent votre nom, votre métier, votre secteur et vos contenus visibles. Gratuit, sans appel IA. Relisez les exemples avant publication. Modifier un de ces textes désactive le mode automatique.';
 panel.querySelector('h2').after(label,note);
 for(const input of panel.querySelectorAll('input:not([type=checkbox]),textarea')){if(input.type==='url')continue;input.addEventListener('input',()=>{state.seo.auto=false;check.checked=false},{capture:true});}
};
refreshAutoSEO();render();update();
