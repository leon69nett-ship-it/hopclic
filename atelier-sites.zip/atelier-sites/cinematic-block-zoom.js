const renderBeforeCinematicZoom=render;
render=function(){renderBeforeCinematicZoom();if(tab!=='design')return;const select=document.querySelector('[aria-label="Mouvement des blocs"]');if(!select)return;const cinema=select.querySelector('option[value="zoom"]');if(cinema)cinema.textContent='Cinéma'};
const pageBeforeCinematicZoom=page;
page=function(){const doc=parseRenderedPage(pageBeforeCinematicZoom());if(!['zoom','zoomout','immersive'].includes(state.blockMotion))return serializeRenderedPage(doc);
const name=state.blockMotion==='zoom'?'cinematic-approach':state.blockMotion==='zoomout'?'cinematic-reveal':'cinematic-soft';
const style=doc.createElement('style');style.id='cinematic-block-zoom';style.textContent=`
 @supports(animation-timeline:view()){@media(prefers-reduced-motion:no-preference){body>.motion-site-block:not(.boundary-stack){transform-origin:50% 70%;animation:${name} linear both!important;animation-timeline:view()!important;animation-range:entry 0% entry 95%!important;backface-visibility:hidden}}}
 @keyframes cinematic-approach{0%{scale:.9;translate:0 44px;transform:perspective(1400px) rotateX(4deg);opacity:.6}55%{opacity:1}100%{scale:1;translate:0 0;transform:perspective(1400px) rotateX(0deg);opacity:1}}
 @keyframes cinematic-reveal{0%{scale:1.08;translate:0 24px;transform:perspective(1400px) rotateX(-3deg);opacity:.65}60%{opacity:1}100%{scale:1;translate:0 0;transform:perspective(1400px) rotateX(0deg);opacity:1}}
 @keyframes cinematic-soft{from{scale:.96;translate:0 22px;transform:perspective(1400px) rotateX(2deg);opacity:.75}to{scale:1;translate:0 0;transform:perspective(1400px) rotateX(0deg);opacity:1}}
 @media(max-width:760px){@keyframes cinematic-approach{from{scale:.98;translate:0 12px;opacity:.85}to{scale:1;translate:0 0;opacity:1}}@keyframes cinematic-reveal{from{scale:1.02;translate:0 8px;opacity:.85}to{scale:1;translate:0 0;opacity:1}}@keyframes cinematic-soft{from{scale:.99;translate:0 8px;opacity:.9}to{scale:1;translate:0 0;opacity:1}}}
 @media(prefers-reduced-motion:reduce){body>.motion-site-block{animation:none!important;transform:none!important;scale:none!important;translate:none!important;opacity:1!important}}
 @media print{body>.motion-site-block{animation:none!important;transform:none!important;scale:none!important;translate:none!important;opacity:1!important}}
 `;doc.head.append(style);return serializeRenderedPage(doc)};render();update();
