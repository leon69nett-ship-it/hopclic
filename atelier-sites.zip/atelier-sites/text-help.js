(() => {
  const el=(tag,text)=>{const node=document.createElement(tag);if(text)node.textContent=text;return node;};
  function attach(input,caption,onApply){
    if(input.dataset.aiHelpAttached)return;input.dataset.aiHelpAttached='true';
    const button=el('button','✨ Améliorer');button.type='button';button.className='text-help-button';const heading=el('span');heading.className='text-help-heading';
    if(input.parentElement.tagName==='LABEL'){const parent=input.parentElement;for(const node of [...parent.childNodes]){if(node===input)break;heading.append(node);}heading.append(button);parent.insertBefore(heading,input);}
    else{const label=input.previousElementSibling;if(label?.tagName==='LABEL'){label.before(heading);heading.append(label,button);}else{heading.append(el('span',caption),button);input.before(heading);}}
    button.onclick=()=>{
      const dialog=el('dialog');dialog.className='text-help-dialog';dialog.append(el('h2','Aide IA — '+caption));
      const note=el('p','Écrivez quelques idées, puis cliquez sur Générer. Relisez la proposition de l’IA et cliquez sur Appliquer si elle vous convient.');note.className='small';dialog.append(note);
      const draft=el('textarea');draft.value=input.value;draft.placeholder='Votre texte ou quelques mots pour commencer';draft.maxLength=3000;dialog.append(el('label','Texte ou idées'),draft);
      const task=el('select');for(const name of ['Proposer un texte','Corriger les fautes','Reformuler','Raccourcir','Donner plus envie']){const option=el('option',name);task.append(option);}dialog.append(el('label','Que souhaitez-vous faire ?'),task);
      const tone=el('select');for(const name of ['Accueillant','Clair et rassurant','Professionnel'])tone.append(el('option',name));tone.value='Professionnel';dialog.append(el('label','Ton'),tone);
      const demo=new URLSearchParams(location.search).get('offre')==='demo';const password=el('input');password.type='password';password.autocomplete='current-password';password.value=demo?'':document.getElementById('password')?.value||'';if(demo)dialog.append(el('p','Essai : 5 demandes par jour et par connexion Internet. Votre brouillon reste dans ce navigateur.'));dialog.append(el('label',demo?'Code de test pour l’aide IA':'Mot de passe administrateur ou code de test'),password);
      const status=el('p');status.setAttribute('role','status');dialog.append(status);
      const output=el('textarea');output.placeholder='La proposition apparaîtra ici';output.setAttribute('aria-label','Proposition IA');dialog.append(output);
      const actions=el('div');actions.className='toolbar';const generate=el('button','Générer'),apply=el('button','Appliquer'),close=el('button','Fermer');apply.disabled=true;actions.append(generate,apply,close);dialog.append(actions);
      generate.onclick=async()=>{if(!draft.value.trim()){status.textContent='Indiquez un texte ou quelques idées.';return;}generate.disabled=true;apply.disabled=true;status.textContent='Préparation de la proposition…';try{const response=await fetchLibraryAI('/api/text-help',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+password.value},body:JSON.stringify({text:draft.value,task:task.value,tone:tone.value,field:caption})});let result;try{result=await response.json()}catch{throw Error('Le serveur ne propose pas encore l’aide IA texte. Relancez le serveur après configuration Cloudflare.')} if(!response.ok)throw Error(result.error||'IA indisponible.');if(typeof result.text!=='string'||!result.text.trim())throw Error('Aucune proposition reçue.');output.value=result.text;apply.disabled=false;status.textContent='Relisez la proposition avant de l’appliquer.';}catch(error){status.textContent=error.message;}finally{generate.disabled=false;}};
      apply.onclick=()=>{input.value=output.value;onApply?onApply(output.value):input.dispatchEvent(new Event('input',{bubbles:true}));dialog.close();};close.onclick=()=>dialog.close();dialog.addEventListener('close',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
    };
  }
  window.TextHelp={attach};
})();

const renderBeforeTextHelp=render;render=function(){renderBeforeTextHelp();for(const label of $('#editor').querySelectorAll('.service-item-fields label')){if(label.firstChild?.textContent!=='Contenu de la fiche explicative')continue;const input=label.querySelector('textarea');if(input&&!label.querySelector('.text-help-button'))TextHelp.attach(input,'Texte')}};const serviceFieldsBeforeTextHelp=addServiceDetailsFields;addServiceDetailsFields=function(parent,block,index){serviceFieldsBeforeTextHelp(parent,block,index);for(const label of parent.querySelectorAll('label'))if(label.firstChild?.textContent==='Contenu de la fiche explicative'){const input=label.querySelector('textarea');if(input&&!label.querySelector('.text-help-button'))TextHelp.attach(input,'Texte')}};render();

