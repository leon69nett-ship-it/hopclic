function mergeRealisationBlocks(){
 const galleries=state.blocks.filter(block=>block.type==='gallery');if(galleries.length<2)return false;
 const primary=galleries[0];
 primary.galleryPhotoIds=galleries.some(block=>!Array.isArray(block.galleryPhotoIds))?null:[...new Set(galleries.flatMap(block=>block.galleryPhotoIds))];
 const seen=new Set();primary.galleryVideos=galleries.flatMap(block=>block.galleryVideos||[]).filter(video=>{const key=video.libraryId||video.videoUrl||video.videoIframe;if(!key||seen.has(key))return false;seen.add(key);return true});
 const photos=new Set(primary.photos||[]);for(const block of galleries.slice(1))for(const photo of block.photos||[])if(photo&&!photos.has(photo)){photos.add(photo);(primary.photos??=[]).push(photo)}
 primary.visible=galleries.some(block=>block.visible);primary.menuLabel='Réalisations';
 const removed=new Set(galleries.slice(1).map(block=>block.id));state.blocks=state.blocks.filter(block=>!removed.has(block.id));
 if(removed.has(selectedBlockId))selectedBlockId=primary.id;
 return true;
}
Promise.resolve(window.photoLibraryReady).then(()=>{
 const marker=KEY+'-merged-realisations-168';if(localStorage.getItem(marker))return;
 if(mergeRealisationBlocks()){localStorage.setItem(marker,'1');update();render();document.querySelector('#status').textContent='Réalisations regroupées : photos et vidéos conservées.'}
});
