(()=>{
  const style=document.createElement('style');
  style.id='hopclic-palette-paint-splash';
  style.textContent=`
    html body.hopclic-landing .feature-palette-icon{overflow:visible!important;isolation:isolate}
    html body.hopclic-landing .feature-palette-icon::before,html body.hopclic-landing .feature-palette-icon::after{display:none!important;content:none!important}
    html body.hopclic-landing .feature-palette-icon .feature-palette-original{display:inline-block;position:relative;z-index:2;transition:opacity .22s ease,transform .32s cubic-bezier(.2,.7,.2,1);transform-origin:center}
    html body.hopclic-landing .feature-palette-icon .feature-paint-splash{position:absolute;z-index:3;top:50%;left:50%;width:38px;height:48px;object-fit:contain;opacity:0;transform:translate(-50%,-50%) scale(.18) rotate(-10deg);pointer-events:none;filter:drop-shadow(0 1px 1px #64351c18)}
    html body.hopclic-landing .concept-feature-grid>div:hover .feature-palette-original,html body.hopclic-landing .concept-feature-grid>div:focus-within .feature-palette-original{opacity:0;transform:scale(.55) rotate(-12deg)}
    html body.hopclic-landing .concept-feature-grid>div:hover .feature-paint-splash,html body.hopclic-landing .concept-feature-grid>div:focus-within .feature-paint-splash{animation:hopclic-palette-replace .42s cubic-bezier(.18,.72,.2,1) forwards}
    @keyframes hopclic-palette-replace{0%{opacity:0;transform:translate(-50%,-50%) scale(.2) rotate(-14deg)}70%{opacity:1;transform:translate(-50%,-50%) scale(1.13) rotate(4deg)}100%{opacity:1;transform:translate(-50%,-50%) scale(1) rotate(0)}}
    @media(prefers-reduced-motion:reduce){html body.hopclic-landing .feature-palette-icon .feature-paint-splash{display:none!important}html body.hopclic-landing .feature-palette-icon .feature-palette-original{transition:none!important}}
  `;
  document.head.append(style);
  document.querySelectorAll('body.hopclic-landing .feature-palette-icon').forEach(icon=>{
    if(icon.querySelector('.feature-paint-splash'))return;
    const original=document.createElement('span');
    original.className='feature-palette-original';
    original.setAttribute('aria-hidden','true');
    original.textContent=icon.textContent.trim()||'🎨';
    icon.replaceChildren(original);
    const splash=document.createElement('img');
    splash.className='feature-paint-splash';
    splash.setAttribute('aria-hidden','true');
    icon.append(splash);
    splash.src='identity-paint-splash.png?v=1';
    splash.alt='';
  });
})();
