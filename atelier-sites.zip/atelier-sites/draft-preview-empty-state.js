// Explain the empty client preview when no content sections have been enabled.
function syncDraftPreviewEmptyState() {
  const doc = previewFrame.contentDocument;
  if (!doc?.body) return;
  let message = doc.querySelector('.draft-preview-empty-state');
  const hasVisibleBlock = state.blocks.some(block => block.visible !== false);
  if (hasVisibleBlock) {
    message?.remove();
    return;
  }
  if (message) return;
  message = doc.createElement('main');
  message.className = 'draft-preview-empty-state';
  message.setAttribute('role', 'status');
  message.innerHTML = '<strong>Votre aperçu est prêt à être composé.</strong><span>Choisissez « Accueil » ou une autre rubrique dans le panneau pour l’afficher ici.</span>';
  const style = doc.createElement('style');
  style.textContent = '.draft-preview-empty-state{min-height:70vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:36px;text-align:center;background:#fffaf5;color:#38281f;font:16px/1.55 Arial,sans-serif}.draft-preview-empty-state strong{font-size:clamp(20px,3vw,28px)}.draft-preview-empty-state span{max-width:440px;color:#604b3f}';
  doc.head.append(style);
  doc.body.append(message);
}

const refreshBeforeDraftEmptyState = refreshPreviewWithoutBlink;
refreshPreviewWithoutBlink = function () {
  try {
    refreshBeforeDraftEmptyState();
    syncDraftPreviewEmptyState();
  } catch (error) {
    console.error('Actualisation de l’aperçu impossible :', error);
    const status = document.querySelector('#status');
    if (status) status.textContent = 'L’aperçu garde sa dernière version affichée. Réessayez après avoir vérifié votre connexion.';
  }
};
previewFrame.addEventListener('load', syncDraftPreviewEmptyState);
syncDraftPreviewEmptyState();
