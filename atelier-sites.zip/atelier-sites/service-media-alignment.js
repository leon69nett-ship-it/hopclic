const pageBeforeMediaAlignment=page;
page=function(){
 const doc=parseRenderedPage(pageBeforeMediaAlignment());
 for(const photo of doc.querySelectorAll('.service-card>.service-photo,.service-card>.service-media-stack>.service-photo')){
  const frame=doc.createElement('div');frame.className='service-photo-frame';photo.before(frame);frame.append(photo);
 }
 const style=doc.createElement('style');style.textContent=`
 .services-grid{align-items:stretch}
 .service-card{min-width:0}
 .service-card:not(.photo-side):not(.service-without-media){display:flex;flex-direction:column}
 .service-card:not(.photo-side)>.service-copy{flex:1;display:flex;flex-direction:column}
 .service-card:not(.photo-side)>.service-copy>.service-info-button{align-self:flex-start;margin-top:auto}
 .service-card>.service-photo-frame,.service-card>.service-media-stack>.service-photo-frame,
 .service-card>.service-video,.service-card>.service-media-stack>.service-video{
 width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;max-height:none!important;aspect-ratio:16/9;margin:0 0 16px!important;border-radius:8px;overflow:hidden;box-sizing:border-box;position:relative;flex-shrink:0
 }
 .service-card .service-photo-frame>.service-photo{display:block;position:absolute;inset:0;width:100%!important;max-width:none!important;height:100%!important;max-height:none!important;margin:0!important;object-fit:cover!important;transform:none!important}
 .service-card .service-video .service-card-video-thumb,
 .service-card .service-video .video-presentation-card,
 .service-card .service-video .video-presentation-media{position:absolute;inset:0;width:100%!important;height:100%!important;max-height:none!important;margin:0!important;padding:0!important;min-width:0}
 .service-card .service-video video,.service-card .service-video iframe{display:block;position:absolute;inset:0;width:100%!important;height:100%!important;max-height:none!important;object-fit:contain!important;transform:none!important;border:0;background:#171717}
 .service-card>.service-media-stack{align-self:start;width:100%;gap:0}
 .service-card.photo-side{align-items:start}
 .service-card>.service-empty-photo{box-sizing:border-box;width:100%;height:auto!important;min-height:0!important;aspect-ratio:16/9;margin:0 0 16px!important}
 `;
 doc.head.append(style);return serializeRenderedPage(doc);
};
update();
