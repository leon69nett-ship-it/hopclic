// Redimensionnement des blocs et déplacement du menu dans le rendu du constructeur.
(() => {
  const clamp = (value, min, max, fallback = 0) => Math.min(max, Math.max(min, Number.isFinite(Number(value)) ? Number(value) : fallback));
  const cleanSize = size => ({
    width: Number.isFinite(Number(size?.width)) && Number(size.width) > 0 ? clamp(size.width, 240, 2000) : 0,
    height: Number.isFinite(Number(size?.height)) && Number(size.height) > 0 ? clamp(size.height, 160, 1800) : 0
  });
  const validateBeforeLayoutControls = validate;
  validate = function (saved) {
    const result = validateBeforeLayoutControls(saved);
    result.railMenuX = clamp(saved?.railMenuX, -500, 500, 0);
    result.railMenuY = clamp(saved?.railMenuY, -900, 900, 0);
    result.blocks = result.blocks.map((block, index) => ({
      ...block,
      renderSize: cleanSize(saved?.blocks?.[index]?.renderSize)
    }));
    return result;
  };
  state.railMenuX = clamp(state.railMenuX, -500, 500, 0);
  state.railMenuY = clamp(state.railMenuY, -900, 900, 0);
  state.blocks.forEach(block => { block.renderSize = cleanSize(block.renderSize); });

  const pageBeforeLayoutControls = page;
  page = function () {
    const doc = parseRenderedPage(pageBeforeLayoutControls());
    const rules = [];
    const visibleBlocks = state.blocks.filter(block => block.visible);
    const sections = [...doc.querySelectorAll('body>section:not(.business-card)')];
    sections.forEach((section, index) => {
      const block = visibleBlocks[index];
      if (block) section.dataset.editorBlock = String(block.id);
    });
    for (const section of sections) {
      const block = visibleBlocks.find(item => String(item.id) === section.dataset.editorBlock);
      if (!block) continue;
      const size = cleanSize(block?.renderSize);
      if (size.width) rules.push(`body>section[data-editor-block="${block.id}"]{width:${size.width}px!important;max-width:100%!important}`);
      if (size.height) rules.push(`body>section[data-editor-block="${block.id}"]{min-height:${size.height}px!important}`);
    }
    if (state.blockPresentation === 'left-rail') {
      rules.push(`body[data-block-presentation="left-rail"]>header nav.site-menu{transform:translate(${state.railMenuX}px,${state.railMenuY}px)!important}`);
    }
    if (rules.length) {
      const style = doc.createElement('style');
      style.id = 'saved-preview-layout-controls';
      style.textContent = rules.join('\n');
      doc.head.append(style);
    }
    return serializeRenderedPage(doc);
  };

  let active = null;
  let dragged = false;
  const controlStyle = `
    .preview-menu-grip{position:absolute!important;top:-13px!important;right:4px!important;z-index:2147483003!important;display:flex!important;align-items:center!important;justify-content:center!important;min-width:36px!important;height:28px!important;padding:0 8px!important;border:2px solid #fff!important;border-radius:7px!important;background:#8e3d25!important;color:#fff!important;font:700 16px/1 Arial!important;box-shadow:0 2px 8px #2b1b1670!important;cursor:move!important;touch-action:none!important}
    body[data-block-presentation="left-rail"]>header nav.site-menu{position:relative!important}
  `;

  function bindPreviewLayoutControls() {
    const doc = previewFrame.contentDocument;
    if (!doc?.body || doc.previewLayoutControlsBound) return;
    doc.previewLayoutControlsBound = true;
    const style = doc.createElement('style');
    style.textContent = controlStyle;
    doc.head.append(style);

    const makeHandle = (className, label, text) => {
      const handle = doc.createElement('span');
      handle.className = className;
      handle.setAttribute('role', 'button');
      handle.setAttribute('tabindex', '0');
      handle.setAttribute('aria-label', label);
      handle.title = label;
      handle.textContent = text;
      return handle;
    };
    if (doc.body.dataset.blockPresentation === 'left-rail') {
      const nav = doc.querySelector('body>header nav.site-menu');
      if (nav && !nav.querySelector(':scope>.preview-menu-grip')) nav.prepend(makeHandle('preview-menu-grip', 'Déplacer le menu dans la colonne de gauche', '↕'));
    }

    doc.addEventListener('pointerdown', event => {
      const grip = event.target.closest('.preview-menu-grip');
      if (!grip) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      dragged = false;
      const target = grip.closest('.site-menu');
      if (!target) return;
      const rect = target.getBoundingClientRect();
      active = {
        type: 'menu', target, startX: event.clientX, startY: event.clientY,
        x: state.railMenuX || 0, y: state.railMenuY || 0
      };
      target.setPointerCapture?.(event.pointerId);
      active.pointerId = event.pointerId;
    }, true);

    doc.addEventListener('pointermove', event => {
      if (!active || event.pointerId !== active.pointerId) return;
      event.preventDefault();
      dragged ||= Math.abs(event.clientX - active.startX) > 2 || Math.abs(event.clientY - active.startY) > 2;
      state.railMenuX = clamp(active.x + event.clientX - active.startX, -500, 500, active.x);
      state.railMenuY = clamp(active.y + event.clientY - active.startY, -900, 900, active.y);
      active.target.style.setProperty('transform', `translate(${state.railMenuX}px,${state.railMenuY}px)`, 'important');
    }, true);

    const finish = event => {
      if (!active || (event.pointerId !== undefined && event.pointerId !== active.pointerId)) return;
      const drag = active;
      active = null;
      if (!dragged) return;
      update();
    };
    doc.addEventListener('pointerup', finish, true);
    doc.addEventListener('pointercancel', finish, true);
  }

  previewFrame.addEventListener('load', bindPreviewLayoutControls);
  const refreshBeforePreviewLayoutControls = refreshPreviewWithoutBlink;
  refreshPreviewWithoutBlink = function () {
    refreshBeforePreviewLayoutControls();
    bindPreviewLayoutControls();
  };
  bindPreviewLayoutControls();
})();
