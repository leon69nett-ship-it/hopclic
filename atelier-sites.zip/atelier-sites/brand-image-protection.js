// Brand artwork is an image asset, so site palettes and visual effects must not recolor it.
const pageBeforeBrandImageProtection = page;
page = function () {
  const doc = parseRenderedPage(pageBeforeBrandImageProtection());
  const style = doc.createElement('style');
  style.id = 'brand-image-original-colors';
  style.textContent = `
    img.hopclic-logo, img.checkout-logo, img.header-business-card,
    .business-card img, img[data-brand-logo], img[alt*="logo HopClic" i] {
      filter: none !important;
      -webkit-filter: none !important;
      opacity: 1 !important;
      mix-blend-mode: normal !important;
      color: revert !important;
      forced-color-adjust: none;
    }
    img.hopclic-logo, img.checkout-logo, img[data-brand-logo], img[alt*="logo HopClic" i] {
      background: #fff !important;
      object-fit: contain !important;
    }
  `;
  doc.head.append(style);
  return serializeRenderedPage(doc);
};
