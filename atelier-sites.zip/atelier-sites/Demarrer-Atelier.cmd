@echo off
set "HOPCLIC_DIR=C:\Users\denis\Documents\Codex\2026-10-07\constructeur-sites-artisans\outputs\atelier-sites"
if not exist "%HOPCLIC_DIR%\server.cjs" (
  echo Dossier HopClic introuvable : %HOPCLIC_DIR%
  pause
  exit /b 1
)
cd /d "%HOPCLIC_DIR%"
echo Demarrage de HopClic. Gardez cette fenetre ouverte.
echo Ouvrez http://127.0.0.1:8786/?mode=client
node server.cjs
echo.
echo Le serveur est arrete.
pause
