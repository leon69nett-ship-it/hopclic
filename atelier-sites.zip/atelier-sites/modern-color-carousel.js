palettes.unshift(
 ['Prune & abricot',['#241c2b','#34283e','#fff2e8','#d0baca','#ffc399','#60485c']],
 ['Pétrole & cuivre',['#e8efea','#f7faf5','#193c3d','#5b7672','#a4472c','#bdd1c8']],
 ['Ivoire & vermillon',['#f6f1e7','#fffdf6','#292620','#70695e','#b63b24','#ded3c3']],
 ['Aubergine & pistache',['#f0efdd','#fcfbed','#35283a','#74637a','#67417d','#d5c9d8']],
 ['Nuit & safran',['#181c28','#252b3b','#fff6e6','#c1c6d6','#f4c36b','#454f68']],
 ['Brume & cerise',['#eee8ed','#fcf8fb','#382733','#796373','#a52d56','#dfc4d1']],
 ['Terracotta velours',['#f5e9df','#fff9f3','#392923','#806258','#a94730','#dfc2b2']],
 ['Pêche satin',['#fff0e6','#fffaf6','#432d29','#82635c','#b74f3c','#edcebe']],
 ['Sable & caramel',['#efe4d3','#fff9ee','#3a3025','#786854','#936024','#d8c5aa']],
 ['Argile rosée',['#f2e4e2','#fff8f5','#402c30','#806168','#a3455c','#ddbec5']],
 ['Olive & lin',['#eee9da','#faf8ef','#33382c','#69705b','#59683e','#cdd0b8']],
 ['Cacao crème',['#2b211e','#3b2d28','#fff3e2','#d2baaa','#efb785','#685046']]
);
palettes.push(
 ['Encre électrique',['#0c1222','#151e32','#f3f7ff','#b2bfd5','#73e4dc','#34425d']],
 ['Matcha studio',['#eef1de','#fafbed','#25372c','#5a6d59','#436c44','#ccd5bb']],
 ['Lilac futur',['#eeeaff','#faf8ff','#27213f','#655b80','#6341bc','#d4c9ee']],
 ['Orange cobalt',['#edf1ff','#ffffff','#172448','#556488','#244ecb','#c6d1ef']],
 ['Rose graphite',['#202025','#2c2b33','#fff4fa','#c9b9c7','#ffa5cb','#51434f']],
 ['Sable solaire',['#f2eadc','#fffaf0','#352f24','#756851','#926322','#ddcfb9']]
);
const renderBeforeModernColorCarousel=render;
render=function(){
 renderBeforeModernColorCarousel();if(tab!=='design')return;
 const grid=document.querySelector('#editor .palette-grid');if(!grid)return;
 grid.classList.add('modern-palette-track');grid.setAttribute('aria-label','Palettes de couleurs');
 grid.replaceChildren();
 for(const [name,c] of palettes){
  const b=document.createElement('button');b.type='button';b.className='modern-palette-card';
  const active=colorKeys.every((k,i)=>state[k].toLowerCase()===c[i].toLowerCase());b.setAttribute('aria-pressed',String(active));
  b.style.cssText=`--sample-bg:${c[0]};--sample-surface:${c[1]};--sample-text:${c[2]};--sample-accent:${c[4]}`;
  b.setAttribute('aria-label','Choisir la palette '+name);
  b.innerHTML=`<span class="palette-card-name">${esc(name)} ${active?'✓':''}</span><span class="swatches">${c.map(v=>`<i style="background:${v}"></i>`).join('')}</span>`;
  b.onclick=()=>applyPalette(c);grid.append(b);
 }
};
const modernPaletteStyle=document.createElement('style');modernPaletteStyle.textContent=`
 #editor .modern-palette-track{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;padding:5px 2px 12px;overflow:visible}
 #editor .modern-palette-card{display:grid;grid-template-columns:minmax(0,1fr);align-content:center;gap:10px;min-width:0;min-height:66px;padding:12px!important;text-align:left;white-space:normal;border-radius:14px!important;background:#fffaf5!important;color:#46332b!important;box-shadow:0 4px 12px #7c493b12;transition:box-shadow .2s,border-color .2s;border:1px solid #e5d4c8!important}
 #editor .modern-palette-card[aria-pressed=true]{border:2px solid var(--ui-accent)!important;box-shadow:0 0 0 3px color-mix(in srgb,var(--ui-accent) 15%,transparent)}
 .palette-card-name{display:block;margin:0;font-size:12px;line-height:1.25;font-weight:700;overflow-wrap:anywhere}#editor .modern-palette-card .swatches{display:flex;margin:0;gap:4px}#editor .modern-palette-card .swatches i{height:9px;flex:1;min-width:0;border-radius:4px}
 @media(max-width:380px){#editor .modern-palette-track{grid-template-columns:1fr}#editor .modern-palette-card{min-height:56px}}
 @media(prefers-reduced-motion:reduce){.modern-palette-card{transition:none}}
`;document.head.append(modernPaletteStyle);render();
