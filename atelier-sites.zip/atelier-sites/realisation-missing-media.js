const galleryBeforeMissingMedia=galleryPresentationMarkup;
galleryPresentationMarkup=function(block){
 const html=galleryBeforeMissingMedia(block);if(block.galleryMode==='slideshow')return html;
 const count=Math.max(1,Math.min(3,Number(block.galleryWindows)||3));
 const photos=galleryLibraryPhotos(block).length;
 const videos=(block.galleryVideos||[]).filter(reference=>{const video=reference.libraryId?(state.videoLibrary||[]).find(item=>item.id===reference.libraryId):reference;return video&&(videoSource(video.videoUrl)||videoIframeSource(video.videoIframe))}).length;
 const missing=Math.max(0,count-photos-videos);if(!missing)return html;
 const doc=new DOMParser().parseFromString(html,'text/html'),section=doc.querySelector('.realisations-section');if(!section)return html;
 const notice=doc.createElement('p');notice.className='realisation-missing-media';notice.setAttribute('role','status');
 notice.textContent=count+' '+(count===1?'fenêtre prévue':'fenêtres prévues')+' : il manque '+missing+' '+(missing===1?'photo ou vidéo':'photos ou vidéos')+'.';
 notice.style.cssText='padding:12px 14px;border:1px solid #d49135;border-radius:8px;background:#fff5df;color:#795013;font:14px/1.5 Arial,sans-serif';
 const grid=section.querySelector('.presentation-gallery');if(grid)grid.before(notice);else section.append(notice);return section.outerHTML;
};update();
