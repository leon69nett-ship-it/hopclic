// Valide automatiquement les dernières modifications après une courte pause.
(() => {
  const publishButton = document.querySelector('#publish');
  if (publishButton) {
    publishButton.textContent = '✓ Validation automatique';
    publishButton.title = 'Les dernières modifications sont enregistrées automatiquement.';
  }

  let timer;
  let saving = Promise.resolve();
  const schedule = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      saving = saving.then(async () => {
        if (window.photoLibraryReady) await window.photoLibraryReady.catch(() => {});
        const savedAt = String(Date.now());
        const snapshot = structuredClone(state);
        const photos = structuredClone(snapshot.photoLibrary || []);
        const localState = { ...snapshot, photoLibrary: [], videoLibrary: [] };
        try {
          localStorage.setItem(KEY, JSON.stringify(localState));
          localStorage.setItem(KEY + '-saved-at', savedAt);
          localStorage.setItem(PUBLISHED, JSON.stringify({ ...snapshot, photoLibrary: [] }));
          localStorage.setItem(PUBLISHED + '-saved-at', savedAt);
          if (typeof libraryStore === 'function') {
            await libraryStore(KEY, photos);
            await libraryStore(PUBLISHED, { photos, html: page() });
          }
          localStorage.removeItem(PUBLISHED + '-html');
          $('#status').textContent = 'Modifications validées et enregistrées automatiquement.';
        } catch {
          $('#status').textContent = 'Les réglages sont enregistrés, mais les photos n’ont pas pu être validées. Exportez une sauvegarde.';
        }
      }).catch(() => {});
    }, 850);
  };

  const previousUpdate = update;
  update = function () {
    previousUpdate();
    try {
      const savedAt = localStorage.getItem(KEY + '-saved-at') || String(Date.now());
      localStorage.setItem(PUBLISHED, JSON.stringify({ ...state, photoLibrary: [] }));
      localStorage.setItem(PUBLISHED + '-saved-at', savedAt);
    } catch {}
    schedule();
  };
})();
