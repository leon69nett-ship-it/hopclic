const pageBeforeBusinessCardLayout=page;
page=function(){
  const doc=parseRenderedPage(pageBeforeBusinessCardLayout());
  const header=doc.querySelector('body>header');
  if(header?.querySelector('.header-business-card')){
    header.classList.add('with-business-card');
    const style=doc.createElement('style');
    style.textContent=`body>header.with-business-card{justify-content:flex-start!important;gap:22px!important;flex-wrap:wrap}body>header.with-business-card>.header-business-card{flex:0 0 auto!important;width:180px!important;max-width:32%!important;height:auto!important;max-height:125px!important;object-fit:contain;margin:0!important}body>header.with-business-card>div:not(.site-menu){flex:1 1 180px!important;min-width:0}body>header.with-business-card strong{overflow-wrap:anywhere}body>header.with-business-card>.call{margin-left:auto}@media(max-width:760px){body>header.with-business-card{flex-direction:column!important;align-items:center!important;text-align:center;padding:24px 7%!important;gap:14px!important}body>header.with-business-card>.header-business-card{width:190px!important;max-width:85%!important;max-height:140px!important;margin:0 auto!important}body>header.with-business-card>div:not(.site-menu){flex:0 0 auto!important;width:100%}body>header.with-business-card>.call{margin:0 auto!important}}`;
    doc.head.append(style);
  }
  return serializeRenderedPage(doc);
};
refreshPreviewWithoutBlink();
