const renderBeforeOrganizedSignatures=render;
render=function(){
 renderBeforeOrganizedSignatures();if(tab!=='design')return;
 const panel=document.querySelector('#editor .modern-signatures');if(!panel)return;
 const cards=[...panel.querySelectorAll(':scope>article')];
 const groups=[['Élégant & épuré',['chrome','floating','museum','split']],['Créatif & expressif',['canvas','pop','digital','xxl','poster']],['Interactif & immersif',['spatial','doors','horizontal','creative']]];
 const current=modernSignatures.find(m=>m.id===state.modernSignature);
 const status=document.createElement('p');status.className='signature-selection-note';status.textContent=current?'Votre signature : '+current.name:'Choisissez un style, puis découvrez son aperçu.';panel.querySelector('.hint').after(status);
 groups.forEach(([title,ids],index)=>{
  const models=cards.filter(card=>ids.includes(modernSignatures.find(m=>m.name===card.querySelector('h3')?.textContent)?.id));if(!models.length)return;
  const group=document.createElement('details');group.className='signature-family';group.open=current?ids.includes(current.id):index===0;
  const summary=document.createElement('summary');summary.textContent=title+' · '+models.length+' modèles';group.append(summary);
  const list=document.createElement('div');list.className='signature-family-list';
  for(const card of models){const selected=card.querySelector('h3')?.textContent===current?.name;card.classList.toggle('signature-current',selected);card.querySelector('img').loading='lazy';list.append(card)}group.append(list);panel.append(group);
 });
 const reset=[...panel.children].find(e=>e.tagName==='BUTTON');if(reset)panel.append(reset);
};
const organizedSignatureStyle=document.createElement('style');organizedSignatureStyle.textContent=`
 .signature-selection-note{padding:12px 14px;border-radius:12px;background:color-mix(in srgb,var(--ui-accent) 9%,white);font-size:12px;font-weight:700}
 .signature-family{margin:12px 0;border:1px solid var(--ui-border);border-radius:16px;background:#fffaf5;overflow:hidden}.signature-family>summary{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:18px 14px;cursor:pointer;font-size:13px;font-weight:700;list-style:none}.signature-family>summary::after{content:'+';font-size:23px;font-weight:400}.signature-family[open]>summary::after{content:'−'}.signature-family>summary:focus-visible{outline:2px solid var(--ui-accent);outline-offset:-4px}
 .signature-family-list{padding:0 12px 12px}.signature-family-list article{margin:10px 0!important;background:white}.signature-family-list article>img{height:110px!important}.signature-family-list article>div{padding:12px!important}.signature-family-list h3{margin:0 0 8px}.signature-family-list .signature-current{border:2px solid var(--ui-accent)!important}.signature-family-list button{width:100%}
`;document.head.append(organizedSignatureStyle);render();
