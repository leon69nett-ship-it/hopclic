function contactConfig(){return {siteKey:process.env.TURNSTILE_SITE_KEY||'',configured:Boolean(process.env.CONTACT_PROVIDER==='cloudflare'&&process.env.CLOUDFLARE_ACCOUNT_ID&&process.env.CLOUDFLARE_EMAIL_API_TOKEN&&process.env.CONTACT_FROM&&process.env.CONTACT_TO&&process.env.TURNSTILE_SITE_KEY&&process.env.TURNSTILE_SECRET_KEY&&process.env.CONTACT_PUBLIC_HOSTNAME)}}
async function sendCloudflareContact(data){
 if(!contactConfig().configured)throw Error('Cloudflare et la protection anti-spam ne sont pas encore configurés.');
 if(typeof data.turnstileToken!=='string'||!data.turnstileToken||data.turnstileToken.length>2048)throw Error('Veuillez valider la protection anti-spam.');
 const verification=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',signal:AbortSignal.timeout(10000),body:new URLSearchParams({secret:process.env.TURNSTILE_SECRET_KEY,response:data.turnstileToken})});
 const check=await verification.json();if(!verification.ok||!check.success||check.hostname!==process.env.CONTACT_PUBLIC_HOSTNAME||check.action!=='contact')throw Error('Vérification anti-spam refusée. Réessayez.');
 const response=await fetch('https://api.cloudflare.com/client/v4/accounts/'+encodeURIComponent(process.env.CLOUDFLARE_ACCOUNT_ID)+'/email/sending/send',{method:'POST',signal:AbortSignal.timeout(15000),headers:{Authorization:'Bearer '+process.env.CLOUDFLARE_EMAIL_API_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.CONTACT_FROM,to:process.env.CONTACT_TO,subject:'Formulaire de contact — '+data.name.replace(/[\r\n]/g,' '),text:'Répondre à : '+data.email+'\n\n'+data.message})});
 const result=await response.json();if(!response.ok||result.success!==true||(!result.result?.delivered?.length&&!result.result?.queued?.length))throw Error('Le service d’envoi n’a pas accepté le message.');
}
module.exports={contactConfig,sendCloudflareContact};
