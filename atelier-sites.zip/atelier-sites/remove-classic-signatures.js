const renderBeforeRemoveClassicSignatures=render;
render=function(){renderBeforeRemoveClassicSignatures();if(tab==='design')document.querySelector('#editor .company-style-choices')?.remove()};render();
