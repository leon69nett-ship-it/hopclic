const {test}=require('node:test');const assert=require('node:assert/strict');
const {sendCloudflareContact,contactConfig}=require('./cloudflare-contact.cjs');
test('Cloudflare refuse les configurations et jetons invalides avant envoi',async()=>{
 const backup={...process.env},original=global.fetch;
 try{
  delete process.env.TURNSTILE_SECRET_KEY;
  assert.equal(contactConfig().configured,false);
  await assert.rejects(sendCloudflareContact({}),/configurés/);
  Object.assign(process.env,{CONTACT_PROVIDER:'cloudflare',CLOUDFLARE_ACCOUNT_ID:'test',CLOUDFLARE_EMAIL_API_TOKEN:'secret',CONTACT_FROM:'from@example.com',CONTACT_TO:'to@example.com',TURNSTILE_SITE_KEY:'public',TURNSTILE_SECRET_KEY:'secret',CONTACT_PUBLIC_HOSTNAME:'example.com'});
  let calls=0;global.fetch=async()=>{calls++;return {ok:true,json:async()=>({success:true,hostname:'wrong.example',action:'contact'})}};
  await assert.rejects(sendCloudflareContact({turnstileToken:'test'}),/refusée/);assert.equal(calls,1);
  global.fetch=async(url,options)=>{calls++;if(url.includes('siteverify'))return {ok:true,json:async()=>({success:true,hostname:'example.com',action:'contact'})};const payload=JSON.parse(options.body);assert.equal(payload.to,'to@example.com');return {ok:true,json:async()=>({success:true,result:{queued:['to@example.com']}})}};
  await sendCloudflareContact({turnstileToken:'test',name:'Client',email:'client@example.com',message:'Bonjour'});
 }finally{global.fetch=original;for(const key of Object.keys(process.env))if(!(key in backup))delete process.env[key];Object.assign(process.env,backup)}
});
