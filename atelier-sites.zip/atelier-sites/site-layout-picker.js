// Présentations globales des blocs proposées dans Design.
(() => {
  const layouts = [
    { id: 'centered', title: 'Centré', description: 'Blocs alignés dans une colonne équilibrée.' },
    { id: 'left-rail', title: 'Colonne à gauche', description: 'Logo et menu à gauche, en-tête du contenu en haut à droite.' },
    { id: 'right-rail', title: 'Colonne à droite', description: 'Navigation verticale à droite, contenu à gauche.' },
    { id: 'cards', title: 'Grille de blocs', description: 'Blocs présentés comme des cartes, en deux colonnes.' },
    { id: 'panorama', title: 'Grandes sections', description: 'Sections larges qui occupent toute la page.' }
  ];
  const validLayout = id => layouts.some(layout => layout.id === id) ? id : 'centered';
  const validMenuPresentation = mode => ['compact', 'static'].includes(mode) ? mode : 'bar';
  const railSettings = {
    railWidth: { initial: 280, min: 220, max: 420, step: 10, unit: 'px' },
    railCompanyHeight: { initial: 180, min: 120, max: 420, step: 10, unit: 'px' }
  };
  const clampRailSetting = (key, value) => {
    const setting = railSettings[key];
    return Math.min(setting.max, Math.max(setting.min, Number.isFinite(Number(value)) ? Number(value) : setting.initial));
  };
  function installScrollMenuAnimation(win) {
    const doc = win?.document;
    const header = doc?.querySelector('body>header');
    const nav = header?.querySelector('nav.site-menu');
    const toggle = header?.querySelector('.site-menu-toggle');
    if (!header || !nav || !toggle || doc.body.dataset.siteMenuPresentation !== 'bar' || header.scrollMenuAnimationBound) return;
    header.scrollMenuAnimationBound = true;
    const links = [...nav.querySelectorAll('a')];
    const threshold = 140;
    let phase = win.scrollY > threshold ? 'compact' : 'normal';
    let sequence = 0;
    let finishTimer = 0;
    let flightElement = null;
    let flightAnimation = null;
    const closeMenu = () => {
      header.classList.remove('menu-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Ouvrir le menu');
      toggle.textContent = '☰';
    };
    const stopAnimations = () => {
      for (const element of [...links, toggle]) for (const animation of element.getAnimations()) animation.cancel();
      flightAnimation?.cancel();
      flightAnimation = null;
      flightElement?.remove();
      flightElement = null;
      header.classList.remove('menu-flight-active');
    };
    const targetPoint = () => ({ x: win.innerWidth - 34, y: 34 });
    const formationPoint = () => {
      const rect = nav.getBoundingClientRect();
      return {
        x: Math.min(win.innerWidth - 36, Math.max(36, rect.left + rect.width / 2)),
        y: Math.min(win.innerHeight - 36, Math.max(36, rect.top + rect.height / 2))
      };
    };
    const gatherLinks = () => {
      const target = formationPoint();
      links.forEach((link, index) => {
        const rect = link.getBoundingClientRect();
        const dx = target.x - (rect.left + rect.width / 2);
        const dy = target.y - (rect.top + rect.height / 2);
        link.animate([
          { opacity: 1, transform: 'translate(0,0) scale(1)' },
          { opacity: .84, offset: .36, transform: `translate(${dx * .24}px,${dy * .24}px) scale(.88)` },
          { opacity: 0, transform: `translate(${dx}px,${dy}px) scale(.08) rotate(-12deg)` }
        ], { duration: 720, delay: Math.min(index * 55, 330), easing: 'cubic-bezier(.2,.75,.25,1)', fill: 'none' });
      });
      const destination = targetPoint();
      const dx = target.x - destination.x;
      const dy = target.y - destination.y;
      const distance = Math.hypot(dx, dy) || 1;
      const ux = dx / distance;
      const uy = dy / distance;
      const nx = -uy;
      const ny = ux;
      const loopRadius = Math.min(46, Math.max(18, distance * .08));
      const centerX = dx * .5;
      const centerY = dy * .5;
      const loopEntryX = centerX + ux * loopRadius;
      const loopEntryY = centerY + uy * loopRadius;
      const frames = [
        { opacity: 1, offset: 0, transform: `translate(${dx}px,${dy}px) scale(.78) rotate(-28deg)` },
        { opacity: 1, offset: .1, transform: `translate(${dx}px,${dy}px) scale(1) rotate(0)` },
        { opacity: 1, offset: .2, transform: `translate(${dx * .68}px,${dy * .68}px) scale(1) rotate(0)`, easing: 'cubic-bezier(.2,.75,.25,1)' },
        { opacity: 1, offset: .24, transform: `translate(${loopEntryX}px,${loopEntryY}px) scale(1) rotate(0)`, easing: 'cubic-bezier(.2,.75,.25,1)' }
      ];
      for (let step = 0; step <= 32; step++) {
        const angle = step * Math.PI / 16;
        const x = centerX + ux * loopRadius * Math.cos(angle) + nx * loopRadius * Math.sin(angle);
        const y = centerY + uy * loopRadius * Math.cos(angle) + ny * loopRadius * Math.sin(angle);
        frames.push({
          opacity: 1,
          offset: .24 + step * .014375,
          transform: `translate(${x}px,${y}px) scale(1) rotate(${step * 11.25}deg)`,
          easing: 'linear'
        });
      }
      frames.push(
        { opacity: 1, offset: .94, transform: `translate(${dx * .12}px,${dy * .12}px) scale(1) rotate(360deg)`, easing: 'cubic-bezier(.2,.75,.25,1)' },
        { opacity: 1, transform: 'translate(0,0) scale(1) rotate(360deg)' }
      );
      const toggleStyle = win.getComputedStyle(toggle);
      flightElement = toggle.cloneNode(true);
      flightElement.className = 'site-menu-toggle site-menu-flight';
      flightElement.removeAttribute('id');
      flightElement.removeAttribute('onclick');
      flightElement.tabIndex = -1;
      flightElement.setAttribute('aria-hidden', 'true');
      flightElement.style.cssText = `position:fixed;top:12px;right:12px;z-index:2147483003;display:${toggleStyle.display};align-items:${toggleStyle.alignItems};justify-content:${toggleStyle.justifyContent};width:${toggleStyle.width};height:${toggleStyle.height};min-width:${toggleStyle.minWidth};min-height:${toggleStyle.minHeight};box-sizing:${toggleStyle.boxSizing};padding:${toggleStyle.padding};border:${toggleStyle.border};border-radius:${toggleStyle.borderRadius};background:${toggleStyle.backgroundColor};color:${toggleStyle.color};box-shadow:${toggleStyle.boxShadow};font:${toggleStyle.font};pointer-events:none;transform-origin:center;will-change:transform,opacity`;
      doc.body.append(flightElement);
      header.classList.add('menu-flight-active');
      flightAnimation = flightElement.animate(frames, { duration: 1800, easing: 'cubic-bezier(.2,.75,.25,1)', fill: 'forwards' });
      flightAnimation.onfinish = () => {
        flightElement?.remove();
        flightElement = null;
        flightAnimation = null;
        header.classList.remove('menu-flight-active');
      };
    };
    const spreadLinks = () => {
      const target = targetPoint();
      links.forEach((link, index) => {
        const rect = link.getBoundingClientRect();
        const dx = target.x - (rect.left + rect.width / 2);
        const dy = target.y - (rect.top + rect.height / 2);
        link.animate([
          { opacity: 0, transform: `translate(${dx}px,${dy}px) scale(.12)` },
          { opacity: .82, offset: .35, transform: `translate(${dx * .38}px,${dy * .38}px) scale(.94)` },
          { opacity: 1, transform: 'translate(0,0) scale(1)' }
      ], { duration: 560, delay: Math.min(index * 45, 270), easing: 'cubic-bezier(.2,.75,.25,1)', fill: 'none' });
      });
      toggle.animate([
        { opacity: 1, transform: 'translate(0,0) scale(1)' },
        { opacity: 0, transform: 'translate(-20px,-24px) scale(.35) rotate(35deg)' }
      ], { duration: 380, easing: 'cubic-bezier(.2,.75,.25,1)', fill: 'none' });
    };
    const collapse = () => {
      if (phase === 'compact' || phase === 'collapsing') return;
      clearTimeout(finishTimer);
      stopAnimations();
      phase = 'collapsing';
      closeMenu();
      header.classList.remove('menu-scrolled', 'menu-transition-out');
      header.classList.add('menu-transition-in');
      gatherLinks();
      const current = ++sequence;
      finishTimer = win.setTimeout(() => {
        if (current !== sequence) return;
        header.classList.remove('menu-transition-in', 'menu-flight-active');
        if (win.scrollY > threshold) {
          header.classList.add('menu-scrolled');
          phase = 'compact';
        } else {
          phase = 'normal';
        }
      }, 1900);
    };
    const expand = () => {
      if (phase === 'normal' || phase === 'expanding') return;
      clearTimeout(finishTimer);
      stopAnimations();
      phase = 'expanding';
      header.classList.remove('menu-scrolled', 'menu-transition-in');
      header.classList.add('menu-transition-out');
      closeMenu();
      spreadLinks();
      const current = ++sequence;
      finishTimer = win.setTimeout(() => {
        if (current !== sequence) return;
        header.classList.remove('menu-transition-out');
        if (win.scrollY > threshold) collapse();
        else phase = 'normal';
      }, 820);
    };
    const update = () => {
      if (win.scrollY > threshold) collapse();
      else expand();
    };
    header.classList.toggle('menu-scrolled', phase === 'compact');
    win.addEventListener('scroll', update, { passive: true });
  }

  const validateBeforeBlockPresentation = validate;
  validate = function (saved) {
    const result = validateBeforeBlockPresentation(saved);
    result.blockPresentation = validLayout(saved?.blockPresentation);
    result.siteMenuPresentation = validMenuPresentation(saved?.siteMenuPresentation ?? state.siteMenuPresentation);
    for (const [key, setting] of Object.entries(railSettings)) result[key] = clampRailSetting(key, saved?.[key] ?? setting.initial);
    return result;
  };
  state.blockPresentation = validLayout(state.blockPresentation);
  state.siteMenuPresentation = validMenuPresentation(state.siteMenuPresentation);
  for (const [key, setting] of Object.entries(railSettings)) state[key] = clampRailSetting(key, state[key] ?? setting.initial);

  const ensureRailSettingsPanel = () => {
    const layoutPanel = document.querySelector('#editor .block-presentation-panel');
    if (!layoutPanel) return;
    let settings = layoutPanel.querySelector('.left-rail-settings');
    if (!settings) {
      settings = document.createElement('section');
      settings.className = 'left-rail-settings';
      const heading = document.createElement('h3');
      heading.textContent = 'Colonne de gauche';
      const hint = document.createElement('p');
      hint.textContent = 'Le menu prend la largeur du bloc Entreprise et remplit l’espace disponible à gauche.';
      settings.append(heading, hint);
      for (const [key, title] of [['railWidth', 'Largeur de la colonne'], ['railCompanyHeight', 'Hauteur du bloc Entreprise']]) {
        const config = railSettings[key];
        const label = document.createElement('label');
        label.className = 'left-rail-setting';
        const caption = document.createElement('span');
        const value = document.createElement('output');
        const input = document.createElement('input');
        input.type = 'range';
        input.min = config.min;
        input.max = config.max;
        input.step = config.step;
        input.value = state[key];
        input.setAttribute('aria-label', title);
        const refresh = () => {
          state[key] = clampRailSetting(key, input.value);
          value.value = `${state[key]} ${config.unit}`;
          value.textContent = value.value;
        };
        caption.textContent = title;
        refresh();
        input.addEventListener('input', () => { refresh(); update(); });
        label.append(caption, value, input);
        settings.append(label);
      }
      layoutPanel.append(settings);
    }
    settings.hidden = state.blockPresentation !== 'left-rail';
  };

  const ensureBlockPresentationPanel = () => {
    if (tab !== 'design') return;
    const editor = document.querySelector('#editor');
    if (!editor || editor.querySelector('.block-presentation-panel')) return;

    const panel = document.createElement('section');
    panel.className = 'block-presentation-panel';
    const heading = document.createElement('h2');
    heading.textContent = 'Organisation de votre site';
    const hint = document.createElement('p');
    hint.textContent = 'Choisissez une disposition, puis réglez la largeur et l’apparence de vos blocs.';
    const grid = document.createElement('div');
    grid.className = 'block-presentation-grid';

    for (const layout of layouts) {
      const choice = document.createElement('button');
      choice.type = 'button';
      choice.className = 'block-presentation-choice';
      choice.dataset.layout = layout.id;
      choice.setAttribute('aria-pressed', String(state.blockPresentation === layout.id));
      choice.setAttribute('aria-label', `${layout.title}. ${layout.description}`);
      const diagram = document.createElement('span');
      diagram.className = `block-layout-diagram diagram-${layout.id}`;
      diagram.setAttribute('aria-hidden', 'true');
      diagram.innerHTML = layout.id === 'left-rail'
        ? '<i class="diagram-header"></i><i class="diagram-content-header"></i><i class="diagram-main"></i><i class="diagram-block"></i><i class="diagram-block"></i>'
        : '<i class="diagram-header"></i><i class="diagram-main"></i><i class="diagram-block"></i><i class="diagram-block"></i><i class="diagram-block"></i>';
      const title = document.createElement('strong');
      title.textContent = layout.title;
      const description = document.createElement('small');
      description.textContent = layout.description;
      choice.append(diagram, title, description);
      grid.append(choice);
    }
    panel.append(heading, hint, grid);
    editor.prepend(panel);
  };

  const ensureMenuEffectsControl = () => {
    if (tab !== 'effects') return;
    const editor = document.querySelector('#editor');
    if (!editor) return;
    let group = editor.querySelector('.design-special-effects');
    if (!group) {
      group = document.createElement('details');
      group.className = 'design-special-effects';
      group.open = true;
      const heading = document.createElement('summary');
      heading.textContent = 'Effets spéciaux';
      group.append(heading);
      editor.append(group);
    }
    let menuSetting = group.querySelector('.site-menu-presentation-setting');
    if (!menuSetting) {
      menuSetting = document.createElement('section');
      menuSetting.className = 'site-menu-presentation-setting';
      const menuHeading = document.createElement('h3');
      menuHeading.textContent = 'Menu du site';
      const menuIcon = document.createElement('span');
      menuIcon.className = 'site-menu-heading-icon';
      menuIcon.setAttribute('aria-hidden', 'true');
      menuIcon.innerHTML = '<svg viewBox="0 0 24 24" fill="none"><path d="M5 7h14M5 12h14M5 17h14"/></svg>';
      menuHeading.prepend(menuIcon);
      const menuLabel = document.createElement('label');
      menuLabel.setAttribute('for', 'site-menu-presentation');
      menuLabel.textContent = 'Présentation du menu';
      const menuSelect = document.createElement('select');
      menuSelect.id = 'site-menu-presentation';
      menuSelect.setAttribute('aria-label', 'Présentation du menu');
      for (const [value, label] of [['bar', 'Classique puis compact au défilement'], ['compact', 'Menu compact comme sur mobile'], ['static', 'Menu classique sans animation']]) {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = label;
        menuSelect.append(option);
      }
      menuSelect.addEventListener('change', () => {
        state.siteMenuPresentation = validMenuPresentation(menuSelect.value);
        update();
      });
      menuSetting.append(menuHeading, menuLabel, menuSelect);
      group.append(menuSetting);
    }
    const menuSelect = menuSetting.querySelector('select');
    if (menuSelect) menuSelect.value = state.siteMenuPresentation;
    if (editor.lastElementChild !== group) editor.append(group);
  };
  window.ensureBlockPresentationPanel = ensureBlockPresentationPanel;
  const bindLayoutChoiceEvents = () => {
    const editor = document.querySelector('#editor');
    if (!editor || editor.dataset.layoutChoiceEventsBound) return;
    editor.dataset.layoutChoiceEventsBound = 'true';
    editor.addEventListener('click', event => {
      const choice = event.target.closest('.block-presentation-choice');
      if (!choice || !editor.contains(choice)) return;
      event.preventDefault();
      const layout = validLayout(choice.dataset.layout);
      state.blockPresentation = layout;
      for (const option of editor.querySelectorAll('.block-presentation-choice')) {
        option.setAttribute('aria-pressed', String(option === choice));
      }
      ensureRailSettingsPanel();
      update();
    });
  };
  const renderBeforeBlockPresentation = render;
  render = function () {
    renderBeforeBlockPresentation();
    ensureBlockPresentationPanel();
    ensureMenuEffectsControl();
    ensureRailSettingsPanel();
    bindLayoutChoiceEvents();
  };

  const pageBeforeBlockPresentation = page;
  page = function () {
    const doc = parseRenderedPage(pageBeforeBlockPresentation());
    const layout = validLayout(state.blockPresentation);
    doc.body.dataset.blockPresentation = layout;
    doc.body.dataset.siteMenuPresentation = validMenuPresentation(state.siteMenuPresentation);
    if (doc.body.dataset.siteMenuPresentation === 'bar') {
      const scrollMenu = doc.createElement('script');
      scrollMenu.textContent = `(${installScrollMenuAnimation.toString()})(window);`;
      doc.body.append(scrollMenu);
    }
    if (layout === 'left-rail' || layout === 'right-rail') {
      const header = doc.querySelector('body>header');
      if (header && !header.querySelector('.site-company-panel')) {
        const companyPanel = doc.createElement('div');
        companyPanel.className = 'site-company-panel';
        for (const child of [...header.children]) {
          if (child.matches('.site-menu,.site-menu-toggle,.call')) continue;
          companyPanel.append(child);
        }
        header.prepend(companyPanel);
      }
      const nav = header?.querySelector('nav');
      if (nav) {
        nav.setAttribute('aria-label', 'Navigation principale');
        const sections = [...doc.querySelectorAll('body>section:not(.business-card)')]
          .filter(section => !section.classList.contains('services-section'));
        nav.replaceChildren(...sections.map((section, index) => {
          if (!section.id) section.id = `site-menu-section-${index + 1}`;
          const link = doc.createElement('a');
          link.href = `#${section.id}`;
          link.textContent = (section.classList.contains('hero') ? 'Entreprise'
            : section.classList.contains('services-section') ? 'Prestations'
            : section.classList.contains('realisations-section') ? 'Réalisations'
            : section.classList.contains('contact') ? 'Contact'
            : section.classList.contains('videos-section') ? 'Vidéos'
            : section.classList.contains('partners-section') ? 'Partenaires'
            : section.classList.contains('zone') ? 'Zone d’intervention'
            : section.classList.contains('promotions-section') ? 'Offres'
            : section.querySelector('h1,h2')?.textContent.trim())
            || section.querySelector('.eyebrow')?.textContent.trim()
            || `Section ${index + 1}`;
          link.setAttribute('onclick', "event.preventDefault();event.stopPropagation();const target=document.getElementById(this.hash.slice(1));const header=this.closest('header');header?.classList.remove('menu-open');const toggle=header?.querySelector('.site-menu-toggle');if(toggle){toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label','Ouvrir le menu');toggle.textContent='☰'}if(target)target.scrollIntoView({behavior:['compact','static'].includes(document.body.dataset.siteMenuPresentation)?'instant':window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'})");
          return link;
        }));
      }
    }
    doc.getElementById('block-presentation-layouts')?.remove();
    const style = doc.createElement('style');
    style.id = 'block-presentation-layouts';
    style.textContent = `
      body[data-block-presentation="centered"]>section:not(.business-card){width:min(100%,1200px);margin-inline:auto}
      body[data-block-presentation="centered"] .services-section .services-grid,body[data-block-presentation="centered"] .presentation-gallery{grid-template-columns:minmax(0,1fr)!important}
      body[data-block-presentation="left-rail"],body[data-block-presentation="right-rail"]{display:grid!important;grid-template-columns:minmax(220px,280px) minmax(0,1fr)!important;align-items:start}
      body[data-block-presentation="left-rail"]{grid-template-columns:minmax(180px,${state.railWidth}px) minmax(0,1fr)!important}
      body[data-block-presentation="left-rail"]>header,body[data-block-presentation="right-rail"]>header{position:sticky;top:0;z-index:2147483000!important;isolation:isolate;grid-row:1 / span 30;align-self:start;min-height:100vh;height:100vh;flex-direction:column;align-items:flex-start;justify-content:flex-start;padding:34px 24px;gap:28px}
      body[data-block-presentation="left-rail"]>header{grid-column:1;border-right:1px solid ${state.borderColor}}
      body[data-block-presentation="left-rail"]>header .call{display:none!important}
      body[data-block-presentation="left-rail"]>section.hero{grid-column:2!important;grid-row:1;min-height:220px;display:flex;flex-direction:column;justify-content:center;padding-block:clamp(32px,5vw,72px)!important;border-bottom:1px solid ${state.borderColor}}
      body[data-block-presentation="right-rail"]>header{grid-column:2;grid-row:1 / span 30;border-left:1px solid ${state.borderColor}}
      body[data-block-presentation="left-rail"]>section,body[data-block-presentation="left-rail"]>footer{grid-column:2!important;min-width:0}
      body[data-block-presentation="right-rail"]>section,body[data-block-presentation="right-rail"]>footer{grid-column:1!important;min-width:0}
      body[data-block-presentation="left-rail"]>header nav,body[data-block-presentation="right-rail"]>header nav{display:flex;flex-direction:column;align-items:flex-start;gap:16px}
      body[data-block-presentation="left-rail"]>header nav,body[data-block-presentation="right-rail"]>header nav{width:100%;max-height:calc(100vh - 190px);overflow:auto}
      body[data-block-presentation="left-rail"]>header nav a,body[data-block-presentation="right-rail"]>header nav a{display:block;width:100%;padding:9px 10px;border:0;border-bottom:1px solid ${state.borderColor};border-radius:6px;font-size:13px;font-weight:600;transition:background .15s,color .15s}
      body[data-block-presentation="left-rail"]>header nav a:hover,body[data-block-presentation="right-rail"]>header nav a:hover{background:${state.accent}12;color:${state.accent}}
      @media(min-width:761px){body[data-block-presentation="left-rail"]>header{padding:20px 24px!important;gap:10px!important}body[data-block-presentation="left-rail"]>header .site-company-panel{width:100%;min-height:${state.railCompanyHeight}px;flex:0 0 auto;display:flex;flex-direction:column;align-items:flex-start;justify-content:flex-start;gap:14px}body[data-block-presentation="left-rail"]>header nav.site-menu{box-sizing:border-box;width:100%!important;min-width:0!important;min-height:120px;height:auto!important;max-height:calc(100vh - ${state.railCompanyHeight}px - 50px)!important;flex:1 1 auto!important;margin-top:0!important;justify-content:flex-start;gap:8px!important;overflow:auto!important;padding:8px;border:1px solid ${state.borderColor};border-radius:10px;background:${state.blockBackground}}}
      body[data-block-presentation="left-rail"] .services-section .services-grid,body[data-block-presentation="right-rail"] .services-section .services-grid,body[data-block-presentation="left-rail"] .presentation-gallery,body[data-block-presentation="right-rail"] .presentation-gallery{grid-template-columns:repeat(2,minmax(0,1fr))!important}
      body[data-block-presentation="left-rail"]>header .call,body[data-block-presentation="right-rail"]>header .call{margin-top:auto}
      body[data-block-presentation="cards"]{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;align-items:start;column-gap:20px;row-gap:20px}
      body[data-block-presentation="cards"]>header,body[data-block-presentation="cards"]>section.business-card,body[data-block-presentation="cards"]>section.hero,body[data-block-presentation="cards"]>footer{grid-column:1/-1!important}
      body[data-block-presentation="cards"]>section:not(.business-card):not(.hero){box-sizing:border-box;width:auto!important;max-width:none!important;margin:0!important;min-width:0;overflow-wrap:anywhere}
      body[data-block-presentation="cards"]>section:not(.business-card){width:min(calc(100% - 36px),1160px);margin:18px auto;border:1px solid ${state.borderColor};border-radius:${state.radius}px;box-shadow:0 8px 26px #1b25200d}
      body[data-block-presentation="cards"] .services-section .services-grid,body[data-block-presentation="cards"] .presentation-gallery{grid-template-columns:repeat(2,minmax(0,1fr))!important}
      body[data-block-presentation="panorama"]{width:100%!important;max-width:none!important}
      body[data-block-presentation="panorama"]>section:not(.business-card){width:100%!important;max-width:none!important;margin-inline:0!important;padding-inline:clamp(24px,7vw,120px)!important}
      body[data-block-presentation="panorama"] .hero{min-height:420px;display:flex;flex-direction:column;justify-content:center}
      body[data-block-presentation="panorama"] .services-section .services-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important}
      @media(min-width:761px){body[data-site-menu-presentation="bar"]{padding-top:58px!important}body[data-site-menu-presentation="bar"]>header nav.site-menu{position:fixed!important;inset:0 0 auto!important;z-index:2147483001!important;display:flex!important;flex-direction:row!important;flex-wrap:wrap!important;align-items:center!important;justify-content:center!important;gap:8px 18px!important;box-sizing:border-box;width:100%!important;max-width:none!important;max-height:calc(100vh - 12px)!important;margin:0!important;padding:8px 20px!important;overflow:auto!important;border:0!important;border-bottom:1px solid ${state.borderColor}!important;border-radius:0!important;background:${state.blockBackground}!important;box-shadow:0 4px 16px #24170f18}body[data-site-menu-presentation="bar"]>header nav.site-menu a{display:inline-flex!important;align-items:center;min-height:38px;padding:8px 10px!important;border:0!important;border-radius:6px;font-size:13px}body[data-site-menu-presentation="bar"]>header .site-menu-toggle{display:none!important}body[data-site-menu-presentation="compact"]>header .site-menu-toggle{display:inline-flex!important;position:fixed!important;top:12px!important;right:12px!important;z-index:2147483002!important;align-items:center;justify-content:center;width:44px;height:44px;margin:0!important;padding:6px!important}body[data-site-menu-presentation="compact"]>header nav.site-menu{display:none!important;position:fixed!important;top:66px!important;right:12px!important;left:auto!important;z-index:2147483001!important;width:min(320px,calc(100vw - 24px))!important;max-width:none!important;max-height:calc(100vh - 82px)!important;margin:0!important;padding:12px!important;overflow:auto!important;border:1px solid ${state.borderColor}!important;border-radius:12px!important;background:${state.blockBackground}!important;box-shadow:0 8px 30px #0003!important}body[data-site-menu-presentation="compact"]>header.menu-open nav.site-menu{display:flex!important;flex-direction:column!important;align-items:stretch!important;gap:0!important}body[data-site-menu-presentation="compact"]>header nav.site-menu a{display:flex!important;align-items:center;min-height:44px;padding:10px 12px!important;border:0!important;border-bottom:1px solid ${state.borderColor}!important}body[data-site-menu-presentation="compact"]>header nav.site-menu a:last-child{border-bottom:0!important}body[data-site-menu-presentation="compact"]>header .site-menu-toggle{background:${state.accent}!important;color:${paletteButtonText(state.accent)}!important;box-shadow:0 2px 12px #0003!important}}
      body[data-site-menu-presentation="compact"]>header nav.site-menu a{min-height:44px}
      body[data-site-menu-presentation="compact"]>header :is(.site-menu-toggle,nav.site-menu,nav.site-menu a){animation:none!important;transition:none!important}
      body[data-site-menu-presentation="static"]>header :is(.site-menu-toggle,nav.site-menu,nav.site-menu a){animation:none!important;transition:none!important}
      body[data-site-menu-presentation="static"]>header,body[data-site-menu-presentation="static"]>header *{animation:none!important;animation-timeline:auto!important;transition:none!important;transform:none!important;scroll-behavior:auto!important}
      body[data-site-menu-presentation="static"]>.site-menu-flight{display:none!important;visibility:hidden!important;animation:none!important;transform:none!important}
      @media(min-width:761px){body[data-site-menu-presentation="static"]>header .site-menu-toggle{display:inline-flex!important;position:fixed!important;top:12px!important;right:12px!important;z-index:2147483002!important;align-items:center;justify-content:center;width:44px;height:44px;margin:0!important;padding:6px!important;background:${state.accent}!important;color:${paletteButtonText(state.accent)}!important;box-shadow:0 2px 12px #0003!important}body[data-site-menu-presentation="static"]>header nav.site-menu{display:none!important;position:fixed!important;top:66px!important;right:12px!important;left:auto!important;z-index:2147483001!important;width:min(320px,calc(100vw - 24px))!important;max-width:none!important;max-height:calc(100vh - 82px)!important;margin:0!important;padding:12px!important;overflow:auto!important;border:1px solid ${state.borderColor}!important;border-radius:12px!important;background:${state.blockBackground}!important;box-shadow:0 8px 30px #0003!important}body[data-site-menu-presentation="static"]>header.menu-open nav.site-menu{display:flex!important;flex-direction:column!important;align-items:stretch!important;gap:0!important}body[data-site-menu-presentation="static"]>header nav.site-menu a{display:flex!important;align-items:center;min-height:44px;padding:10px 12px!important;border:0!important;border-bottom:1px solid ${state.borderColor}!important}body[data-site-menu-presentation="static"]>header nav.site-menu a:last-child{border-bottom:0!important}}
      body[data-site-menu-presentation="bar"] section[id]{scroll-margin-top:72px}
      @media(max-width:760px){body[data-block-presentation="left-rail"],body[data-block-presentation="right-rail"]{display:block!important}body[data-block-presentation="left-rail"]>header,body[data-block-presentation="right-rail"]>header{position:relative;height:auto;min-height:0;flex-direction:column!important;align-items:stretch!important;padding:20px 7%;gap:14px;border:0}body[data-block-presentation="left-rail"]>header nav,body[data-block-presentation="right-rail"]>header nav{display:flex!important;flex-direction:column;align-items:stretch;width:100%;max-height:none;overflow:visible;gap:0}body[data-block-presentation="left-rail"]>header nav.site-menu{margin-top:0!important;max-height:none!important;flex:0 0 auto!important}body[data-block-presentation="left-rail"]>header nav a,body[data-block-presentation="right-rail"]>header nav a{padding:10px 8px}body[data-block-presentation="left-rail"]>header .call,body[data-block-presentation="right-rail"]>header .call{margin:0 0 0 auto}body[data-block-presentation="cards"]{grid-template-columns:minmax(0,1fr)!important;row-gap:14px}body[data-block-presentation="cards"]>header,body[data-block-presentation="cards"]>section.business-card,body[data-block-presentation="cards"]>section.hero,body[data-block-presentation="cards"]>footer{grid-column:1!important}body[data-block-presentation="cards"]>section:not(.business-card):not(.hero){width:100%!important}body[data-block-presentation="cards"] .services-section .services-grid,body[data-block-presentation="cards"] .presentation-gallery,body[data-block-presentation="panorama"] .services-section .services-grid{grid-template-columns:1fr!important}}
    `;
    doc.head.append(style);
    const scrollMenuStyle = doc.createElement('style');
    scrollMenuStyle.id = 'scroll-menu-presentation';
    scrollMenuStyle.textContent = `
      @media(min-width:761px){
        body[data-site-menu-presentation="bar"]{padding-top:0!important}
        body[data-site-menu-presentation="bar"]>header nav.site-menu{position:static!important;inset:auto!important;z-index:auto!important;display:flex!important;flex-direction:row!important;flex-wrap:wrap!important;align-items:center!important;justify-content:flex-end!important;width:auto!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;overflow:visible!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important}
        body[data-site-menu-presentation="bar"]>header nav.site-menu a{display:inline-flex!important;align-items:center;min-height:38px;padding:8px 10px!important;border:0!important;border-radius:6px;font-size:13px}
        body[data-site-menu-presentation="bar"]>header .site-menu-toggle{display:none!important}
        body[data-site-menu-presentation="bar"]>header.menu-scrolled nav.site-menu{display:none!important}
        body[data-site-menu-presentation="bar"]>header.menu-scrolled .site-menu-toggle{display:inline-flex!important;position:fixed!important;top:12px!important;right:12px!important;z-index:2147483002!important;align-items:center;justify-content:center;width:44px;height:44px;margin:0!important;padding:6px!important;background:${state.accent}!important;color:${paletteButtonText(state.accent)}!important;box-shadow:0 2px 12px #0003!important}
        body[data-site-menu-presentation="bar"]>header.menu-scrolled.menu-open nav.site-menu{display:flex!important;position:fixed!important;top:66px!important;right:12px!important;left:auto!important;z-index:2147483001!important;flex-direction:column!important;align-items:stretch!important;gap:0!important;box-sizing:border-box;width:min(320px,calc(100vw - 24px))!important;max-width:none!important;max-height:calc(100vh - 82px)!important;margin:0!important;padding:12px!important;overflow:auto!important;border:1px solid ${state.borderColor}!important;border-radius:12px!important;background:${state.blockBackground}!important;box-shadow:0 8px 30px #0003!important}
        body[data-site-menu-presentation="bar"]>header.menu-scrolled.menu-open nav.site-menu a{display:flex!important;align-items:center;min-height:44px;padding:10px 12px!important;border:0!important;border-bottom:1px solid ${state.borderColor}!important}
        body[data-site-menu-presentation="bar"]>header.menu-scrolled.menu-open nav.site-menu a:last-child{border-bottom:0!important}
        body[data-site-menu-presentation="bar"]>header.menu-flight-active .site-menu-toggle{visibility:hidden!important}
        body[data-site-menu-presentation="bar"]>header:is(.menu-transition-in,.menu-transition-out) .site-menu-toggle{display:inline-flex!important;position:fixed!important;top:12px!important;right:12px!important;z-index:2147483002!important;align-items:center;justify-content:center;width:44px;height:44px;margin:0!important;padding:6px!important;background:${state.accent}!important;color:${paletteButtonText(state.accent)}!important;box-shadow:0 2px 12px #0003!important}
        body[data-site-menu-presentation="bar"]>header:is(.menu-transition-in,.menu-transition-out) nav.site-menu{overflow:visible!important;pointer-events:none!important}
        body[data-site-menu-presentation="bar"]>header:is(.menu-transition-in,.menu-transition-out) nav.site-menu a{will-change:transform,opacity}
      }
    `;
    doc.head.append(scrollMenuStyle);
    const railMenuStyle = doc.createElement('style');
    railMenuStyle.id = 'compact-left-rail-menu';
    railMenuStyle.textContent = `
      @media(min-width:761px){
        body[data-block-presentation="left-rail"]>header{gap:8px!important}
        body[data-block-presentation="left-rail"][data-site-menu-presentation="bar"]>header.with-business-card>div.site-company-panel{flex:0 0 auto!important}
        body[data-block-presentation="left-rail"][data-site-menu-presentation="bar"]>header:not(.menu-scrolled) nav.site-menu{position:static!important;display:flex!important;flex:0 0 auto!important;flex-direction:column!important;align-items:stretch!important;justify-content:flex-start!important;gap:4px!important;width:100%!important;min-height:0!important;height:auto!important;max-height:calc(100vh - ${state.railCompanyHeight}px - 36px)!important;margin:0!important;padding:4px!important;overflow:auto!important}
        body[data-block-presentation="left-rail"][data-site-menu-presentation="bar"]>header:not(.menu-scrolled) nav.site-menu a{display:block!important;width:100%!important;min-height:32px!important;padding:5px 8px!important;text-align:left!important}
      }
    `;
    doc.head.append(railMenuStyle);
    return serializeRenderedPage(doc);
  };

  const bindScrollMenuPreview = () => {
    const doc = previewFrame.contentDocument;
    if (!doc?.body) return;
    installScrollMenuAnimation(doc.defaultView);
  };
  previewFrame.addEventListener('load', bindScrollMenuPreview);
  bindScrollMenuPreview();

  const style = document.createElement('style');
  style.textContent = `
    #editor .block-presentation-panel{margin:0 0 22px;padding:16px 16px 20px;border:1px solid #9a7458;border-radius:14px;background:#fffaf5;color:#38281f}
    #editor .left-rail-settings{margin-top:18px;padding-top:15px;border-top:1px solid #e5caba}
    #editor .left-rail-settings[hidden]{display:none}
    #editor .left-rail-settings h3{margin:0 0 4px;font-size:16px;color:#38281f}
    #editor .left-rail-settings>p{margin:0 0 14px;font-size:12px;color:#604b3f}
    #editor .left-rail-setting{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:3px 10px;margin:0 0 13px;font-size:12px;color:#38281f}
    #editor .left-rail-setting output{font-weight:700;color:#8e3d25}
    #editor .left-rail-setting input{grid-column:1/-1;width:100%;accent-color:#8e3d25}
    #editor .site-menu-presentation-setting{display:grid;gap:7px;margin-top:18px;padding-top:15px;border-top:1px solid #e5caba}
    #editor .site-menu-presentation-setting h3{margin:0;color:#38281f;font-size:16px}
    #editor .site-menu-presentation-setting label{font-size:12px;color:#604b3f}
    #editor .site-menu-presentation-setting select{width:100%;min-height:40px;padding:8px 10px;border:1px solid #b88e70;border-radius:8px;background:#fff;color:#38281f;font:inherit}
    #editor .block-presentation-panel h2{margin:0 0 5px;color:#38281f;font-size:20px}
    #editor .block-presentation-panel>p{margin:0 0 13px;color:#604b3f;font-size:12px;line-height:1.55}
    #editor .block-presentation-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
    #editor .block-presentation-choice{display:grid;grid-template-rows:84px auto 1fr;gap:7px;min-width:0;min-height:148px;padding:9px;text-align:left;background:#fff;color:#38281f;border:1px solid #b88e70;border-radius:10px}
    #editor .block-presentation-choice[aria-pressed="true"]{outline:3px solid #8e3d25;outline-offset:1px;background:#fff1e3}
    #editor .block-presentation-choice strong{font-size:12px;color:#38281f}
    #editor .block-presentation-choice small{font-size:10px;line-height:1.35;color:#604b3f}
    #editor .block-layout-diagram{position:relative;display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:12px 1fr 1fr;gap:4px;padding:7px;overflow:hidden;border:1px solid #b88e70;border-radius:6px;background:#f6eee6}
    #editor .block-layout-diagram i{display:block;border-radius:2px;background:#d8c4b2}
    #editor .block-layout-diagram .diagram-header{grid-column:1/-1;background:#a9a9a9}
    #editor .block-layout-diagram .diagram-main{grid-column:1/4;grid-row:2/4;background:#bdbdbd}
    #editor .block-layout-diagram .diagram-block:nth-of-type(3){grid-column:4;grid-row:2}
    #editor .block-layout-diagram .diagram-block:nth-of-type(4){grid-column:4;grid-row:3}
    #editor .block-layout-diagram .diagram-block:nth-of-type(5){display:none}
    #editor .diagram-left-rail{grid-template-rows:10px 1fr 1fr;grid-template-columns:14px 1fr 1fr 1fr}
    #editor .diagram-left-rail .diagram-header{grid-column:1;grid-row:1/-1}
    #editor .diagram-left-rail .diagram-content-header{display:block;grid-column:2/-1;grid-row:1;background:#a9a9a9}
    #editor .diagram-left-rail .diagram-main{grid-column:2/-1;grid-row:2/-1;background:#bdbdbd}
    #editor .diagram-left-rail .diagram-block:nth-of-type(4),#editor .diagram-left-rail .diagram-block:nth-of-type(5){display:none}
    #editor .diagram-right-rail{grid-template-rows:1fr 1fr 1fr;grid-template-columns:14px 1fr 1fr}
    #editor .diagram-right-rail .diagram-header{grid-column:1;grid-row:1/-1}
    #editor .diagram-right-rail .diagram-main{grid-column:2/4;grid-row:1/3}
    #editor .diagram-right-rail .diagram-block:nth-of-type(3){grid-column:2;grid-row:3;display:block}
    #editor .diagram-right-rail .diagram-block:nth-of-type(4){grid-column:3;grid-row:3;display:block}
    #editor .diagram-right-rail .diagram-header{grid-column:3}
    #editor .diagram-right-rail .diagram-main{grid-column:1/3}
    #editor .diagram-right-rail .diagram-block:nth-of-type(3){grid-column:1}
    #editor .diagram-right-rail .diagram-block:nth-of-type(4){grid-column:2}
    #editor .diagram-cards{grid-template-columns:repeat(2,minmax(0,1fr));grid-template-rows:12px repeat(2,minmax(0,1fr))}
    #editor .diagram-cards .diagram-header{grid-column:1/-1}
    #editor .diagram-cards .diagram-main{grid-column:1;grid-row:2}
    #editor .diagram-cards .diagram-block:nth-of-type(3){grid-column:2;grid-row:2;display:block}
    #editor .diagram-cards .diagram-block:nth-of-type(4){grid-column:1;grid-row:3;display:block}
    #editor .diagram-cards .diagram-block:nth-of-type(5){grid-column:2;grid-row:3;display:block}
    #editor .diagram-panorama{grid-template-columns:repeat(3,1fr);grid-template-rows:12px 1fr 1fr}
    #editor .diagram-panorama .diagram-header,#editor .diagram-panorama .diagram-main{grid-column:1/-1}
    #editor .diagram-panorama .diagram-main{grid-row:2;background:#bdbdbd}
    #editor .diagram-panorama .diagram-block:nth-of-type(3){grid-column:1;grid-row:3;display:block}
    #editor .diagram-panorama .diagram-block:nth-of-type(4){grid-column:2;grid-row:3;display:block}
    #editor .diagram-panorama .diagram-block:nth-of-type(5){grid-column:3;grid-row:3;display:block}
    #editor .diagram-centered{grid-template-columns:minmax(0,1fr);grid-template-rows:10px repeat(2,minmax(0,1fr))}
    #editor .diagram-centered .diagram-header{grid-column:1;grid-row:1}
    #editor .diagram-centered .diagram-main{grid-column:1;grid-row:2/-1;background:#bdbdbd}
    #editor .diagram-centered .diagram-block:nth-of-type(3),#editor .diagram-centered .diagram-block:nth-of-type(4),#editor .diagram-centered .diagram-block:nth-of-type(5){display:none}
    @media(max-width:480px){#editor .block-presentation-grid{grid-template-columns:1fr 1fr;gap:7px}#editor .block-presentation-choice{grid-template-rows:70px auto 1fr;min-height:132px;padding:7px}#editor .block-presentation-choice small{font-size:9px}}
  `;
  document.head.append(style);
  render();
})();
