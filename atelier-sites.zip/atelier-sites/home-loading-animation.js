// Loading-screen choice for the home block, with automatic business-name branding.
(() => {
  const choices = new Set(['business-circle', 'hopclic-circle', 'none']);
  const cleanChoice = value => choices.has(value) ? value : 'business-circle';

  const validateBeforeHomeLoadingChoice = validate;
  validate = function (saved) {
    const result = validateBeforeHomeLoadingChoice(saved);
    result.homeLoadingAnimation = cleanChoice(saved?.homeLoadingAnimation);
    result.siteFavicon = typeof saved?.siteFavicon === 'string'
      && saved.siteFavicon.length <= 600000
      && /^data:image\/(?:png|jpeg|webp|svg\+xml|x-icon|vnd\.microsoft\.icon);base64,[a-z\d+/=]+$/i.test(saved.siteFavicon)
      ? saved.siteFavicon
      : 'favicon-hopclic.png';
    return result;
  };
  state.homeLoadingAnimation = cleanChoice(state.homeLoadingAnimation);

  function applyBuilderFavicon(source) {
    const icon = document.querySelector('#builder-favicon');
    if (icon) icon.href = source || 'favicon-hopclic.png';
  }
  applyBuilderFavicon(state.siteFavicon);

  const renderBeforeHomeLoadingChoice = render;
  render = function () {
    renderBeforeHomeLoadingChoice();
    if (tab !== 'effects') return;
    const editor = document.querySelector('#editor');
    if (!editor) return;
    let effectsGroup = editor.querySelector('.design-special-effects');
    if (!effectsGroup) {
      effectsGroup = document.createElement('details');
      effectsGroup.className = 'design-special-effects';
      effectsGroup.open = true;
      const summary = document.createElement('summary');
      summary.textContent = 'Effets spéciaux';
      effectsGroup.append(summary);
      editor.append(effectsGroup);
    }
    if (effectsGroup.querySelector('.home-loading-choice')) return;

    const group = document.createElement('section');
    group.className = 'home-loading-choice';
    group.style.cssText = 'margin-top:18px;padding-top:14px;border-top:1px solid var(--ui-border,#e5caba)';
    const heading = document.createElement('h3');
    heading.textContent = 'Animation au chargement du site';
    const options = document.createElement('div');
    options.className = 'home-loading-options';
    const definitions = [
      ['business-circle', 'Nom de l’entreprise', 'Le nom tourne au centre du cercle'],
      ['hopclic-circle', 'Logo HopClic', 'Le logo tourne au chargement'],
      ['none', 'Aucune animation', 'Afficher le site immédiatement']
    ];
    const loadingSwitches = [];
    const previewDialog = document.createElement('dialog');
    previewDialog.className = 'home-loading-preview-dialog';
    previewDialog.setAttribute('aria-labelledby', 'home-loading-preview-title');
    const previewTop = document.createElement('div');
    previewTop.className = 'home-loading-preview-top';
    const previewTitle = document.createElement('h3');
    previewTitle.id = 'home-loading-preview-title';
    const previewClose = document.createElement('button');
    previewClose.type = 'button';
    previewClose.textContent = 'Fermer';
    previewClose.addEventListener('click', () => previewDialog.close());
    previewTop.append(previewTitle, previewClose);
    const previewStage = document.createElement('div');
    previewStage.className = 'home-loading-preview-stage';
    const previewDescription = document.createElement('p');
    previewDescription.className = 'hint';
    previewDialog.append(previewTop, previewStage, previewDescription);
    document.body.append(previewDialog);
    for (const [value, title, description] of definitions) {
      const choice = document.createElement('div');
      choice.className = 'home-loading-option';
      const radio = document.createElement('input');
      radio.type = 'checkbox';
      radio.name = 'homeLoadingAnimation';
      radio.value = value;
      radio.checked = cleanChoice(state.homeLoadingAnimation) === value;
      radio.setAttribute('role', 'switch');
      radio.setAttribute('aria-checked', String(radio.checked));
      radio.setAttribute('aria-label', title);
      loadingSwitches.push({ input: radio, value });
      const copy = document.createElement('span');
      copy.className = 'home-loading-copy';
      const name = document.createElement('strong');
      name.textContent = title;
      const detail = document.createElement('small');
      detail.textContent = description;
      copy.append(name, detail);
      const visual = document.createElement('span');
      visual.className = `home-loading-mini home-loading-mini-${value}`;
      visual.setAttribute('aria-hidden', 'true');
      if (value !== 'none') {
        const wordmark = document.createElement('b');
        wordmark.textContent = value === 'business-circle' ? String(state.name || 'Entreprise').trim() : 'HopClic';
        const orbit = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        orbit.classList.add('home-loading-mini-orbit');
        orbit.setAttribute('viewBox', '0 0 200 200');
        orbit.setAttribute('aria-hidden', 'true');
        orbit.innerHTML = '<path d="M101 15 A85 85 0 1 1 45 36"/><polygon points="41,25 65,31 47,51"/>';
        visual.append(wordmark, orbit);
      } else {
        visual.textContent = '↗';
      }
      const previewButton = document.createElement('button');
      previewButton.type = 'button';
      previewButton.className = 'home-loading-preview-button';
      previewButton.setAttribute('aria-label', `Ouvrir l’aperçu : ${title}`);
      previewButton.title = 'Ouvrir l’aperçu';
      previewButton.append(visual);
      previewButton.addEventListener('click', () => {
        previewTitle.textContent = title;
        previewDescription.textContent = description;
        previewStage.replaceChildren();
        if (value === 'none') {
          const message = document.createElement('span');
          message.className = 'home-loading-preview-none-message';
          message.textContent = 'Le site s’affiche directement, sans écran de chargement.';
          previewStage.append(message);
        } else {
          const largePreview = visual.cloneNode(true);
          largePreview.classList.add('home-loading-preview-large');
          previewStage.append(largePreview);
        }
        previewDialog.showModal();
        previewClose.focus();
      });
      radio.addEventListener('change', () => {
        state.homeLoadingAnimation = radio.checked
          ? cleanChoice(radio.value)
          : state.homeLoadingAnimation === radio.value ? 'none' : state.homeLoadingAnimation;
        for (const option of loadingSwitches) {
          option.input.checked = option.value === state.homeLoadingAnimation;
          option.input.setAttribute('aria-checked', String(option.input.checked));
        }
        update();
      });
      choice.append(radio, copy, previewButton);
      options.append(choice);
    }
    const help = document.createElement('p');
    help.className = 'hint';
    help.textContent = 'Survolez la vignette pour voir l’animation. Désactivez l’interrupteur actif pour afficher le site sans écran de chargement.';
    group.append(heading, options, help);
    const favicon = document.createElement('div');
    favicon.className = 'home-site-favicon';
    const faviconHeading = document.createElement('h3');
    faviconHeading.textContent = 'Icône du site (favicon)';
    const faviconDescription = document.createElement('p');
    faviconDescription.className = 'hint';
    faviconDescription.textContent = 'Le logo HopClic est utilisé par défaut. Vous pouvez importer une icône .ico, .png ou .svg (400 Ko maximum).';
    const faviconControls = document.createElement('div');
    faviconControls.className = 'home-site-favicon-controls';
    const faviconPreview = document.createElement('img');
    faviconPreview.src = state.siteFavicon || 'favicon-hopclic.png';
    faviconPreview.alt = 'Aperçu du favicon';
    faviconPreview.width = 48;
    faviconPreview.height = 48;
    const faviconInput = document.createElement('input');
    faviconInput.type = 'file';
    faviconInput.accept = '.ico,.png,.svg,image/x-icon,image/vnd.microsoft.icon,image/png,image/svg+xml';
    faviconInput.setAttribute('aria-label', 'Importer un favicon');
    let faviconReadToken = 0;
    const faviconActions = document.createElement('div');
    faviconActions.className = 'home-site-favicon-actions';
    const removeFavicon = document.createElement('button');
    removeFavicon.type = 'button';
    removeFavicon.textContent = 'Réinitialiser';
    removeFavicon.disabled = !state.siteFavicon || state.siteFavicon === 'favicon-hopclic.png';
    removeFavicon.addEventListener('click', () => {
      state.siteFavicon = 'favicon-hopclic.png';
      faviconPreview.src = state.siteFavicon;
      faviconInput.value = '';
      removeFavicon.disabled = true;
      applyBuilderFavicon(state.siteFavicon);
      update();
    });
    faviconInput.addEventListener('change', () => {
      const file = faviconInput.files?.[0];
      if (!file) return;
      const readToken = ++faviconReadToken;
      // Clear immediately so choosing the same file again still fires `change`.
      faviconInput.value = '';
      const extension = file.name.split('.').pop().toLowerCase();
      const mimeByExtension = { ico: 'image/x-icon', png: 'image/png', svg: 'image/svg+xml' };
      const mime = mimeByExtension[extension];
      if (!mime || file.size > 400000) {
        $('#status').textContent = 'Choisissez un fichier .ico, .png ou .svg de 400 Ko maximum.';
        faviconInput.value = '';
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (readToken !== faviconReadToken) return;
        let data = String(reader.result || '');
        if (mime === 'image/svg+xml') {
          const parsed = new DOMParser().parseFromString(data, 'image/svg+xml');
          const svg = parsed.documentElement;
          if (parsed.querySelector('parsererror') || svg.localName !== 'svg') {
            $('#status').textContent = 'Ce fichier SVG est invalide.';
            faviconInput.value = '';
            return;
          }
          svg.querySelectorAll('script,foreignObject').forEach(node => node.remove());
          for (const node of [svg, ...svg.querySelectorAll('*')]) {
            for (const attribute of [...node.attributes]) {
              if (/^on/i.test(attribute.name) || ((attribute.name === 'href' || attribute.name.endsWith(':href')) && !attribute.value.startsWith('#'))) node.removeAttribute(attribute.name);
            }
          }
          data = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(new XMLSerializer().serializeToString(svg))));
        } else {
          data = data.replace(/^data:[^;]+;/, `data:${mime};`);
        }
        if (data.length > 600000) {
          $('#status').textContent = 'Le favicon est trop volumineux. Réduisez-le à 400 Ko maximum.';
          faviconInput.value = '';
          return;
        }
        state.siteFavicon = data;
        faviconPreview.src = data;
        removeFavicon.disabled = false;
        applyBuilderFavicon(data);
        update();
        $('#status').textContent = 'Favicon enregistré et ajouté au site.';
      };
      reader.onerror = () => {
        if (readToken !== faviconReadToken) return;
        $('#status').textContent = 'Impossible de lire ce fichier.';
      };
      reader.readAsDataURL(file);
    });
    faviconActions.append(faviconInput, removeFavicon);
    faviconControls.append(faviconPreview, faviconActions);
    favicon.append(faviconHeading, faviconDescription, faviconControls);
    group.append(favicon);
    const controlsStyle = document.createElement('style');
    controlsStyle.textContent = `
      .home-loading-choice h3{margin:0 0 10px;font-size:15px}
      .home-loading-options{display:grid;gap:8px}
      .home-loading-option{display:grid;grid-template-columns:74px minmax(0,1fr) 58px;align-items:center;gap:10px;padding:9px 10px;border:1px solid var(--ui-border,#e5caba);border-radius:11px;background:#fffaf5;transition:border-color .18s,background .18s,transform .18s}
      .home-loading-option:hover,.home-loading-option:focus-within{border-color:#c95b2e;background:#fff4e8;transform:translateY(-1px)}
      .home-loading-option input{appearance:none;-webkit-appearance:none;position:relative;width:72px;height:34px;margin:0;border:1px solid #828986;border-radius:999px;background:linear-gradient(180deg,#777d7a,#555c59);box-shadow:inset 0 2px 4px #0005,0 1px 2px #fff9;cursor:pointer;transition:background .2s,border-color .2s}
      .home-loading-option input::before{content:'OFF';position:absolute;top:50%;right:8px;transform:translateY(-50%);font:700 9px/1 Arial,sans-serif;letter-spacing:.04em;color:#e4e8e6}
      .home-loading-option input::after{content:'';position:absolute;left:3px;top:3px;width:26px;height:26px;border:1px solid #c6cbc8;border-radius:50%;background:linear-gradient(145deg,#fff,#c8cfcc);box-shadow:0 1px 3px #0006;transition:transform .2s ease}
      .home-loading-option input:checked{border-color:#71847d;background:linear-gradient(180deg,#82948d,#50675f)}
      .home-loading-option input:checked::before{content:'ON';left:10px;right:auto;color:#b8fff0}
      .home-loading-option input:checked::after{transform:translateX(38px)}
      .home-loading-option input:focus-visible{outline:3px solid #d77a3d;outline-offset:3px}
      .home-loading-option input{justify-self:start}
      .home-loading-copy{display:grid;gap:3px;min-width:0}
      .home-loading-copy strong{font-size:13px;color:#4b2b1e}
      .home-loading-copy small{font-size:11px;line-height:1.35;color:#795d4d}
      .home-loading-mini{position:relative;display:grid;place-items:center;width:54px;height:54px;overflow:hidden;border:1px solid #e8d3c0;border-radius:50%;background:radial-gradient(circle,#fff 15%,#fff6eb 72%,#f2dfca);color:#502817}
      .home-loading-mini b{z-index:1;max-width:44px;max-height:44px;overflow:hidden;white-space:normal;overflow-wrap:anywhere;text-align:center;font-size:7px;line-height:1.05;letter-spacing:-.04em}
      .home-loading-mini-orbit{position:absolute;inset:0;width:100%;height:100%;overflow:visible;transform-origin:center;pointer-events:none}
      .home-loading-mini-orbit path{fill:none;stroke:#f29a1b;stroke-width:7;stroke-linecap:round;filter:drop-shadow(0 1px 2px #a64c1944)}
      .home-loading-mini-orbit polygon{fill:#df5427;filter:drop-shadow(0 1px 2px #a64c1944)}
      .home-loading-option:hover .home-loading-mini-business-circle .home-loading-mini-orbit,.home-loading-option:hover .home-loading-mini-hopclic-circle .home-loading-mini-orbit{animation:home-loading-preview-spin 2.4s linear infinite}
      .home-loading-option:hover .home-loading-mini b{animation:home-loading-preview-pulse 1.1s ease-in-out infinite}
      .home-loading-mini-none{font-size:23px;color:#b9572b}
      .home-loading-preview-button{display:grid;place-items:center;width:58px;height:58px;margin:0;padding:0;border:0;background:transparent;cursor:zoom-in}
      .home-loading-preview-button:hover .home-loading-mini{border-color:#c95b2e;box-shadow:0 2px 8px #b9512826}
      .home-loading-preview-dialog{width:min(420px,calc(100vw - 32px));max-width:none;padding:18px;border:1px solid #e4cdb9;border-radius:16px;background:#fffaf5;color:#4b2b1e;box-shadow:0 22px 70px #24160e55}
      .home-loading-preview-dialog::backdrop{background:#21160f80;backdrop-filter:blur(3px)}
      .home-loading-preview-top{display:flex;align-items:center;justify-content:space-between;gap:12px}
      .home-loading-preview-top h3{margin:0;font-size:17px}
      .home-loading-preview-stage{min-height:270px;display:grid;place-items:center;margin:14px 0;padding:24px;border:1px solid #ecd8c5;border-radius:13px;background:radial-gradient(ellipse,#fff 10%,#fbf1e7 76%,#f1dfcd)}
      .home-loading-preview-large{width:220px;height:220px;border-radius:50%;background:transparent;border:0;overflow:visible}
      .home-loading-preview-large b{max-width:82%;max-height:82%;overflow:visible;white-space:normal;text-overflow:clip;overflow-wrap:anywhere;text-align:center;font-size:clamp(15px,4.8vw,21px);line-height:1.08;animation:home-loading-preview-pulse 1.8s ease-in-out infinite}
      .home-loading-preview-large .home-loading-mini-orbit{animation:home-loading-preview-spin 2.4s linear infinite}
      .home-loading-preview-large .home-loading-mini-orbit path{stroke-width:5}
      .home-loading-preview-none-message{max-width:250px;text-align:center;color:#795d4d}
      @media(max-width:420px){.home-loading-option{grid-template-columns:68px minmax(0,1fr) 54px;gap:7px;padding:8px}.home-loading-option input{width:66px}.home-loading-option input:checked::after{transform:translateX(32px)}}
      @media(prefers-reduced-motion:reduce){.home-loading-preview-large b,.home-loading-mini-orbit{animation:none!important}}
      .home-site-favicon{margin-top:16px;padding-top:14px;border-top:1px solid var(--ui-border,#e5caba)}
      .home-site-favicon h3{margin:0 0 6px;font-size:15px}
      .home-site-favicon-controls{display:flex;align-items:center;gap:12px}
      .home-site-favicon-controls>img{object-fit:contain;border:1px solid var(--ui-border,#e5caba);border-radius:9px;background:white}
      .home-site-favicon-actions{display:flex;flex-wrap:wrap;align-items:center;gap:8px}
      .home-site-favicon-actions input{max-width:100%;font-size:12px}
      .home-site-favicon-actions button{padding:7px 10px}
      @keyframes home-loading-preview-spin{to{transform:rotate(336deg)}}
      @keyframes home-loading-preview-pulse{50%{transform:scale(1.12)}}
      @media(prefers-reduced-motion:reduce){.home-loading-option,.home-loading-mini b,.home-loading-mini-orbit{animation:none!important;transition:none}}
    `;
    group.append(controlsStyle);
    effectsGroup.append(group);
    const keepLoadingControlsAtBottom = () => {
      const loadingControls = effectsGroup.querySelector('.home-loading-choice');
      if (loadingControls && effectsGroup.lastElementChild !== loadingControls) effectsGroup.append(loadingControls);
    };
    keepLoadingControlsAtBottom();
    if (!effectsGroup.dataset.homeLoadingBottomBound) {
      effectsGroup.dataset.homeLoadingBottomBound = 'true';
      new MutationObserver(keepLoadingControlsAtBottom).observe(effectsGroup, {childList: true});
    }
  };

  const pageBeforeHomeLoadingChoice = page;
  page = function () {
    const doc = parseRenderedPage(pageBeforeHomeLoadingChoice());
    const screen = doc.querySelector('.cafein-loading-screen');
    doc.querySelectorAll('link[rel~="icon"]').forEach(icon => icon.remove());
    const favicon = doc.createElement('link');
    favicon.rel = 'icon';
    favicon.href = state.siteFavicon || 'favicon-hopclic.png';
    favicon.type = favicon.href.startsWith('data:image/svg+xml') ? 'image/svg+xml'
      : favicon.href.startsWith('data:image/x-icon') ? 'image/x-icon'
        : favicon.href.startsWith('data:image/vnd.microsoft.icon') ? 'image/vnd.microsoft.icon'
          : favicon.href.startsWith('data:image/jpeg') ? 'image/jpeg'
            : favicon.href.startsWith('data:image/webp') ? 'image/webp' : 'image/png';
    favicon.sizes = 'any';
    doc.head.append(favicon);
    const style = doc.createElement('style');
    style.id = 'home-loading-animation-style';
    style.textContent = `
      .business-loading-stage{width:min(204px,66vw)!important}
      .business-loading-name{position:relative;z-index:2;display:flex;align-items:center;justify-content:center;width:58%;min-height:58px;max-height:90px;margin:auto;padding:4px;text-align:center;overflow-wrap:anywhere;word-break:normal;color:#4a2414;font:800 clamp(14px,5vw,24px)/1.08 Arial,sans-serif;letter-spacing:-.055em;animation:business-name-breathe 2.8s ease-in-out infinite}
      .business-loading-orbit{position:absolute;inset:0;width:100%;height:100%;overflow:visible;animation:business-orbit-turn 2.4s linear infinite;pointer-events:none}
      .business-loading-orbit path{fill:none;stroke:url(#business-orbit-gradient);stroke-width:8;stroke-linecap:round;filter:drop-shadow(0 2px 5px #d66b1d55)}
      .business-loading-orbit polygon{fill:#f47a12;filter:drop-shadow(0 2px 4px #d66b1d55)}
      @keyframes business-orbit-turn{to{transform:rotate(360deg)}}
      @keyframes business-name-breathe{0%,100%{transform:scale(1)}50%{transform:scale(1.035)}}
      @media(prefers-reduced-motion:reduce){.business-loading-orbit,.business-loading-name{animation:none}}
    `;
    doc.head.append(style);

    if (state.homeLoadingAnimation === 'none') {
      screen?.remove();
      return serializeRenderedPage(doc);
    }

    if (screen && state.homeLoadingAnimation === 'business-circle') {
      const stage = screen.querySelector('.cafein-loading-stage');
      if (stage) {
        stage.classList.add('business-loading-stage');
        stage.replaceChildren();
        const name = doc.createElement('strong');
        name.className = 'business-loading-name';
        name.textContent = String(state.name || 'Votre entreprise').trim();
        name.setAttribute('aria-label', String(state.name || 'Votre entreprise').trim());
        const orbit = doc.createElementNS('http://www.w3.org/2000/svg', 'svg');
        orbit.classList.add('business-loading-orbit');
        orbit.setAttribute('viewBox', '0 0 200 200');
        orbit.setAttribute('aria-hidden', 'true');
        orbit.innerHTML = '<defs><linearGradient id="business-orbit-gradient" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f5bd45"/><stop offset=".55" stop-color="#f58a16"/><stop offset="1" stop-color="#da4b21"/></linearGradient></defs><path d="M101 15 A85 85 0 1 1 45 36"/><polygon points="41,25 65,31 47,51"/>';
        stage.append(name, orbit);
      }
    }
    return serializeRenderedPage(doc);
  };

  render();
  update();
})();
