const pageBeforeConsistentServicePhotos=page;
page=function(){const doc=parseRenderedPage(pageBeforeConsistentServicePhotos());
 doc.querySelectorAll('.service-card').forEach(card=>{if(card.querySelector('.service-photo-frame,.service-photo'))card.classList.add('consistent-service-photo')});
 const style=doc.createElement('style');style.id='consistent-service-photos';style.textContent=`
 body .services-section .services-grid{align-items:stretch!important;grid-template-columns:repeat(var(--service-columns,3),minmax(0,1fr))!important}body .services-section .services-grid>.service-card{margin-top:0!important;transform:none!important}
 body .services-section .services-grid>.service-card.consistent-service-photo{display:flex!important;flex-direction:column!important;align-items:stretch!important;gap:0!important}
 body .services-section .services-grid>.service-card.consistent-service-photo>.service-photo-frame{order:1!important;width:100%!important;aspect-ratio:16/10!important;height:auto!important;min-height:0!important;max-height:none!important;margin:0 0 22px!important;align-self:stretch!important;flex:none!important}
 body .services-section .services-grid>.service-card.consistent-service-photo>.service-photo-frame img{display:block!important;width:100%!important;height:100%!important;min-height:0!important;max-height:none!important;object-fit:cover!important;object-position:center!important;margin:0!important;transform:none}
 body .services-section .services-grid>.service-card.consistent-service-photo>.service-photo{order:1!important;display:block!important;width:100%!important;aspect-ratio:16/10!important;height:auto!important;object-fit:cover!important;margin:0 0 22px!important}
 body .services-section .services-grid>.service-card.consistent-service-photo>.service-copy{order:2!important;display:flex!important;flex-direction:column!important;flex:1;min-width:0}
 body .services-section .services-grid>.service-card.consistent-service-photo>.premium-service-number,body .services-section .services-grid>.service-card.consistent-service-photo>.habitat-number,body .services-section .services-grid>.service-card.consistent-service-photo>.meta-number{order:0!important;font-size:12px!important;line-height:1.4!important;margin:0 0 12px!important;min-height:17px}
 body .services-section .services-grid>.service-card.consistent-service-photo h3{margin-top:0!important;min-height:2.3em}body .services-section .services-grid>.service-card.consistent-service-photo .service-info-button{align-self:flex-start;margin-top:auto!important}
 @media(max-width:600px){body .services-section .services-grid{grid-template-columns:1fr!important}body .services-section .services-grid>.service-card.consistent-service-photo h3{min-height:0}}
 `;doc.head.append(style);return serializeRenderedPage(doc);
};update();
