const pageBeforeEmptyLayout=page;
const openCompanyBeforeFocus=openCompanyContent;
openCompanyContent=function(){
  openCompanyBeforeFocus();
  const input=[...document.querySelectorAll('#editor label')].find(label=>label.textContent.trim()==='Nom de l’entreprise')?.querySelector('input');
  if(input){input.scrollIntoView({behavior:'instant',block:'center'});input.focus({preventScroll:true});input.setSelectionRange(input.value.length,input.value.length);}
};
page=function(){
  const doc=parseRenderedPage(pageBeforeEmptyLayout());
  const style=doc.createElement('style');
  style.textContent='body{min-height:100vh;display:flex;flex-direction:column}body>footer{margin-top:auto}';
  doc.head.append(style);
  return serializeRenderedPage(doc);
};
function decorateEmptyPreview(){
  const doc=previewFrame.contentDocument;if(!doc?.body)return;
  const pristine=!state.name.trim()&&!state.businessCard&&!state.blocks.some(block=>block.title.trim()||block.text.replace(/[|\\s]/g,'').length);const empty=!state.blocks.some(block=>block.visible)&&!localStorage.getItem(KEY+'-welcome-started-v1');
  doc.querySelector('#creation-welcome')?.remove();
  doc.querySelector('#creation-welcome-style')?.remove();
  if(!empty&&!new URLSearchParams(location.search).has("welcome"))return;
  const style=doc.createElement('style');style.id='creation-welcome-style';
  style.textContent=`body{min-height:100vh;display:flex;flex-direction:column}body>footer{margin-top:auto}body>header:has(strong:empty):not(:has(.header-business-card)){display:none!important}body>section{display:none!important}body>header{display:none!important}#creation-welcome{flex:1;display:flex;align-items:center;justify-content:center;text-align:center;padding:54px 24px}#creation-welcome .welcome-inner{max-width:540px}#creation-welcome .welcome-icon{display:inline-grid;place-items:center;width:64px;height:64px;border-radius:20px;background:color-mix(in srgb,${state.accent} 10%,white);font-size:29px}#creation-welcome h1{font:normal clamp(28px,4vw,44px) Georgia;margin:24px auto 16px;letter-spacing:-1px}#creation-welcome p{margin:0 auto 26px;font-size:15px;line-height:1.7}#creation-welcome .welcome-step{font-size:12px;margin-top:24px;opacity:.8}#creation-welcome button{background:${state.accent};padding:15px 24px;border-radius:10px}body>footer{padding:20px 7%;text-align:center}body>footer .author-credit{display:inline-block}`;
  doc.head.append(style);
  const main=doc.createElement('main');main.id='creation-welcome';
  main.innerHTML='<div class="welcome-inner"><span class="welcome-icon">✦</span><h1>Votre site commence ici.</h1><p>Ajoutez votre carte de visite ou les informations de votre entreprise, puis composez votre site à votre rythme.</p><button type="button">Commencer par Accueil</button><div class="welcome-step">1. Accueil &nbsp; · &nbsp; 2. Mon entreprise &nbsp; · &nbsp; 3. Mes contenus</div></div>';
  main.querySelector('button').onclick=()=>{localStorage.setItem(KEY+'-welcome-started-v1','1');const address=new URL(location.href);address.searchParams.delete('welcome');history.replaceState(null,'',address);refreshPreviewWithoutBlink();const home=state.blocks.find(block=>block.type==='intro');if(home)selectEditorBlock(home.id,true);else document.querySelector('#tabs button[data-tab="blocks"]')?.click();document.querySelector('#editor')?.scrollIntoView({behavior:'smooth',block:'start'});};
  doc.body.insertBefore(main,doc.querySelector('body>footer'));
  const footer=doc.querySelector('body>footer');
  if(footer&&!state.name){const credit=footer.querySelector('.author-credit');footer.replaceChildren();if(credit)footer.append(credit);}
}
previewFrame.addEventListener('load',decorateEmptyPreview);
const refreshBeforeEmptyLayout=refreshPreviewWithoutBlink;
refreshPreviewWithoutBlink=function(){refreshBeforeEmptyLayout();decorateEmptyPreview()};
refreshPreviewWithoutBlink();

document.querySelector('#editor').addEventListener('click',event=>{if(event.target.closest('.content-choice')&&!localStorage.getItem(KEY+'-welcome-started-v1')){localStorage.setItem(KEY+'-welcome-started-v1','1');refreshPreviewWithoutBlink();}},true);
