// This link opens only a same-origin viewer; keep its opener for the live draft handshake.
document.querySelector('#visit')?.setAttribute('rel','opener');
const draftPreviewTargetOrigin=location.origin==='null'?'*':location.origin;
window.addEventListener('message',event=>{
 if(event.origin!==location.origin||event.data?.type!=='hopclic-request-preview'||!event.source)return;
 const source=event.source;
 const send=()=>{try{source.postMessage({type:'hopclic-preview',html:page()},draftPreviewTargetOrigin)}catch{}};
 Promise.resolve(window.photoLibraryReady).then(send,send);
});
