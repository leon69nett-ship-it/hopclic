contentNames.contact='Formulaire de contact';
for(const block of state.blocks){
 if(block.type!=='contact')continue;
 if(block.menuLabel==='Demande de devis')block.menuLabel='Formulaire de contact';
 if(block.title==='Demande de devis')block.title='Formulaire de contact';
}
render();update();
