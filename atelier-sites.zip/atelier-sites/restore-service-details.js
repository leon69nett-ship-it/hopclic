if(!localStorage.getItem(KEY+'-service-details-restored-v1')){
  for(const block of state.blocks)if(block.type==='services'){
    block.serviceDetails??=[];
    serviceItems(block).forEach((item,index)=>{block.serviceDetails[index]={label:'En savoir plus',title:'',text:'',...block.serviceDetails[index],enabled:true}});
  }
  localStorage.setItem(KEY+'-service-details-restored-v1','1');render();update();
}
