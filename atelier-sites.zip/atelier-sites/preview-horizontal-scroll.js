(() => {
  const frame = document.querySelector('#preview');
  const pan = document.querySelector('#preview-pan');
  const control = document.querySelector('#preview-pan-control');
  if (!frame || !pan || !control) return;
  control.title = 'Faire défiler le rendu de gauche à droite';
  control.setAttribute('aria-label', 'Faire défiler le rendu de gauche à droite');

  let observedDocument = null;
  let mutationObserver = null;
  let resizeObserver = null;
  let scheduled = false;

  const updateBar = () => {
    scheduled = false;
    const doc = frame.contentDocument;
    const view = frame.contentWindow;
    if (!doc?.documentElement || !doc.body || !view) {
      pan.hidden = true;
      return;
    }

    doc.documentElement.style.setProperty('overflow-x', 'auto', 'important');
    doc.body.style.setProperty('overflow-x', 'auto', 'important');

    if (doc !== observedDocument) {
      observedDocument = doc;
      mutationObserver?.disconnect();
      resizeObserver?.disconnect();
      mutationObserver = new MutationObserver(scheduleUpdate);
      mutationObserver.observe(doc.documentElement, { childList: true, subtree: true });
      if ('ResizeObserver' in view) {
        resizeObserver = new view.ResizeObserver(scheduleUpdate);
        resizeObserver.observe(doc.documentElement);
        resizeObserver.observe(doc.body);
      }
      view.addEventListener('scroll', scheduleUpdate, { passive: true });
    }

    const maxScroll = Math.max(0, Math.max(doc.documentElement.scrollWidth, doc.body.scrollWidth) - view.innerWidth);
    control.max = String(maxScroll);
    control.value = String(Math.max(0, Math.min(maxScroll, view.scrollX || doc.documentElement.scrollLeft || 0)));
    pan.hidden = maxScroll <= 2;
  };

  function scheduleUpdate() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(updateBar);
  }

  control.addEventListener('input', () => {
    const view = frame.contentWindow;
    if (!view) return;
    view.scrollTo(Number(control.value), view.scrollY);
  });
  frame.addEventListener('load', scheduleUpdate);
  window.addEventListener('resize', scheduleUpdate, { passive: true });
  scheduleUpdate();
})();
